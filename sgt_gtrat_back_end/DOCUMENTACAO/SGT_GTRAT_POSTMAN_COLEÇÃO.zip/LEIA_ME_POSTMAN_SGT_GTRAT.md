# SGT/GTRAT — Postman — Etapa 13

## Arquivos

- `SGT_GTRAT_POSTMAN_COLLECTION_ETAPA13.json`: coleção completa, 282 endpoints em 44 controladores.
- `SGT_GTRAT_POSTMAN_ENVIRONMENT_LOCAL.json`: ambiente local (`http://localhost:8080`).

## Importação

No Postman, use **Import** e selecione os dois arquivos JSON. Depois selecione o ambiente **SGT/GTRAT — Local Java 17**.

## Antes de testar

Preencha no ambiente:

- `matricula`
- `password`
- `totp` somente se a conta usar 2FA
- IDs conforme os dados existentes no banco quando necessário.

## Ordem inicial recomendada

1. `Autenticacao > tokenCsrf — GET /api/autenticacao/csrf`
2. `Autenticacao > autenticar — POST /api/autenticacao/autenticar`
3. `Autenticacao > informacoesSessao — GET /api/autenticacao/sessao`
4. Demais endpoints.

O endpoint CSRF grava `csrfToken` automaticamente. Os cookies `autenticacao`, `dispositivo` e `XSRF-TOKEN` são mantidos pelo Cookie Jar do Postman. A coleção adiciona `X-XSRF-TOKEN` em POST/PUT/PATCH/DELETE.

Endpoints `@ExigirSenha` já possuem o header `X-User-Password: {{password}}`. Em uma sessão com 2FA forte, o backend pode dispensar a redigitação da senha, mas manter o header não prejudica o teste.

## Observações

- Parâmetros opcionais ficam desabilitados por padrão; habilite os necessários no Postman.
- Corpos JSON foram gerados a partir dos DTOs/requisições reais do código e servem como ponto de partida; ajuste IDs e valores conforme seu banco.
- Endpoints multipart incluem os campos de metadados e arquivo; o arquivo precisa ser selecionado manualmente.
- O teste genérico da coleção marca como falha respostas 5xx. Respostas 4xx podem representar validação/regra de negócio e devem ser avaliadas conforme o cenário.
- A coleção reflete a Etapa 13 atual: inclui `/api/autenticacao/csrf` e `/api/contratos/{id}/corrigir-anulacao`; não inclui o antigo `POST /api/pessoas`, removido do controlador atual.
