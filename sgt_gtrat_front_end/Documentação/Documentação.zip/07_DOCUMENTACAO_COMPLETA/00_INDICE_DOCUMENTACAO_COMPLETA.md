# SGT/GTRAT — Índice da documentação completa

## Escopo

Este diretório consolida a documentação do **React das Etapas 01 a 18** e a documentação do **Java atual, centro da verdade**. Os documentos históricos foram recuperados das entregas originais, da Library/memória de conversas anteriores e da cadeia de ZIPs preservada nas próprias etapas.

## Precedência documental

1. **Java atual** (`01_JAVA_CENTRO_DA_VERDADE`) — contrato autoritativo de API, segurança e regras negociais.

2. **Documentação final da Etapa 18** — estado vigente do frontend candidato à homologação.

3. **Planejamento React original** — requisitos, rastreabilidade e plano das 18 etapas.

4. **Histórico React Etapas 01–18** — evidência de evolução; pode conter decisões superadas e por isso não substitui o Java atual.

## Estrutura

- `01_JAVA_CENTRO_DA_VERDADE/`: documentação extraída do `JAVA.zip` atual, incluindo requisitos, contratos, planos, aderência, auditorias e evidências do backend.

- `02_PLANEJAMENTO_REACT_ORIGINAL/`: planejamento consolidado enviado para implementação das 18 etapas.

- `03_AUDITORIAS_E_CORRECOES/`: auditorias e correções transversais.

- `04_HISTORICO_REACT_ETAPAS_01_A_18/`: documentação/evidências reais de cada uma das 18 etapas.

- `05_HASHES_ENTREGAS_HISTORICAS/`: hashes das entregas históricas recuperadas quando disponíveis.

## Cobertura por etapa React

| Etapa | Arquivos recuperados | Fonte principal |
|---:|---:|---|
| 01 | 31 | Library/memória — documentação V2 detalhada |
| 02 | 45 | Library/memória — ZIP original da etapa |
| 03 | 30 | Library/memória — ZIP original da etapa |
| 04 | 48 | Library/memória — ZIP original da etapa |
| 05 | 85 | Library/memória — ZIP original da etapa |
| 06 | 68 | Library/memória — ZIP original da etapa |
| 07 | 64 | Library/memória — ZIP original da etapa |
| 08 | 67 | Library/memória — ZIP original da etapa |
| 09 | 57 | Library/memória — ZIP original da etapa |
| 10 | 45 | cadeia de ZIPs preservada na Etapa 12 |
| 11 | 34 | cadeia de ZIPs preservada na Etapa 12 |
| 12 | 64 | ZIP original recebido da Etapa 12 |
| 13 | 56 | ZIP final corrigido da Etapa 13 |
| 14 | 26 | árvore final validada da etapa |
| 15 | 726 | árvore final validada da etapa |
| 16 | 732 | árvore final validada da etapa |
| 17 | 28 | árvore final validada da etapa |
| 18 | 47 | árvore final validada da etapa |

## Documentação Java

- Arquivos presentes em `01_JAVA_CENTRO_DA_VERDADE`: **118**.

- SHA-256 do Java atual: `bb9eeb2d779015d00145aaee2aef55a45537082814ea79ba8eee135ac0055f18`.

- O acervo Java inclui documentação histórica das etapas do backend e o contrato pós-auditoria usado pelo React.

## Observação de segurança

A consolidação documental não reintroduz `.env` reais, certificados privados ou chaves privadas no candidato. Documentos históricos são preservados, mas artefatos sensíveis de execução não são copiados para este acervo.
