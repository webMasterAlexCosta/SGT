# SGT/GTRAT — Inventário Detalhado da API Java + Decisão de Consumo React V2

**Total:** 282 mapeamentos HTTP. Cada endpoint possui decisão e etapa prevista.

## Legenda de decisão

- **CONSUMIR/VALIDAR:** integrar na etapa indicada.  
- **CONSUMIR SOMENTE COMO PROJEÇÃO OPERACIONAL AUXILIAR:** permitido para leitura operacional, sem virar identidade negocial.  
- **MIGRAR/EVITAR COMO FONTE CANÔNICA:** endpoint legado de leitura; preferir domínio canônico.  
- **NÃO USAR NO NOVO FLUXO CANÔNICO:** não construir nova escrita sobre ele.  
- **NÃO CONSUMIR:** endpoint bloqueado/interno.  
- **OPCIONAL — DIAGNÓSTICO ADMIN:** somente se houver decisão de manter UI técnica.

## 1. AditamentoContratualControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/contratos/{contratoId}/aditamentos` | `listar` | query/path | `List<AditamentoContratualDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/aditamentos/previa` | `previa` | AditamentoContratualRequisicao requisicao | `PreviaAditamentoContratualDTO` | SIM | NAO | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/aditamentos` | `registrar` | AditamentoContratualRequisicao requisicao | `ResponseEntity<AditamentoContratualDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/aditamentos/{aditamentoId}/retificar` | `retificar` | AditamentoContratualRequisicao requisicao | `AditamentoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/aditamentos/{aditamentoId}/cancelar` | `cancelar` | AcaoCicloVidaContratoDTO acao | `AditamentoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |

## 2. AgenciaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/agencias` | `listarTodos` | none | `Page<AgenciaDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| GET | `/api/agencias/{id}` | `buscarPorId` | query/path | `ResponseEntity<AgenciaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/agencias` | `criar` | AgenciaDTO dto | `AgenciaDTO` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/agencias/{id}` | `atualizar` | AgenciaDTO dto | `ResponseEntity<AgenciaDTO>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/agencias/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 3. AutenticacaoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| POST | `/api/autenticacao/alterar-senha-inicial` | `alterarSenhaInicial` | AlteracaoSenhaInicialAutenticacaoDTO data | `ResponseEntity<?>` | SIM | NAO | authenticated | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| GET | `/api/autenticacao/sessao` | `informacoesSessao` | query/path | `ResponseEntity<?>` | NAO | NAO | authenticated | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| POST | `/api/autenticacao/renovar-sessao` | `renovarSessao` | RenovacaoSessaoDTO payload | `ResponseEntity<?>` | SIM | NAO | authenticated | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| POST | `/api/autenticacao/autenticar` | `autenticar` | CredenciaisLoginDTO loginData | `ResponseEntity<?>` | SIM | NAO | permitAll | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| GET | `/api/autenticacao/csrf` | `tokenCsrf` | none | `ResponseEntity<TokenCsrfDTO>` | NAO | NAO | permitAll | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| GET | `/api/autenticacao/superintendencias` | `listarSuperintendenciasParaCadastro` | none | `ResponseEntity<List<AutenticacaoSuperintendenciaDTO>>` | NAO | NAO | permitAll | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| GET | `/api/autenticacao/gestoes-locais` | `listarGestoesLocaisParaCadastro` | query/path | `ResponseEntity<List<AutenticacaoGestaoLocalDTO>>` | NAO | NAO | permitAll | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| POST | `/api/autenticacao/cadastrar` | `registrar` | CadastroAutenticacaoDTO userData | `ResponseEntity<?>` | SIM | NAO | permitAll | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| POST | `/api/autenticacao/recuperar-senha/solicitar` | `solicitarRecuperacaoSenha` | SolicitacaoRecuperacaoSenhaDTO payload | `ResponseEntity<MensagemApiDTO>` | SIM | NAO | permitAll | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| GET | `/api/autenticacao/recuperar-senha/validar` | `validarTokenRecuperacaoSenha` | query/path | `ResponseEntity<ValidacaoTokenRecuperacaoSenhaDTO>` | NAO | NAO | permitAll | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| POST | `/api/autenticacao/recuperar-senha/confirmar` | `confirmarRecuperacaoSenha` | ConfirmacaoRecuperacaoSenhaDTO payload | `ResponseEntity<MensagemApiDTO>` | SIM | NAO | permitAll | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |
| POST | `/api/autenticacao/encerrar-sessao` | `encerrarSessao` | none | `ResponseEntity<?>` | SIM | NAO | permitAll | 04 | **CONSUMIR/VALIDAR** | Login/Sessão/Acesso: Integrar conforme contrato e permissões. |

## 4. BancoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/bancos` | `listarTodos` | none | `Page<BancoDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| GET | `/api/bancos/{id}` | `buscarPorId` | query/path | `ResponseEntity<BancoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/bancos` | `criar` | BancoDTO dto | `BancoDTO` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/bancos/{id}` | `atualizar` | BancoDTO dto | `ResponseEntity<BancoDTO>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/bancos/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 5. CacheDiagnosticoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/cache/status` | `status` | none | `CacheDiagnosticoDTO` | NAO | NAO | authenticated | 17 | **OPCIONAL — DIAGNÓSTICO ADMIN** | Diagnóstico técnico: Não é requisito de tela operacional; consumir apenas se for mantido painel técnico. |

## 6. CalendarioEventoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/calendario-eventos` | `listar` | query/path | `List<CalendarioEventoDTO>` | NAO | NAO | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/calendario-eventos` | `criar` | CalendarioEventoRequisicao dados | `ResponseEntity<CalendarioEventoDTO>` | SIM | SIM | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| PUT | `/api/calendario-eventos/{id}` | `atualizar` | CalendarioEventoRequisicao dados | `ResponseEntity<CalendarioEventoDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| DELETE | `/api/calendario-eventos/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |

## 7. CargoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/cargos` | `listarTodos` | none | `Page<CargoDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| GET | `/api/cargos/{id}` | `buscarPorId` | query/path | `ResponseEntity<CargoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/cargos` | `criar` | CargoDTO dto | `CargoDTO` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/cargos/{id}` | `atualizar` | CargoDTO dto | `ResponseEntity<CargoDTO>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/cargos/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 8. ComposicaoContratualControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/contratos/{contratoId}/composicoes` | `listar` | query/path | `List<ComposicaoContratualDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{contratoId}/composicoes/excedentes` | `listarExcedentes` | query/path | `List<ExcedenteComposicaoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/composicoes` | `criar` | ComposicaoContratualDTO dto | `ResponseEntity<ComposicaoContratualDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| PUT | `/api/contratos/{contratoId}/composicoes/{id}` | `atualizar` | ComposicaoContratualDTO dto | `ComposicaoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| DELETE | `/api/contratos/{contratoId}/composicoes/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |

## 9. ConfiguracaoSistemaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/config.json` | `obterConfiguracaoPublica` | none | `ResponseEntity<ConfiguracaoPublicaSistemaDTO>` | NAO | NAO | permitAll | 02 | **CONSUMIR NO BOOTSTRAP/VALIDAR** | Bootstrap runtime: Integrar conforme contrato e permissões. |
| GET | `/api/sistema/configuracoes` | `listarConfiguracoes` | none | `ResponseEntity<List<ConfiguracaoSistemaDTO>>` | NAO | NAO | authenticated | 07 | **CONSUMIR/VALIDAR** | Configurações administrativas: Integrar conforme contrato e permissões. |
| POST | `/api/sistema/configuracoes` | `salvarConfiguracao` | List<ConfiguracaoSistemaDTO> configuracoes | `ResponseEntity<MensagemApiDTO>` | SIM | NAO | authenticated | 07 | **CONSUMIR/VALIDAR** | Configurações administrativas: Integrar conforme contrato e permissões. |

## 10. ContaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/contas` | `listarTodos` | none | `Page<ContaDTO>` | NAO | NAO | authenticated | N/A | **NÃO CONSUMIR** | Sem UI: Bloqueado/legado; dados devem vir por DTOs agregados autorizados. |
| GET | `/api/contas/{id}` | `buscarPorId` | query/path | `ResponseEntity<ContaDTO>` | NAO | NAO | denyAll | N/A | **NÃO CONSUMIR** | Sem UI: Endpoint bloqueado pela configuração de segurança; manter fora do frontend. |
| POST | `/api/contas` | `criar` | ContaDTO dto | `ContaDTO` | SIM | SIM | authenticated | N/A | **NÃO CONSUMIR** | Sem UI: Bloqueado/legado; dados devem vir por DTOs agregados autorizados. |
| PUT | `/api/contas/{id}` | `atualizar` | ContaDTO dto | `ResponseEntity<ContaDTO>` | SIM | SIM | denyAll | N/A | **NÃO CONSUMIR** | Sem UI: Endpoint bloqueado pela configuração de segurança; manter fora do frontend. |
| DELETE | `/api/contas/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | denyAll | N/A | **NÃO CONSUMIR** | Sem UI: Endpoint bloqueado pela configuração de segurança; manter fora do frontend. |

## 11. ContratoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/contratos` | `listarTodos` | none | `List<ContratoDTO>` | NAO | NAO | authenticated | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/opcoes` | `obterOpcoes` | none | `List<ContratoOpcaoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{id}` | `buscarPorId` | query/path | `ContratoDTO` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{id}/eventos` | `listarEventos` | query/path | `List<EventoCicloVidaContratoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{id}/eventos/precedencias` | `listarPrecedencias` | query/path | `List<RelacaoPrecedenciaEventoContratoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{id}/versoes` | `listarVersoes` | query/path | `List<VersaoContratoNegocialDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{id}/transferencias-gestao` | `listarTransferenciasGestao` | query/path | `List<TransferenciaGestaoContratoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Ações excepcionais/histórico: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{id}/posicao-temporal` | `consultarPosicaoTemporal` | query/path | `PosicaoTemporalContratoDTO` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| POST | `/api/contratos` | `criar` | ContratoDTO dto | `ResponseEntity<ContratoDTO>` | SIM | SIM | authenticated | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{id}/publicar` | `publicar` | PublicacaoContratoDTO dto | `ContratoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| PUT | `/api/contratos/{id}` | `atualizar` | ContratoDTO dto | `ResponseEntity<ContratoDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{id}/inativar` | `inativar` | AcaoCicloVidaContratoDTO acao | `ContratoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{id}/reativar` | `reativar` | AcaoCicloVidaContratoDTO acao | `ContratoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{id}/encerrar-antecipadamente` | `encerrarAntecipadamente` | AcaoCicloVidaContratoDTO acao | `ContratoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{id}/cancelar-futuro` | `cancelarFuturo` | AcaoCicloVidaContratoDTO acao | `ContratoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{id}/anular` | `anular` | AcaoCicloVidaContratoDTO acao | `ContratoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{id}/corrigir-anulacao` | `corrigirAnulacao` | AcaoCicloVidaContratoDTO acao | `ContratoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Ações excepcionais/histórico: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{id}/transferir-gestao` | `transferirGestao` | TransferenciaGestaoContratoRequisicao requisicao | `ContratoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Ações excepcionais/histórico: Integrar conforme contrato e permissões. |
| DELETE | `/api/contratos/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 08 | **CONSUMIR/VALIDAR** | Contratos > Núcleo/Ciclo de vida: Integrar conforme contrato e permissões. |

## 12. CorrecaoIdentificadorContratoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| POST | `/api/contratos/{contratoId}/correcoes-identificador` | `corrigir` | CorrecaoIdentificadorContratoRequisicao requisicao | `ResponseEntity<CorrecaoIdentificadorContratoDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{contratoId}/correcoes-identificador` | `listar` | query/path | `List<CorrecaoIdentificadorContratoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/historico-identificador` | `pesquisar` | query/path | `List<CorrecaoIdentificadorContratoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |

## 13. DocumentoComprobatorioControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/contratos/{contratoId}/documentos` | `listar` | query/path | `List<DocumentoComprobatorioDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{contratoId}/documentos/{documentoId}` | `buscar` | query/path | `DocumentoComprobatorioDTO` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{contratoId}/documentos/{documentoId}/eventos` | `eventos` | query/path | `List<EventoDocumentoComprobatorioDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{contratoId}/documentos/{documentoId}/arquivo` | `baixar` | query/path | `ResponseEntity<FileSystemResource>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/documentos` | `criar` | @RequestPart("metadados") CadastroDocumentoComprobatorioRequisicao requisicao <br> @RequestPart(value = "arquivo", required = false) MultipartFile arquivo | `ResponseEntity<DocumentoComprobatorioDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/documentos/{documentoId}/retificar-sei` | `retificarSei` | RetificacaoSeiDocumentoRequisicao requisicao | `DocumentoComprobatorioDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/documentos/{documentoId}/substituir` | `substituir` | @RequestPart("metadados") SubstituicaoDocumentoComprobatorioRequisicao requisicao <br> @RequestPart(value = "arquivo", required = false) MultipartFile arquivo | `DocumentoComprobatorioDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/documentos/{documentoId}/invalidar` | `invalidar` | AcaoDocumentoComprobatorioRequisicao requisicao | `DocumentoComprobatorioDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| DELETE | `/api/contratos/{contratoId}/documentos/{documentoId}` | `descartarRascunho` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{contratoId}/documentos/{documentoId}/permissoes` | `permissoes` | query/path | `List<PermissaoDocumentoRestritoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/documentos/{documentoId}/permissoes` | `conceder` | ConcessaoAcessoDocumentoRequisicao requisicao | `PermissaoDocumentoRestritoDTO` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/documentos/{documentoId}/permissoes/{permissaoId}/revogar` | `revogar` | AcaoDocumentoComprobatorioRequisicao requisicao | `PermissaoDocumentoRestritoDTO` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |
| GET | `/api/contratos/{contratoId}/documentos/{documentoId}/acessos` | `acessos` | query/path | `List<AcessoDocumentoRestritoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 10 | **CONSUMIR/VALIDAR** | Contrato > Documentos/Correções: Integrar conforme contrato e permissões. |

## 14. EmpregadoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/empregados/{id}/historico-contratos` | `obterHistoricoContratos` | query/path | `ResponseEntity<List<HistoricoVinculoContratoDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 11/17 | **MIGRAR/EVITAR COMO FONTE CANÔNICA** | Compatibilidade/legado: Preferir Pessoa/Vínculo/Alocação; manter apenas se houver caso de leitura legado comprovado. |
| GET | `/api/empregados` | `listarTodos` | query/path | `Page<EmpregadoDTO>` | NAO | NAO | authenticated | 11/17 | **MIGRAR/EVITAR COMO FONTE CANÔNICA** | Compatibilidade/legado: Preferir Pessoa/Vínculo/Alocação; manter apenas se houver caso de leitura legado comprovado. |
| GET | `/api/empregados/resumo` | `obterResumo` | query/path | `Page<EmpregadoListaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 11/17 | **MIGRAR/EVITAR COMO FONTE CANÔNICA** | Compatibilidade/legado: Preferir Pessoa/Vínculo/Alocação; manter apenas se houver caso de leitura legado comprovado. |
| GET | `/api/empregados/filtrados-frequencia` | `obterEmpregadosParaFrequencia` | query/path | `ResponseEntity<Page<EmpregadoFrequenciaDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 13 | **CONSUMIR SOMENTE COMO PROJEÇÃO OPERACIONAL AUXILIAR** | Frequência: Pode apoiar seleção operacional, mas identidade/comando de frequência permanece por vinculoContratualId. |
| GET | `/api/empregados/{id}` | `buscarPorId` | query/path | `ResponseEntity<EmpregadoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 11/17 | **MIGRAR/EVITAR COMO FONTE CANÔNICA** | Compatibilidade/legado: Preferir Pessoa/Vínculo/Alocação; manter apenas se houver caso de leitura legado comprovado. |
| POST | `/api/empregados` | `criar` | EmpregadoDTO dto | `ResponseEntity<EmpregadoDTO>` | SIM | NAO | authenticated | N/A | **NÃO USAR NO NOVO FLUXO CANÔNICO** | Sem nova UI canônica: POST/PUT/DELETE de Empregado não deve comandar criação/edição canônica de pessoa/vínculo. |
| PUT | `/api/empregados/{id}` | `atualizar` | EmpregadoDTO dto | `ResponseEntity<EmpregadoDTO>` | SIM | NAO | hasAnyAuthority PERFIL_GESTOR_LOCAL | N/A | **NÃO USAR NO NOVO FLUXO CANÔNICO** | Sem nova UI canônica: POST/PUT/DELETE de Empregado não deve comandar criação/edição canônica de pessoa/vínculo. |
| DELETE | `/api/empregados/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | N/A | **NÃO USAR NO NOVO FLUXO CANÔNICO** | Sem nova UI canônica: POST/PUT/DELETE de Empregado não deve comandar criação/edição canônica de pessoa/vínculo. |

## 15. EnderecoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/enderecos` | `listarTodos` | none | `Page<EnderecoDTO>` | NAO | NAO | authenticated | N/A | **NÃO CONSUMIR** | Sem UI: Bloqueado/legado; dados devem vir por DTOs agregados autorizados. |
| GET | `/api/enderecos/{id}` | `buscarPorId` | query/path | `ResponseEntity<EnderecoDTO>` | NAO | NAO | denyAll | N/A | **NÃO CONSUMIR** | Sem UI: Endpoint bloqueado pela configuração de segurança; manter fora do frontend. |
| POST | `/api/enderecos` | `criar` | EnderecoDTO dto | `EnderecoDTO` | SIM | SIM | authenticated | N/A | **NÃO CONSUMIR** | Sem UI: Bloqueado/legado; dados devem vir por DTOs agregados autorizados. |
| PUT | `/api/enderecos/{id}` | `atualizar` | EnderecoDTO dto | `ResponseEntity<EnderecoDTO>` | SIM | SIM | denyAll | N/A | **NÃO CONSUMIR** | Sem UI: Endpoint bloqueado pela configuração de segurança; manter fora do frontend. |
| DELETE | `/api/enderecos/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | denyAll | N/A | **NÃO CONSUMIR** | Sem UI: Endpoint bloqueado pela configuração de segurança; manter fora do frontend. |

## 16. FechamentoFrequenciaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| POST | `/api/frequencias/fechamentos` | `criar` | RequisicaoCriacaoFechamentoFrequencia request | `ResponseEntity<FechamentoFrequenciaDTO>` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| GET | `/api/frequencias/fechamentos/{id}` | `buscar` | query/path | `ResponseEntity<FechamentoFrequenciaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| GET | `/api/frequencias/fechamentos/atual` | `buscarAtual` | query/path | `ResponseEntity<FechamentoFrequenciaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/frequencias/fechamentos/{id}/cancelamento` | `cancelar` | query/path | `ResponseEntity<FechamentoFrequenciaDTO>` | SIM | NAO | hasAnyAuthority PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/frequencias/fechamentos/{id}/reprocessamento` | `reprocessar` | query/path | `ResponseEntity<FechamentoFrequenciaDTO>` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |

## 17. FrequenciaAdicionalControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/frequencias-adicionais` | `listar` | query/path | `ResponseEntity<Page<FrequenciaAdicionalDTO>>` | NAO | NAO | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/frequencias-adicionais` | `criar` | FrequenciaAdicionalDTO dto | `ResponseEntity<FrequenciaAdicionalDTO>` | SIM | SIM | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| PUT | `/api/frequencias-adicionais/{id}` | `atualizar` | FrequenciaAdicionalDTO dto | `ResponseEntity<FrequenciaAdicionalDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| DELETE | `/api/frequencias-adicionais/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |

## 18. FrequenciaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/frequencias` | `buscarPorData` | query/path | `ResponseEntity<Page<FrequenciaDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 13 | **CONSUMIR/VALIDAR** | Frequência diária/lote: Integrar conforme contrato e permissões. |
| GET | `/api/frequencias/mensal` | `obterMensal` | query/path | `ResponseEntity<Page<FrequenciaDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 13 | **CONSUMIR/VALIDAR** | Frequência diária/lote: Integrar conforme contrato e permissões. |
| GET | `/api/frequencias/intervalo` | `obterIntervalo` | query/path | `ResponseEntity<Page<FrequenciaDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 13 | **CONSUMIR/VALIDAR** | Frequência diária/lote: Integrar conforme contrato e permissões. |
| GET | `/api/frequencias/{id}/eventos` | `listarEventos` | query/path | `ResponseEntity<List<EventoFrequenciaDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 13 | **CONSUMIR/VALIDAR** | Frequência diária/lote: Integrar conforme contrato e permissões. |
| POST | `/api/frequencias` | `salvarOuAtualizar` | FrequenciaDTO dto | `ResponseEntity<FrequenciaDTO>` | SIM | SIM | authenticated | 13 | **CONSUMIR/VALIDAR** | Frequência diária/lote: Integrar conforme contrato e permissões. |
| POST | `/api/frequencias/lote` | `salvarOuAtualizarLote` | List<FrequenciaDTO> itens | `ResponseEntity<List<FrequenciaDTO>>` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 13 | **CONSUMIR/VALIDAR** | Frequência diária/lote: Integrar conforme contrato e permissões. |

## 19. FrequenciaExcecaoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/frequencias-excecoes` | `listarAtivasPorData` | query/path | `ResponseEntity<Page<FrequenciaExcecaoDTO>>` | NAO | NAO | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/frequencias-excecoes` | `criar` | FrequenciaExcecaoDTO dto | `ResponseEntity<FrequenciaExcecaoDTO>` | SIM | SIM | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| PUT | `/api/frequencias-excecoes/{id}` | `atualizar` | FrequenciaExcecaoDTO dto | `ResponseEntity<FrequenciaExcecaoDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| DELETE | `/api/frequencias-excecoes/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |

## 20. GestaoLocalControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/gestoes-locais` | `listar` | query/path | `List<GestaoLocalDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/gestoes-locais` | `criar` | GestaoLocalDTO dto | `ResponseEntity<GestaoLocalDTO>` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/gestoes-locais/{id}` | `atualizar` | GestaoLocalDTO dto | `GestaoLocalDTO` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/gestoes-locais/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 21. GovernancaTerceirosControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/governanca-terceiros/resumo` | `resumo` | none | `GovernancaResumoDTO` | NAO | NAO | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| GET | `/api/governanca-terceiros/fornecedores` | `fornecedores` | none | `List<FornecedorGovernancaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| POST | `/api/governanca-terceiros/fornecedores` | `criarFornecedor` | FornecedorGovernancaEntradaDTO dados | `FornecedorGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| PUT | `/api/governanca-terceiros/fornecedores/{id}` | `atualizarFornecedor` | FornecedorGovernancaEntradaDTO dados | `FornecedorGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| PUT | `/api/governanca-terceiros/contratos/{contratoId}/fornecedor/{fornecedorId}` | `vincularFornecedor` | query/path | `ContratoFornecedorGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| GET | `/api/governanca-terceiros/tabelas-tarifarias` | `tabelasTarifarias` | query/path | `List<TabelaTarifariaGovernancaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| POST | `/api/governanca-terceiros/tabelas-tarifarias` | `criarTabelaTarifaria` | TabelaTarifariaGovernancaEntradaDTO dados | `TabelaTarifariaGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| GET | `/api/governanca-terceiros/processos` | `processos` | none | `List<ProcessoTerceiroGovernancaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| POST | `/api/governanca-terceiros/processos` | `criarProcesso` | ProcessoTerceiroEntradaDTO dados | `ProcessoTerceiroGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| PATCH | `/api/governanca-terceiros/processos/{id}/status` | `statusProcesso` | StatusGovernancaDTO dados | `ProcessoTerceiroGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| GET | `/api/governanca-terceiros/folhas-horas` | `folhasHoras` | none | `List<FolhaHorasGovernancaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| POST | `/api/governanca-terceiros/folhas-horas/gerar` | `gerarFolhaHoras` | FolhaHorasGeracaoDTO dados | `FolhaHorasGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| POST | `/api/governanca-terceiros/folhas-horas/{id}/submeter` | `submeter` | query/path | `FolhaHorasGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| POST | `/api/governanca-terceiros/folhas-horas/{id}/aprovar` | `aprovar` | query/path | `FolhaHorasGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| POST | `/api/governanca-terceiros/folhas-horas/{id}/rejeitar` | `rejeitar` | MotivoGovernancaDTO dados | `FolhaHorasGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| GET | `/api/governanca-terceiros/faturas` | `faturas` | none | `List<FaturaGovernancaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| POST | `/api/governanca-terceiros/faturas/gerar/{folhaHorasId}` | `gerarFatura` | FaturaGeracaoDTO dados | `FaturaGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| PATCH | `/api/governanca-terceiros/faturas/{id}/status` | `statusFatura` | FaturaStatusDTO dados | `FaturaGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| GET | `/api/governanca-terceiros/riscos` | `riscos` | none | `List<RiscoFornecedorGovernancaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| POST | `/api/governanca-terceiros/riscos` | `avaliarRisco` | RiscoFornecedorEntradaDTO dados | `RiscoFornecedorGovernancaDTO` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |

## 22. HistoricoEmpregadoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/historicos-empregados` | `listarTodos` | none | `Page<HistoricoEmpregadoDTO>` | NAO | NAO | authenticated | 11/17 | **MIGRAR/VALIDAR COMPATIBILIDADE** | Histórico legado: Preferir histórico canônico de Pessoa/Vínculo quando equivalente. |
| GET | `/api/historicos-empregados/empregado/{id}` | `buscarPorEmpregado` | query/path | `ResponseEntity<List<HistoricoEmpregadoDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 11/17 | **MIGRAR/VALIDAR COMPATIBILIDADE** | Histórico legado: Preferir histórico canônico de Pessoa/Vínculo quando equivalente. |
| GET | `/api/historicos-empregados/empregado/{id}/integridade` | `verificarIntegridade` | query/path | `ResponseEntity<HistoricoIntegridadeServico.ResultadoVerificacao>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 11/17 | **MIGRAR/VALIDAR COMPATIBILIDADE** | Histórico legado: Preferir histórico canônico de Pessoa/Vínculo quando equivalente. |
| GET | `/api/historicos-empregados/{id}` | `buscarPorId` | query/path | `ResponseEntity<HistoricoEmpregadoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 11/17 | **MIGRAR/VALIDAR COMPATIBILIDADE** | Histórico legado: Preferir histórico canônico de Pessoa/Vínculo quando equivalente. |

## 23. JornadaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/jornadas` | `listar` | query/path | `List<JornadaDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| GET | `/api/jornadas/{id}` | `obter` | query/path | `ResponseEntity<JornadaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/jornadas` | `criar` | JornadaDTO dto | `ResponseEntity<JornadaDTO>` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/jornadas/{id}` | `atualizar` | JornadaDTO dto | `ResponseEntity<JornadaDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/jornadas/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 24. LotacaoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/lotacoes` | `listarTodos` | none | `Page<LotacaoDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| GET | `/api/lotacoes/opcoes` | `obterOpcoes` | none | `List<LotacaoOpcaoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| GET | `/api/lotacoes/{id}` | `buscarPorId` | query/path | `ResponseEntity<LotacaoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/lotacoes` | `criar` | LotacaoDTO dto | `ResponseEntity<LotacaoDTO>` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/lotacoes/{id}` | `atualizar` | LotacaoDTO dto | `ResponseEntity<LotacaoDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/lotacoes/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 25. MotivoDesligamentoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/motivos-desligamento` | `listar` | none | `List<MotivoDesligamentoDTO>` | NAO | NAO | authenticated | 11 | **CONSUMIR/VALIDAR** | Vínculo > Motivos de desligamento: Integrar conforme contrato e permissões. |
| GET | `/api/motivos-desligamento/{id}` | `buscarPorId` | query/path | `MotivoDesligamentoDTO` | NAO | NAO | authenticated | 11 | **CONSUMIR/VALIDAR** | Vínculo > Motivos de desligamento: Integrar conforme contrato e permissões. |
| POST | `/api/motivos-desligamento` | `criar` | MotivoDesligamentoDTO dto | `ResponseEntity<MotivoDesligamentoDTO>` | SIM | SIM | authenticated | 11 | **CONSUMIR/VALIDAR** | Vínculo > Motivos de desligamento: Integrar conforme contrato e permissões. |
| PUT | `/api/motivos-desligamento/{id}` | `atualizar` | MotivoDesligamentoDTO dto | `MotivoDesligamentoDTO` | SIM | SIM | authenticated | 11 | **CONSUMIR/VALIDAR** | Vínculo > Motivos de desligamento: Integrar conforme contrato e permissões. |

## 26. OcorrenciaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/ocorrencias` | `listarTodos` | query/path | `Page<OcorrenciaResumoDTO>` | NAO | NAO | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| GET | `/api/ocorrencias/anexos/{anexoId}` | `baixarAnexo` | query/path | `ResponseEntity<Resource>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/ocorrencias` | `criar` | query/path | `ResponseEntity<OcorrenciaResumoDTO>` | SIM | SIM | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| DELETE | `/api/ocorrencias/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAnyAuthority PERFIL_GESTOR_LOCAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |

## 27. PainelCalculoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| POST | `/api/painel/calculos` | `solicitar` | query/path | `ResponseEntity<PainelCalculoDTO>` | SIM | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 15 | **CONSUMIR/VALIDAR** | Painel: Integrar conforme contrato e permissões. |
| GET | `/api/painel/calculos/{id}` | `consultar` | query/path | `ResponseEntity<PainelCalculoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 15 | **CONSUMIR/VALIDAR** | Painel: Integrar conforme contrato e permissões. |

## 28. PainelControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/painel/efetivo/filtros` | `obterFiltrosEfetivo` | query/path | `ResponseEntity<PainelEfetivoDTO.Filtros>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 15 | **CONSUMIR/VALIDAR** | Painel: Integrar conforme contrato e permissões. |
| GET | `/api/painel/efetivo` | `obterIndicadorEfetivo` | query/path | `ResponseEntity<PainelEfetivoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 15 | **CONSUMIR/VALIDAR** | Painel: Integrar conforme contrato e permissões. |
| GET | `/api/painel/gestao` | `obterGestao` | query/path | `ResponseEntity<PainelGestaoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 15 | **CONSUMIR/VALIDAR** | Painel: Integrar conforme contrato e permissões. |
| GET | `/api/painel/estatisticas` | `obterEstatisticas` | none | `ResponseEntity<EstatisticasPainelDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 15 | **CONSUMIR/VALIDAR** | Painel: Integrar conforme contrato e permissões. |
| GET | `/api/painel/atividades` | `obterAtividadesRecentes` | query/path | `ResponseEntity<Page<AtividadePainelDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 15 | **CONSUMIR/VALIDAR** | Painel: Integrar conforme contrato e permissões. |
| GET | `/api/painel/ranking-lotacoes` | `obterRankingLotacoes` | query/path | `ResponseEntity<List<PainelRankingDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 15 | **CONSUMIR/VALIDAR** | Painel: Integrar conforme contrato e permissões. |

## 29. PendenciaAdministrativaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/pendencias` | `listar` | query/path | `ResponseEntity<PaginaPendenciasDTO>` | NAO | NAO | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| GET | `/api/pendencias/resumo` | `resumo` | query/path | `ResponseEntity<ResumoPendenciasDTO>` | NAO | NAO | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/pendencias/{id}/iniciar-tratamento` | `iniciar` | TratamentoPendenciaRequisicao requisicao | `ResponseEntity<PendenciaDTO>` | SIM | NAO | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/pendencias/{id}/confirmar-resolucao` | `confirmarResolucao` | TratamentoPendenciaRequisicao requisicao | `ResponseEntity<PendenciaDTO>` | SIM | NAO | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |

## 30. PerfilControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/perfil/2fa/status` | `statusSegundoFator` | none | `ResponseEntity<?>` | NAO | NAO | authenticated | 04/07 | **CONSUMIR/VALIDAR** | Meu Perfil/Segurança: Integrar conforme contrato e permissões. |
| POST | `/api/perfil/2fa/configurar` | `configurarSegundoFator` | SenhaAtualDTO payload | `ResponseEntity<?>` | SIM | NAO | authenticated | 04/07 | **CONSUMIR/VALIDAR** | Meu Perfil/Segurança: Integrar conforme contrato e permissões. |
| POST | `/api/perfil/2fa/ativar` | `ativarSegundoFator` | TokenTotpDTO payload | `ResponseEntity<?>` | SIM | NAO | authenticated | 04/07 | **CONSUMIR/VALIDAR** | Meu Perfil/Segurança: Integrar conforme contrato e permissões. |
| DELETE | `/api/perfil/2fa` | `desativarSegundoFator` | DesativacaoSegundoFatorDTO payload | `ResponseEntity<?>` | SIM | NAO | authenticated | 04/07 | **CONSUMIR/VALIDAR** | Meu Perfil/Segurança: Integrar conforme contrato e permissões. |
| POST | `/api/perfil/alterar-senha` | `alterarSenha` | AlteracaoSenhaPerfilDTO payload | `ResponseEntity<?>` | SIM | NAO | authenticated | 04/07 | **CONSUMIR/VALIDAR** | Meu Perfil/Segurança: Integrar conforme contrato e permissões. |
| POST | `/api/perfil/validar-senha` | `validarSenha` | ValidacaoSenhaDTO payload | `ResponseEntity<?>` | SIM | NAO | authenticated | 04/07 | **CONSUMIR/VALIDAR** | Meu Perfil/Segurança: Integrar conforme contrato e permissões. |
| POST | `/api/perfil/avatar` | `enviarAvatar` | query/path | `ResponseEntity<?>` | SIM | NAO | authenticated | 04/07 | **CONSUMIR/VALIDAR** | Meu Perfil/Segurança: Integrar conforme contrato e permissões. |
| GET | `/api/perfil/avatar/{nomeArquivo}` | `obterAvatar` | query/path | `ResponseEntity<Resource>` | NAO | NAO | authenticated | 04/07 | **CONSUMIR/VALIDAR** | Meu Perfil/Segurança: Integrar conforme contrato e permissões. |

## 31. PermissaoExcepcionalControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/permissoes-excepcionais` | `listar` | none | `List<PermissaoExcepcionalDTO>` | NAO | NAO | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/permissoes-excepcionais` | `conceder` | ConcessaoPermissaoExcepcionalRequisicao requisicao | `ResponseEntity<PermissaoExcepcionalDTO>` | SIM | SIM | authenticated | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| POST | `/api/permissoes-excepcionais/{id}/revogar` | `revogar` | RevogacaoPermissaoExcepcionalRequisicao requisicao | `PermissaoExcepcionalDTO` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |
| GET | `/api/permissoes-excepcionais/{id}/usos` | `usos` | query/path | `List<UsoPermissaoExcepcionalDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 14 | **CONSUMIR/VALIDAR** | Operação complementar/Pendências/Exceções: Integrar conforme contrato e permissões. |

## 32. PessoaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/pessoas` | `listar` | query/path | `Page<PessoaResumoDTO>` | NAO | NAO | authenticated | 11 | **CONSUMIR/VALIDAR** | Pessoas: Integrar conforme contrato e permissões. |
| GET | `/api/pessoas/{id}` | `buscar` | query/path | `PessoaDTO` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 11 | **CONSUMIR/VALIDAR** | Pessoas: Integrar conforme contrato e permissões. |
| GET | `/api/pessoas/{id}/dados-restritos` | `buscarDadosRestritos` | query/path | `PessoaDTO` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoas: Integrar conforme contrato e permissões. |
| PUT | `/api/pessoas/{id}/dados-opcionais` | `atualizarOpcionais` | AtualizacaoPessoaOpcionalRequisicao req | `PessoaDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoas: Integrar conforme contrato e permissões. |
| POST | `/api/pessoas/{id}/correcoes-identidade` | `corrigir` | CorrecaoIdentidadePessoaRequisicao req | `PessoaDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoas: Integrar conforme contrato e permissões. |
| GET | `/api/pessoas/{id}/correcoes-identidade` | `correcoes` | query/path | `List<CorrecaoPessoaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 11 | **CONSUMIR/VALIDAR** | Pessoas: Integrar conforme contrato e permissões. |

## 33. RegistroAuditoriaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/registros-auditoria` | `pesquisar` | query/path | `Page<RegistroAuditoriaDTO>` | NAO | NAO | authenticated | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |
| GET | `/api/registros-auditoria/{id}` | `buscarPorId` | query/path | `ResponseEntity<RegistroAuditoriaDTO>` | NAO | NAO | hasAuthority PERFIL_ADMINISTRADOR | 17 | **CONSUMIR/VALIDAR** | Governança/Auditoria: Integrar conforme contrato e permissões. |

## 34. RegraAdicionalControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/jornadas/{jornadaId}/regras-adicionais` | `listar` | query/path | `List<RegraAdicionalDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/jornadas/{jornadaId}/regras-adicionais` | `criar` | RegraAdicionalDTO dto | `ResponseEntity<RegraAdicionalDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/regras-adicionais/{id}` | `atualizar` | RegraAdicionalDTO dto | `ResponseEntity<RegraAdicionalDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/regras-adicionais/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 35. RelatorioAdministrativoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| POST | `/api/relatorios/administrativos/previa` | `previa` | EmissaoRelatorioRequisicao requisicao | `ResponseEntity<RelatorioAdministrativoDTO>` | SIM | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| POST | `/api/relatorios/administrativos/emissoes` | `emitir` | EmissaoRelatorioRequisicao requisicao | `ResponseEntity<RelatorioAdministrativoDTO>` | SIM | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/administrativos/emissoes/{id}` | `obter` | query/path | `ResponseEntity<RelatorioAdministrativoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| POST | `/api/relatorios/administrativos/emissoes/conhecimento` | `conhecidaAte` | EmissaoRelatorioRequisicao requisicao | `ResponseEntity<RelatorioAdministrativoDTO>` | SIM | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/administrativos/emissoes/{id}/comparacao-vigente` | `comparar` | query/path | `ResponseEntity<ComparacaoEmissaoRelatorioDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/administrativos/emissoes` | `listar` | query/path | `ResponseEntity<Page<MetadadosEmissaoRelatorioDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |

## 36. RelatorioControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/relatorios/filtros` | `filtros` | none | `ResponseEntity<RelatorioFiltrosDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/frequencia-consolidada` | `frequenciaConsolidada` | query/path | `ResponseEntity<RelatorioFrequenciaConsolidadoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/frequencia-consolidada/paginada` | `frequenciaConsolidadaPaginada` | query/path | `ResponseEntity<RelatorioFrequenciaPaginaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/frequencia-consolidada/exportacao` | `exportarFrequenciaConsolidada` | query/path | `ResponseEntity<StreamingResponseBody>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| POST | `/api/relatorios/frequencia-consolidada/exportacao/solicitacao` | `solicitarExportacaoFrequencia` | query/path | `ResponseEntity<ExportacaoRelatorioStatusDTO>` | SIM | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/terceirizados/consolidado` | `consolidadoTerceirizados` | query/path | `ResponseEntity<RelatorioTerceirizadosDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/terceirizados/exportacao` | `exportarTerceirizados` | query/path | `ResponseEntity<StreamingResponseBody>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| POST | `/api/relatorios/terceirizados/exportacao/solicitacao` | `solicitarExportacaoTerceirizados` | query/path | `ResponseEntity<ExportacaoRelatorioStatusDTO>` | SIM | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/absenteismo` | `gerarRelatorioAbsenteismo` | query/path | `ResponseEntity<List<RelatorioAbsenteismoDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/absenteismo/paginado` | `gerarRelatorioAbsenteismoPaginado` | query/path | `ResponseEntity<RelatorioAbsenteismoPaginaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/absenteismo/resumo` | `gerarResumoAbsenteismo` | query/path | `ResponseEntity<RelatorioAbsenteismoResumoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/absenteismo/exportacao` | `exportarAbsenteismo` | query/path | `ResponseEntity<StreamingResponseBody>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| POST | `/api/relatorios/absenteismo/exportacao/solicitacao` | `solicitarExportacaoAbsenteismo` | query/path | `ResponseEntity<ExportacaoRelatorioStatusDTO>` | SIM | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/exportacoes/{id}` | `consultarExportacao` | query/path | `ResponseEntity<ExportacaoRelatorioStatusDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/exportacoes/{id}/arquivo` | `baixarExportacao` | query/path | `ResponseEntity<StreamingResponseBody>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |
| GET | `/api/relatorios/horas-trabalhadas` | `gerarRelatorioHorasTrabalhadas` | query/path | `ResponseEntity<List<RelatorioHorasDTO>>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 16 | **CONSUMIR/VALIDAR** | Relatórios/Exportações: Integrar conforme contrato e permissões. |

## 37. RemanejamentoContratualControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/contratos/{contratoId}/remanejamentos` | `listar` | query/path | `List<RemanejamentoContratualDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/remanejamentos/previa` | `previa` | RemanejamentoContratualRequisicao requisicao | `PreviaRemanejamentoContratualDTO` | SIM | NAO | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/remanejamentos` | `registrar` | RemanejamentoContratualRequisicao requisicao | `ResponseEntity<RemanejamentoContratualDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/remanejamentos/{remanejamentoId}/retificar` | `retificar` | RemanejamentoContratualRequisicao requisicao | `RemanejamentoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |
| POST | `/api/contratos/{contratoId}/remanejamentos/{remanejamentoId}/cancelar` | `cancelar` | AcaoCicloVidaContratoDTO acao | `RemanejamentoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 09 | **CONSUMIR/VALIDAR** | Contrato > Composição/Aditamento/Remanejamento: Integrar conforme contrato e permissões. |

## 38. StatusEmpregadoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/status-empregados` | `listarTodos` | none | `Page<StatusEmpregadoDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| GET | `/api/status-empregados/{id}` | `buscarPorId` | query/path | `ResponseEntity<StatusEmpregadoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/status-empregados` | `criar` | StatusEmpregadoDTO dto | `StatusEmpregadoDTO` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/status-empregados/{id}` | `atualizar` | StatusEmpregadoDTO dto | `ResponseEntity<StatusEmpregadoDTO>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/status-empregados/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 39. SuperintendenciaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/superintendencias` | `listar` | none | `List<SuperintendenciaDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/superintendencias` | `criar` | SuperintendenciaDTO dto | `ResponseEntity<SuperintendenciaDTO>` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/superintendencias/{id}` | `atualizar` | SuperintendenciaDTO dto | `SuperintendenciaDTO` | SIM | SIM | hasAnyAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/superintendencias/{id}/ativar` | `ativar` | query/path | `AtivacaoUsuarioAplicacaoDTO` | SIM | SIM | hasAnyAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/superintendencias/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAnyAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 40. TelefoneControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/telefones` | `listarTodos` | none | `Page<TelefoneDTO>` | NAO | NAO | authenticated | N/A | **NÃO CONSUMIR** | Sem UI: Bloqueado/legado; dados devem vir por DTOs agregados autorizados. |
| GET | `/api/telefones/{id}` | `buscarPorId` | query/path | `ResponseEntity<TelefoneDTO>` | NAO | NAO | denyAll | N/A | **NÃO CONSUMIR** | Sem UI: Endpoint bloqueado pela configuração de segurança; manter fora do frontend. |
| POST | `/api/telefones` | `criar` | TelefoneDTO dto | `TelefoneDTO` | SIM | SIM | authenticated | N/A | **NÃO CONSUMIR** | Sem UI: Bloqueado/legado; dados devem vir por DTOs agregados autorizados. |
| PUT | `/api/telefones/{id}` | `atualizar` | TelefoneDTO dto | `ResponseEntity<TelefoneDTO>` | SIM | SIM | denyAll | N/A | **NÃO CONSUMIR** | Sem UI: Endpoint bloqueado pela configuração de segurança; manter fora do frontend. |
| DELETE | `/api/telefones/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | denyAll | N/A | **NÃO CONSUMIR** | Sem UI: Endpoint bloqueado pela configuração de segurança; manter fora do frontend. |

## 41. TipoContaControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/tipos-conta` | `listarTodos` | none | `Page<TipoContaDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| GET | `/api/tipos-conta/{id}` | `buscarPorId` | query/path | `ResponseEntity<TipoContaDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/tipos-conta` | `criar` | TipoContaDTO dto | `TipoContaDTO` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/tipos-conta/{id}` | `atualizar` | TipoContaDTO dto | `ResponseEntity<TipoContaDTO>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| DELETE | `/api/tipos-conta/{id}` | `excluir` | query/path | `ResponseEntity<Void>` | SIM | SIM | hasAuthority PERFIL_ADMINISTRADOR | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 42. TipoContratacaoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/tipos-contratacao` | `listar` | none | `List<TipoContratacaoDTO>` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| GET | `/api/tipos-contratacao/{id}` | `buscarPorId` | query/path | `TipoContratacaoDTO` | NAO | NAO | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| POST | `/api/tipos-contratacao` | `criar` | TipoContratacaoDTO dto | `ResponseEntity<TipoContratacaoDTO>` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |
| PUT | `/api/tipos-contratacao/{id}` | `atualizar` | TipoContratacaoDTO dto | `TipoContratacaoDTO` | SIM | SIM | authenticated | 06 | **CONSUMIR/VALIDAR** | Estrutura/Catálogos: Integrar conforme contrato e permissões. |

## 43. UsuarioAplicacaoControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/usuarios` | `listarTodos` | none | `ResponseEntity<List<ResumoUsuarioAplicacaoDTO>>` | NAO | NAO | authenticated | 07 | **CONSUMIR/VALIDAR** | Gestão de Usuários/Meu Perfil: Integrar conforme contrato e permissões. |
| POST | `/api/usuarios` | `criar` | CriacaoUsuarioAplicacaoDTO payload | `ResponseEntity<ResumoUsuarioAplicacaoDTO>` | SIM | SIM | authenticated | 07 | **CONSUMIR/VALIDAR** | Gestão de Usuários/Meu Perfil: Integrar conforme contrato e permissões. |
| POST | `/api/usuarios/{id}/conceder-acesso-retroativo` | `concederAcessoRetroativo` | query/path | `ResponseEntity<MensagemApiDTO>` | SIM | SIM | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 07 | **CONSUMIR/VALIDAR** | Gestão de Usuários/Meu Perfil: Integrar conforme contrato e permissões. |
| POST | `/api/usuarios/{id}/revogar-acesso-retroativo` | `revogarAcessoRetroativo` | query/path | `ResponseEntity<MensagemApiDTO>` | SIM | SIM | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 07 | **CONSUMIR/VALIDAR** | Gestão de Usuários/Meu Perfil: Integrar conforme contrato e permissões. |
| POST | `/api/usuarios/{id}/redefinir-senha` | `redefinirSenha` | RedefinicaoSenhaUsuarioAplicacaoDTO payload | `ResponseEntity<ResultadoRedefinicaoSenhaDTO>` | SIM | SIM | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 07 | **CONSUMIR/VALIDAR** | Gestão de Usuários/Meu Perfil: Integrar conforme contrato e permissões. |
| PUT | `/api/usuarios/{id}` | `atualizar` | AtualizacaoUsuarioAplicacaoDTO payload | `ResponseEntity<MensagemApiDTO>` | SIM | SIM | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 07 | **CONSUMIR/VALIDAR** | Gestão de Usuários/Meu Perfil: Integrar conforme contrato e permissões. |
| GET | `/api/usuarios/meu-perfil` | `obterMeuPerfil` | none | `ResponseEntity<MeuPerfilDTO>` | NAO | NAO | authenticated | 07 | **CONSUMIR/VALIDAR** | Gestão de Usuários/Meu Perfil: Integrar conforme contrato e permissões. |
| POST | `/api/usuarios/{id}/ativar` | `ativar` | query/path | `ResponseEntity<AtivacaoUsuarioAplicacaoDTO>` | SIM | SIM | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 07 | **CONSUMIR/VALIDAR** | Gestão de Usuários/Meu Perfil: Integrar conforme contrato e permissões. |
| DELETE | `/api/usuarios/{id}` | `excluir` | query/path | `ResponseEntity<MensagemApiDTO>` | SIM | SIM | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL | 07 | **CONSUMIR/VALIDAR** | Gestão de Usuários/Meu Perfil: Integrar conforme contrato e permissões. |

## 44. VinculoContratualControlador

| Método | Rota | Java | Entrada | Retorno | CSRF | Senha | Segurança | Etapa | Decisão React | Superfície/nota |
|---|---|---|---|---|:---:|:---:|---|---:|---|---|
| GET | `/api/vinculos-contratuais` | `listar` | query/path | `Page<VinculoContratualDTO>` | NAO | NAO | authenticated | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| GET | `/api/vinculos-contratuais/{id}` | `buscar` | query/path | `VinculoContratualDTO` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| GET | `/api/vinculos-contratuais/{id}/eventos` | `eventos` | query/path | `List<EventoVinculoContratualDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| GET | `/api/vinculos-contratuais/{id}/alocacoes` | `alocacoes` | query/path | `List<AlocacaoVinculoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 12 | **CONSUMIR/VALIDAR** | Pessoa/Vínculo > Alocações: Integrar conforme contrato e permissões. |
| GET | `/api/vinculos-contratuais/{id}/alocacoes/eventos` | `eventosAlocacao` | query/path | `List<EventoAlocacaoVinculoDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 12 | **CONSUMIR/VALIDAR** | Pessoa/Vínculo > Alocações: Integrar conforme contrato e permissões. |
| GET | `/api/vinculos-contratuais/{id}/alocacoes/posicao` | `posicaoAlocacao` | query/path | `PosicaoAlocacaoTemporalDTO` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 12 | **CONSUMIR/VALIDAR** | Pessoa/Vínculo > Alocações: Integrar conforme contrato e permissões. |
| GET | `/api/vinculos-contratuais/contratos/{contratoId}/opcoes-alocacao` | `opcoesAlocacao` | query/path | `List<OpcaoAlocacaoTemporalDTO>` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 12 | **CONSUMIR/VALIDAR** | Pessoa/Vínculo > Alocações: Integrar conforme contrato e permissões. |
| GET | `/api/vinculos-contratuais/pessoas/{pessoaId}/posicao` | `posicao` | query/path | `PosicaoPessoaDTO` | NAO | NAO | hasAnyAuthority PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais` | `cadastrar` | CadastroVinculoContratualRequisicao req | `ResponseEntity<VinculoContratualDTO>` | SIM | SIM | authenticated | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/previas/retificacao-inicio` | `previaInicio` | RetificacaoInicioVinculoRequisicao req | `PreviaImpactoVinculoDTO` | SIM | NAO | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/retificar-inicio` | `retificarInicio` | RetificacaoInicioVinculoRequisicao req | `VinculoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/previas/alocacoes` | `previaAlocacao` | AlteracaoAlocacaoVinculoRequisicao req | `PreviaImpactoAlocacaoDTO` | SIM | NAO | hasAuthority PERFIL_GESTOR_LOCAL | 12 | **CONSUMIR/VALIDAR** | Pessoa/Vínculo > Alocações: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/alocacoes` | `alterarAlocacao` | AlteracaoAlocacaoVinculoRequisicao req | `AlocacaoVinculoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 12 | **CONSUMIR/VALIDAR** | Pessoa/Vínculo > Alocações: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/alocacoes/{alocacaoId}/retificar` | `retificarAlocacao` | AlteracaoAlocacaoVinculoRequisicao req | `AlocacaoVinculoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 12 | **CONSUMIR/VALIDAR** | Pessoa/Vínculo > Alocações: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/alocacoes/{alocacaoId}/cancelar-programacao` | `cancelarAlocacao` | AcaoVinculoContratualRequisicao req | `AlocacaoVinculoDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 12 | **CONSUMIR/VALIDAR** | Pessoa/Vínculo > Alocações: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/alterar-matricula` | `alterarMatricula` | AlteracaoMatriculaVinculoRequisicao req | `VinculoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/cancelar-programacao` | `cancelarProgramacao` | AcaoVinculoContratualRequisicao req | `VinculoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/desligar` | `desligar` | DesligamentoVinculoRequisicao req | `VinculoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/previas/retificacao-desligamento` | `previaDesligamento` | DesligamentoVinculoRequisicao req | `PreviaImpactoVinculoDTO` | SIM | NAO | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/retificar-desligamento` | `retificarDesligamento` | DesligamentoVinculoRequisicao req | `VinculoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/{id}/cancelar-desligamento-programado` | `cancelarDesligamento` | AcaoVinculoContratualRequisicao req | `VinculoContratualDTO` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
| POST | `/api/vinculos-contratuais/contratos/{contratoId}/tratar-fim-natural` | `tratarFimNatural` | query/path | `List<VinculoContratualDTO>` | SIM | SIM | hasAuthority PERFIL_GESTOR_LOCAL | 11 | **CONSUMIR/VALIDAR** | Pessoa > Vínculos: Integrar conforme contrato e permissões. |
