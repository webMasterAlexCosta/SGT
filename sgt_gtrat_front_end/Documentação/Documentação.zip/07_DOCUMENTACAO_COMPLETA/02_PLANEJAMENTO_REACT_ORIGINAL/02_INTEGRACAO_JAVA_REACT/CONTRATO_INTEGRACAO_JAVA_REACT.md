# SGT/GTRAT — Contrato de Integração Java ↔ React V2

**Objetivo:** transformar o contrato pós-auditoria do Java em regras concretas de implementação da camada HTTP/serviços do React.

## 1. Base URL e cookies

- O React atual usa `VITE_API_URL=/api`; os serviços normalmente chamam caminhos sem o prefixo `/api`.
- O cliente HTTP deve manter `withCredentials: true`.
- Cookies de autenticação/dispositivo são responsabilidade do servidor/browser; o React não deve tentar ler um JWT HttpOnly nem substituí-lo por token em Web Storage.

## 2. Sequência obrigatória de mutação

1. Verificar/restaurar sessão quando a rota exigir autenticação.
2. Garantir token CSRF via `GET /api/autenticacao/csrf`.
3. Montar payload estritamente conforme DTO.
4. Gerar/conservar `X-Request-Id`.
5. Quando a intenção exigir confirmação de senha, enviar `X-User-Password` somente após confirmação explícita.
6. Quando a operação oferecer chave de idempotência, gerar uma chave por intenção e conservá-la em reenvios da mesma intenção.
7. Desabilitar double-submit enquanto a intenção estiver em voo.
8. Interpretar status/código de domínio sem reduzir tudo a toast genérico.
9. Atualizar/refetch consultas dependentes usando a resposta oficial do servidor.
10. Limpar senha/token temporário de prévia após conclusão/abandono.

## 3. CSRF

O endpoint `GET /api/autenticacao/csrf` retorna o token e o nome do header. Toda mutação (`POST`, `PUT`, `PATCH`, `DELETE`) deve passar pelo coordenador CSRF central. O token não deve ser copiado para cada serviço manualmente.

### Casos a testar

- primeira mutação após abrir a SPA;
- várias mutações concorrentes durante bootstrap;
- login/logout/login;
- CSRF inválido/expirado;
- upload multipart;
- confirmação de senha seguida de retry controlado;
- erro de rede após envio de comando crítico.

## 4. Login e 2FA

Payload canônico:

```json
{"matricula":"12345678","password":"senha","totp":"123456"}
```

`skipTwoFactor` é proibido. Resposta `202` com `requiresTwoFactor=true` é estado intermediário; o contexto autenticado só é criado após o desafio ser concluído.

## 5. Autoridades canônicas

- `PERFIL_ADMINISTRADOR`
- `PERFIL_GESTOR_NACIONAL`
- `PERFIL_GESTOR_ESTADUAL`
- `PERFIL_GESTOR_LOCAL`
- `PERFIL_PRESIDENTE`
- `PERFIL_OPERACIONAL`

O React deve mapear essas autoridades para capacidades semânticas (`podeVisualizarPainel`, `podeEscreverContrato`, etc.), evitando condicionais de string distribuídas.

## 6. Matriz de segurança extraída da configuração Java

A ordem é significativa: o primeiro matcher aplicável prevalece.

| Ordem | Método | Padrões | Decisão | Autoridades |
|---:|---|---|---|---|
| 1 | TRACE | /** | denyAll |  |
| 2 | ANY | / <br> /index.html <br> /assets/** <br> /*.ico <br> /*.png <br> /*.svg <br> /*.json <br> /*.js <br> /*.css | permitAll |  |
| 3 | POST | /api/autenticacao/autenticar <br> /api/autenticacao/cadastrar <br> /api/autenticacao/encerrar-sessao <br> /api/autenticacao/recuperar-senha/solicitar <br> /api/autenticacao/recuperar-senha/confirmar | permitAll |  |
| 4 | GET | /api/autenticacao/csrf <br> /api/autenticacao/superintendencias <br> /api/autenticacao/gestoes-locais <br> /api/autenticacao/recuperar-senha/validar | permitAll |  |
| 5 | OPTIONS | /** | permitAll |  |
| 6 | ANY | /api/autenticacao/alterar-senha-inicial | authenticated |  |
| 7 | GET | /api/usuarios/meu-perfil | authenticated |  |
| 8 | ANY | /api/painel/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL |
| 9 | ANY | /api/relatorios/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL |
| 10 | ANY | /api/governanca-terceiros/** | hasAnyAuthority | PERFIL_GESTOR_LOCAL |
| 11 | GET | /api/frequencias <br> /api/frequencias/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 12 | GET | /api/frequencias/intervalo | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 13 | ANY | /api/frequencias/** | hasAnyAuthority | PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 14 | GET | /api/ocorrencias/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 15 | ANY | /api/ocorrencias/** | hasAnyAuthority | PERFIL_GESTOR_LOCAL |
| 16 | GET | /api/pessoas/*/dados-restritos | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL |
| 17 | GET | /api/pessoas/** <br> /api/vinculos-contratuais/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 18 | ANY | /api/pessoas/** <br> /api/vinculos-contratuais/** | hasAuthority | PERFIL_GESTOR_LOCAL |
| 19 | GET | /api/empregados/filtrados-frequencia | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 20 | GET | /api/status-empregados/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 21 | ANY | /api/status-empregados/** | hasAuthority | PERFIL_ADMINISTRADOR |
| 22 | GET | /api/historicos-empregados/** <br> /api/empregados/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL |
| 23 | ANY | /api/historicos-empregados/** <br> /api/empregados/** | hasAnyAuthority | PERFIL_GESTOR_LOCAL |
| 24 | ANY | /api/contas/** <br> /api/enderecos/** <br> /api/telefones/** | denyAll |  |
| 25 | POST | /api/contratos/*/documentos/*/permissoes <br> /api/contratos/*/documentos/*/permissoes/*/revogar | hasAuthority | PERFIL_ADMINISTRADOR |
| 26 | GET | /api/contratos/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 27 | ANY | /api/contratos/** | hasAuthority | PERFIL_GESTOR_LOCAL |
| 28 | GET | /api/calendario-eventos/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 29 | ANY | /api/calendario-eventos/** | hasAuthority | PERFIL_GESTOR_LOCAL |
| 30 | GET | /api/frequencias-excecoes/** <br> /api/frequencias-adicionais/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 31 | ANY | /api/frequencias-excecoes/** <br> /api/frequencias-adicionais/** | hasAuthority | PERFIL_GESTOR_LOCAL |
| 32 | ANY | /api/usuarios/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL |
| 33 | GET | /api/superintendencias/** | authenticated |  |
| 34 | GET | /api/gestoes-locais/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 35 | ANY | /api/superintendencias/** | hasAnyAuthority | PERFIL_ADMINISTRADOR |
| 36 | ANY | /api/gestoes-locais/** | hasAuthority | PERFIL_ADMINISTRADOR |
| 37 | GET | /api/lotacoes/** <br> /api/jornadas/** <br> /api/jornadas/*/regras-adicionais | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 38 | ANY | /api/lotacoes/** <br> /api/jornadas/** <br> /api/regras-adicionais/** | hasAuthority | PERFIL_GESTOR_LOCAL |
| 39 | GET | /api/bancos/** <br> /api/cargos/** <br> /api/agencias/** <br> /api/tipos-conta/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL <br> PERFIL_OPERACIONAL |
| 40 | ANY | /api/bancos/** <br> /api/cargos/** <br> /api/agencias/** <br> /api/tipos-conta/** | hasAuthority | PERFIL_ADMINISTRADOR |
| 41 | ANY | /api/registros-auditoria/** | hasAuthority | PERFIL_ADMINISTRADOR |
| 42 | GET | /api/permissoes-excepcionais/** | hasAnyAuthority | PERFIL_ADMINISTRADOR <br> PERFIL_GESTOR_NACIONAL <br> PERFIL_PRESIDENTE <br> PERFIL_GESTOR_ESTADUAL <br> PERFIL_GESTOR_LOCAL |
| 43 | ANY | /api/permissoes-excepcionais/** | hasAuthority | PERFIL_ADMINISTRADOR |
| 44 | ANY | /api/** | authenticated |  |

## 7. Status HTTP e ação do cliente

| Status | Interpretação | Ação React |
|---:|---|---|
| 200/201 | comando/consulta concluído | usar resposta oficial e invalidar consultas dependentes |
| 202 | desafio/processamento | manter estado intermediário e seguir fluxo específico |
| 204 | concluído sem corpo | finalizar ação sem acessar propriedades de resposta |
| 400 | payload/regra inválida | preservar formulário, associar fields/errors quando possível |
| 401 | sessão/autenticação inválida | interpretar `code`, encerrar contexto apenas quando aplicável |
| 403 | autorização, escopo ou CSRF | não deslogar automaticamente; distinguir contexto/código |
| 404 | recurso inexistente | mostrar estado de recurso removido/inacessível e retorno seguro |
| 409 | conflito negocial/concorrência/idempotência | exibir conflito específico e refetch/reprévia quando necessário |
| 413 | upload grande | manter metadados e pedir arquivo menor |
| 415 | mídia inválida | explicar tipo/assinatura não aceita |
| 422 | validação semântica quando usada | associar mensagens ao formulário |
| 428 | confirmação de senha requerida | abrir modal central e repetir intenção uma vez de forma controlada |
| 429 | rate limit | respeitar Retry-After/lockout e impedir spam |
| 5xx | falha servidor/resultado possivelmente incerto | não assumir rollback local; oferecer verificar estado antes de repetir comando crítico |

## 8. Temporalidade

- `LocalDate`: `YYYY-MM-DD` sem UTC.
- `YearMonth`: `YYYY-MM`.
- `Instant/conhecidoAte`: ISO-8601.
- “data efetiva” e “registrado em” são dimensões diferentes.
- Em consultas históricas, nomes/fotografias históricas não devem ser substituídos por cadastros atuais.

## 9. Pessoa, Vínculo e Alocação

- Pessoa: identidade canônica.
- Vínculo: relação Pessoa ↔ Contrato no tempo.
- Alocação: Lotação + Jornada/Turno + Cargo durante uma faixa temporal.
- Criação operacional usa `POST /api/vinculos-contratuais`, podendo criar Pessoa de forma integrada.
- Frequência pública usa `vinculoContratualId`.
- O React não deve criar um `Empregado` paralelo para servir de identidade negocial.

## 10. Prévia → confirmação

Aditamentos, remanejamentos e alterações/retificações temporais que oferecem prévia devem seguir uma máquina de estados: `EDITANDO → CALCULANDO_PREVIA → PREVIA_VALIDA → CONFIRMANDO → CONCLUIDO` ou `CONFLITO/EXPIRADA`. Qualquer alteração de campos após a prévia volta para `EDITANDO`.

## 11. Upload/download

- Multipart usa os nomes de parte definidos no controlador.
- Não fixar manualmente boundary.
- Download deve tratar `Content-Disposition`, MIME e blob.
- Documento restrito exige finalidade e autorização além do perfil.
- Conteúdo restrito não deve ser cacheado em storage persistente.

## 12. Definição de bug Java durante integração

Classificar como possível bug somente quando: (a) payload está aderente ao DTO; (b) CSRF/senha/perfil/escopo estão corretos; (c) a resposta contradiz requisito ou contrato atual; e (d) o comportamento é reproduzível. Registrar endpoint, requestId, payload redigido, resposta, usuário/perfil, data efetiva e resultado esperado.
