# Métricas da Baseline React V2 Detalhada

- Requisitos formais de implementação/checklist: **403**.
- Requisitos canônicos do Java rastreados individualmente: **198**.
- Mapeamentos HTTP inventariados: **282**.
- Controladores REST representados: **44**.
- DTOs varridos: **183**.
- Matchers de segurança extraídos: **44**.
- Endpoints com `@ExigirSenha`: **123**.
- Endpoints mutáveis sujeitos a CSRF: **154**.
- Decisões de consumo: **CONSUMIR/VALIDAR=253**, **OPCIONAL — DIAGNÓSTICO ADMIN=1**, **CONSUMIR NO BOOTSTRAP/VALIDAR=1**, **NÃO CONSUMIR=15**, **MIGRAR/EVITAR COMO FONTE CANÔNICA=4**, **CONSUMIR SOMENTE COMO PROJEÇÃO OPERACIONAL AUXILIAR=1**, **NÃO USAR NO NOVO FLUXO CANÔNICO=3**, **MIGRAR/VALIDAR COMPATIBILIDADE=4**.
- Plano de execução: **18 etapas totais** (Etapa 01 documental + 17 etapas subsequentes).

## Interpretação

Os 282 endpoints não equivalem a 282 telas. O inventário registra a decisão técnica por rota. Os 403 requisitos formais também não são “403 funcionalidades”; incluem segurança, arquitetura, UX, testes e as obrigações derivadas dos 198 requisitos de domínio Java.
