# SGT/GTRAT — Passo a Passo Operacional de Implementação do React — V3

## 1. Por que este documento existe

A V2 dizia **o que** implementar. Este documento descreve **como eu executarei o trabalho na prática**, em ordem verificável, desde o ZIP recebido até o ZIP entregue em cada etapa. Ele não substitui os 403 requisitos; funciona como procedimento operacional que impede pular análise, baseline, testes, rastreabilidade ou regressão.

## 2. Ciclo obrigatório de TODA etapa

1. **Receber e congelar entradas:** ZIP React aprovado da etapa anterior + Java baseline; calcular hashes.
2. **Extrair em diretório novo:** nunca trabalhar sobre o ZIP original.
3. **Verificar árvore e versão:** package.json, package-lock, Node, npm, arquivos alterados anteriormente.
4. **Executar baseline antes da mudança:** todos os testes disponíveis para aquela etapa. Se algo já falhar, registrar como falha preexistente antes de tocar no código.
5. **Selecionar escopo documental:** requisitos da etapa, endpoints, DTOs, matchers de segurança, gaps e testes vinculados.
6. **Ler o Java correspondente:** controller, DTO, service/regra relevante, annotations de segurança e tratamento de erro. O Java é contrato, não alvo de refatoração.
7. **Ler o React correspondente:** rotas, páginas, componentes, services, hooks, contextos e CSS Modules existentes.
8. **Classificar cada peça React:** REUTILIZAR / ADAPTAR / SUBSTITUIR / REMOVER / NOVA.
9. **Planejar uma sequência horizontal mínima:** infraestrutura/serviço → estado/hook → componente → página → rota → teste.
10. **Implementar em incrementos pequenos:** evitar reescrita ampla sem teste intermediário.
11. **Adicionar/ajustar testes junto com cada comportamento:** contrato HTTP, unitário, componente e regressão conforme o risco.
12. **Executar teste focal após cada bloco lógico.**
13. **Executar suíte da etapa.**
14. **Executar regressão acumulada das etapas anteriores.**
15. **Executar build de produção.**
16. **Executar smoke com API real quando a infraestrutura da etapa exigir e estiver disponível.**
17. **Comparar Java antes/depois:** deve permanecer byte a byte/árvore inalterado, salvo bug autorizado.
18. **Atualizar checklists:** requisito, endpoint, gap, teste, pendência, risco e evidência.
19. **Gerar documentação da etapa:** ALTERACOES, TESTES, PENDENCIAS_RISCOS, POSSIVEL_BUG_JAVA se houver.
20. **Empacotar e validar ZIP:** abrir/testar ZIP, gerar SHA-256 e entregar.

## 3. Regra de interrupção

- P0 novo: não concluir etapa enquanto não estiver resolvido ou tecnicamente bloqueado por dependência externa documentada.
- Falha de regressão: investigar antes de avançar.
- Resposta inesperada da API: primeiro revisar request/DTO/CSRF/senha/perfil/escopo/data; só depois abrir suspeita de bug Java.
- Dependência indisponível: marcar teste como **NÃO EXECUTADO POR LIMITAÇÃO DE AMBIENTE**, nunca como aprovado por inferência.

## 4. Passo a passo específico por etapa

### Etapa 02 — Higiene técnica, runtime e configuração

1. Congelar e hashear o ZIP React recebido e o ZIP Java de referência; registrar ambos como entrada da etapa.
2. Executar baseline estático do React sem mudanças: inventário, diff limpo, leitura de package.json, lockfile, .nvmrc, Vite e .env.
3. Quando as dependências offline estiverem disponíveis, executar npm ls, validate:runtime, build e suíte baseline antes de editar.
4. Classificar cada variável .env em infraestrutura, UX, teste, otimização ou regra negocial não autoritativa.
5. Identificar leituras diretas de import.meta.env espalhadas e planejar centralização sem criar dependência circular.
6. Implementar validação de tipos/faixas/defaults da configuração e precedência entre .env/config.json/backend.
7. Remover autoridade local de limites que pertencem ao Java, preservando-os apenas como dica visual quando útil.
8. Revisar Vite proxy/HTTPS/build target/output/chunks e sincronização para static do Java sem mudar o backend.
9. Adicionar testes de configuração inválida, variável ausente, NaN, boolean parsing e fail-closed de credenciais/flags.
10. Executar build, testes da etapa, análise de bundle e varredura por segredos de teste.
11. Atualizar matriz de configuração, requisitos, testes e empacotar a etapa sem alterar Java.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 03 — Core HTTP, CSRF, envelope e segurança de comandos

1. Ler no Java o contrato CSRF, envelope padrão, handlers de erro, @ExigirSenha, idempotência e DTOs de erro antes de alterar Axios.
2. Inventariar interceptors e helpers HTTP do React antigo e marcar o que será reaproveitado, substituído ou removido.
3. Definir um único cliente HTTP e um único ponto de normalização de resposta/erro, preservando status, headers, meta e requestId.
4. Implementar bootstrap CSRF deduplicado para múltiplas mutações concorrentes e armazenamento somente em memória.
5. Injetar dinamicamente o header CSRF em POST/PUT/PATCH/DELETE, sem aplicar a GET/HEAD.
6. Implementar fluxo central de 428/@ExigirSenha: capturar intenção, solicitar senha, reenviar uma única vez e descartar senha imediatamente.
7. Implementar idempotency key apenas nos comandos em que o contrato permitir; nunca repetir mutação arbitrariamente.
8. Implementar catálogo tipado/semântico para 400/401/403/404/409/413/415/422/428/429/5xx.
9. Padronizar multipart, blobs/downloads, LocalDate/Instant/YearMonth, query arrays e AbortController.
10. Adicionar testes unitários do coordenador CSRF, erro, 428, retry, idempotência e cancelamento.
11. Criar testes HTTP mockados que comprovem método/rota/header/body sem depender da API real.
12. Quando backend estiver disponível, executar smoke de GET + primeira mutação + 428 + 409 + download.
13. Rodar regressão completa e congelar esta camada antes dos módulos de domínio.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 04 — Autenticação, sessão, 2FA e autoridades

1. Ler os 20 endpoints de AutenticacaoControlador e PerfilControlador, DTOs e regras de segurança.
2. Localizar todo uso de skipTwoFactor, ROLE_*, fallback ROLE_USER e usuário autoritativo em storage.
3. Desenhar state machine de autenticação: não autenticado, credenciais aceitas, 2FA requerido, autenticado, sessão expirada/substituída.
4. Adaptar login para HTTP 202/requiresTwoFactor sem opção de pular 2FA.
5. Implementar restauração de sessão usando a API como fonte de verdade, não localStorage.
6. Mapear perfil/autoridade para seis perfis canônicos e capacidades semânticas.
7. Refatorar guards, menu e rota inicial para capacidades, mantendo backend como segurança final.
8. Implementar logout servidor + limpeza local e cenários de sessão substituída/expirada.
9. Adaptar recuperação/primeira senha/troca de senha e gerenciamento 2FA do perfil.
10. Adicionar matriz de testes dos seis perfis, deep links, 202, 401, 403 e reload.
11. Executar regressão de navegação e autenticação antes de avançar.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 05 — Shell visual, design tokens, navegação e acessibilidade base

1. Inventariar CSS global, CSS Modules, componentes de layout, sidebar, header, modais e tokens visuais do React antigo.
2. Extrair tokens Correios preservando identidade atual: cores, tipografia, espaçamento, bordas, sombras e estados.
3. Reduzir CSS global ao que é realmente global; componente novo deve usar CSS Module.
4. Padronizar shell de página, área de filtros, toolbar, tabela, vazio, loading e erro.
5. Padronizar modal/diálogo/stepper e confirmação crítica.
6. Adaptar menu desktop/mobile às capacidades implementadas na Etapa 04.
7. Adicionar Error Boundary e apresentação de requestId em falhas suportáveis.
8. Aplicar lazy loading em módulos e dependências pesadas quando mensurável.
9. Validar teclado, foco, labels, contraste e zoom 200%.
10. Executar smoke visual headless, testes de componentes e bundle.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 06 — Estrutura organizacional e catálogos

1. Listar endpoints de estrutura organizacional e catálogos previstos na etapa e seus DTOs.
2. Mapear selects e serviços legados que carregam região/UF/SE/gestão local/lotação/cargo/jornada etc.
3. Definir adaptadores de opção padrão {id,label,...metadata} sem perder campos temporais.
4. Implementar carregamento encadeado com cancelamento da requisição anterior e estados independentes.
5. Impedir que catálogo inativo hoje elimine item historicamente válido quando a API o retornar para data efetiva.
6. Padronizar paginação/busca para catálogos grandes.
7. Adaptar telas administrativas de catálogo respeitando capacidades e @ExigirSenha.
8. Testar dependências encadeadas, vazios, itens inativos, edição histórica e 403.
9. Executar smoke contra endpoints reais quando disponíveis e atualizar inventário.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 07 — Usuários, perfil e configurações administrativas

1. Inventariar endpoints de usuários/configurações administrativas, permissões e DTOs.
2. Separar perfil do usuário logado de gestão de usuários por administradores/gestores.
3. Adaptar listagem, filtros, paginação e detalhe para o contrato atual.
4. Implementar criação/alteração/desativação conforme autoridade e escopo retornados pelo backend.
5. Aplicar confirmação de senha centralizada quando exigida, sem código específico em cada tela.
6. Não inferir autorização só pelo perfil; usar capacidades para UX e resposta 403 como autoridade final.
7. Testar usuário fora de escopo, usuário inativo, conflito, 428, sessão do próprio usuário e paginação.
8. Executar regressão dos seis perfis e atualizar matriz de endpoints.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 08 — Contratos — núcleo e ciclo de vida

1. Ler entidades/DTOs/serviços/controladores do núcleo de contrato e registrar campos obrigatórios, enums, datas e transições.
2. Comparar formulário legado de contrato com DTOs atuais e criar matriz campo antigo → campo novo → removido.
3. Implementar lista/detalhe contratual antes de criar/editar, para validar leitura do contrato real.
4. Implementar criação usando DTO canônico e catálogos da Etapa 06.
5. Implementar edição somente nos estados/campos permitidos pela API.
6. Expor vigência, situação, lotações/turnos e histórico essencial sem recalcular regra no React.
7. Implementar ações de ciclo de vida como comandos explícitos com confirmação e tratamento 409/428.
8. Testar datas limite, contrato futuro, encerrado, cancelado/anulado e concorrência de atualização.
9. Executar contrato HTTP mockado para cada ação e smoke real do fluxo principal.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 09 — Contratos — composição, excedentes, aditamentos e remanejamentos

1. Ler regras de composição, excedentes, aditamentos e remanejamentos no Java e identificar operações de prévia versus confirmação.
2. Modelar UI em duas fases quando a API oferecer cálculo/prévia: calcular → revisar impacto → confirmar.
3. Implementar composição por lotação/turno/cargo respeitando temporalidade e capacidade.
4. Implementar aditamento positivo/negativo com histórico, data efetiva e justificativa.
5. Implementar excedentes sem tentar reconciliar capacidade no cliente.
6. Implementar remanejamento com origem/destino e validação de contexto alterado entre prévia e confirmação.
7. Tratar 409 como conflito negocial específico e oferecer recarregar/recalcular, não retry cego.
8. Testar dois operadores concorrentes, mesma capacidade, fatos retroativos e múltiplos aditamentos.
9. Validar que totais exibidos são resposta/projeção do Java, não soma autoritativa local.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 10 — Contratos — documentos, transferências e correções excepcionais

1. Inventariar endpoints de documentos, versões, transferências de gestão e correções excepcionais.
2. Definir componente de upload reutilizável com limites vindos/confirmados pela API e feedback de progresso.
3. Implementar listagem e versionamento documental, preservando metadados, download e erros 413/415.
4. Implementar transferências como comando crítico com prévia/confirmação se o contrato assim definir.
5. Implementar correção de identificador e outras exceções apenas para capacidades autorizadas.
6. Exigir confirmação de senha pelo mecanismo central sem armazenar credencial.
7. Testar arquivo inválido, tamanho, versão concorrente, cancelamento, 403, 409, 428 e download.
8. Executar smoke real com arquivo pequeno e comprovar integridade do blob retornado.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 11 — Pessoas e vínculos contratuais

1. Ler o modelo canônico Pessoa → Vínculo Contratual e marcar endpoints legados de Empregado que não devem criar fatos canônicos.
2. Criar adaptadores e serviços separados para pessoa e vínculo, sem reintroduzir DTO monolítico legado.
3. Implementar busca/identificação de pessoa respeitando PII e escopo.
4. Implementar criação/edição da pessoa conforme contrato, com validação no servidor como autoridade.
5. Implementar criação e ciclo de vida do vínculo contratual referenciando contrato/pessoa corretamente.
6. Expor histórico do vínculo e datas efetivas sem sobrescrever fatos antigos.
7. Migrar telas que antes esperavam empregadoId para vinculoContratualId onde o backend exige.
8. Testar duplicidade, vínculo futuro, desligamento, reativação quando permitida, 409 e retroatividade.
9. Executar busca/lista/detalhe/criação smoke real antes da Etapa 12.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 12 — Alocações temporais e opções encadeadas

1. Ler endpoints e DTOs de alocação temporal e opções dependentes por contrato/data.
2. Implementar consulta das opções encadeadas a partir de contrato, lotação, turno, cargo, jornada e data efetiva.
3. Criar formulário temporal explícito: “válido a partir de”/intervalo conforme contrato.
4. Implementar criação/alteração de alocação sem editar retroativamente a linha errada.
5. Apresentar histórico de alocações com períodos e motivo/origem quando disponível.
6. Usar AbortController e chave de contexto para impedir resposta antiga de sobrescrever seleção nova.
7. Testar último dia de vínculo, mesma data, futuro, retroativo, troca múltipla e catálogos inativos historicamente válidos.
8. Validar integração real com vínculo criado na Etapa 11.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 13 — Frequência diária, lote e operação de grande volume

1. Ler endpoints de frequência unitária/lote, limites, DTOs, fechamento e permissões.
2. Substituir dependência de empregadoId pelo identificador canônico exigido pelo Java.
3. Implementar seleção de data/lotação/turno com carregamento paginado ou em lotes adequado a >40 mil colaboradores.
4. Definir estado de linha: previsto/presente/ausente/pendente conforme resposta da API, sem inferir pendente incorretamente.
5. Implementar edição unitária e lote usando tamanho máximo da API e feedback de progresso parcial.
6. Impedir regra VITE_* de decidir janela oficial de edição; mostrar mensagem da API quando bloqueado.
7. Evitar duplo envio, preservar idempotência onde suportada e tratar timeout sem repetir cegamente.
8. Testar lote máximo, parcial, falha de um item, 403, janela expirada, ausência/pendência e concorrência.
9. Executar teste de volume controlado e medir renderização/bundle/memória.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 14 — Fechamentos, calendário, ocorrências, pendências e permissões excepcionais

1. Inventariar fechamentos, calendário, feriados/folgas, ocorrências, pendências e permissões excepcionais.
2. Implementar cada módulo sobre a camada HTTP comum, sem replicar autorização e senha.
3. Integrar fechamento assíncrono com estado/progresso/recuperação conforme API.
4. Implementar calendário e ocorrências respeitando escopo estadual/local e temporalidade.
5. Implementar pendências com filtros e ações permitidas por capacidade.
6. Implementar desbloqueios/permissões excepcionais como comandos auditáveis com confirmação.
7. Testar recuperação após reload, fechamento em andamento, falha parcial, Gestor Estadual, Operacional e 428.
8. Executar regressão cruzada com frequência da Etapa 13.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 15 — Painel e cálculos gerenciais

1. Ler DTOs/projeções do painel e identificar exatamente o que o backend calcula.
2. Não reproduzir fórmulas gerenciais autoritativas no React; limitar-se a composição visual e transformações de gráfico.
3. Implementar filtros contrato/lotação/turno/cargo/data com opção Todos e dependências dinâmicas.
4. Implementar previsto, presentes, ausentes e pendentes usando valores retornados.
5. Implementar painéis desdobrados quando Todos for selecionado conforme requisito.
6. Implementar linha, barra, dispersão e infográfico com componentes lazy quando possível.
7. Tratar polling/async/cache sem duplicar consultas e cancelar contexto antigo.
8. Testar Gestor Nacional, Presidente, Estado, data histórica, sem dados e grande volume.
9. Medir tempo de renderização e validar que indicadores não desaparecem por regra de perfil incorreta.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 16 — Relatórios, emissões e exportações

1. Inventariar endpoints de relatórios, parâmetros, jobs, downloads e formatos.
2. Implementar filtros compartilhados e serialização exata de todos/todas lotações/turnos/cargos.
3. Usar cálculo no backend; React somente solicita, acompanha e apresenta/exporta.
4. Implementar paginação 200/1000/2000/5000/Todos somente quando suportada/segura pelo contrato.
5. Implementar downloads PDF/XLSX com nome, content-type, erro e expiração.
6. Evitar geração duplicada em duplo clique; usar estado do job/identificador retornado quando aplicável.
7. Testar mensal, absenteísmo, consolidado, filtros Todos, arquivo vazio, grande e erro de geração.
8. Comparar valores exibidos versus arquivo/export do mesmo recorte.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 17 — Governança de terceiros, auditoria avançada e saneamento legado

1. Inventariar governança de terceiros, auditoria, endpoints diagnósticos e remanescentes legados.
2. Implementar somente os endpoints com decisão CONSUMIR; manter denyAll/internos fora da UI.
3. Garantir que telas de auditoria não exponham campos sensíveis mascarados pelo backend.
4. Adicionar navegação/filtros de auditoria com requestId, período e paginação adequada.
5. Remover referências finais a contratos legados identificadas nos CSVs de evidência.
6. Executar busca automática por skipTwoFactor, ROLE_*, /empregados canônico e URLs não inventariadas.
7. Revisar todos os endpoints marcados “pendente de decisão” e fechar decisão documental.
8. Executar regressão de segurança e saneamento antes do gate final.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

### Etapa 18 — Gate final pré-homologação

1. Congelar código e gerar hash do candidato final.
2. Executar npm ls, validate:runtime, nomenclatura, todas as suítes Vitest, análise estática, cobertura e build.
3. Executar smoke headless no Chromium e validar rotas principais, assets e console.
4. Com backend real disponível, executar matriz de integração dos fluxos críticos por perfil.
5. Executar matriz dos seis perfis e escopos, incluindo deep links e respostas 403.
6. Executar cenários obrigatórios 409/428/429, CSRF, sessão substituída, timeout e concorrência.
7. Executar temporalidade: passado/futuro/retroativo/mesma data/último dia.
8. Executar volume de frequência, painel e relatórios com massa suficiente.
9. Conferir 403 requisitos: nenhum P0/P1 crítico em aberto.
10. Conferir 282 endpoints: cada um com decisão final e todos os consumidos cobertos/rastreados.
11. Confirmar zero alteração no Java ou documentar separadamente bug/fix autorizado.
12. Gerar relatório final pré-homologação, pendências residuais, hashes e ZIP candidato.

**Saída obrigatória:** código + testes + evidências + atualização documental + ZIP; Java inalterado salvo bug formalmente autorizado.

## 5. Estratégia de commits/diffs internos

Mesmo que a entrega ao usuário seja em ZIP, internamente a alteração deve ser separável por assunto. Para revisão, manterei diffs coerentes: infraestrutura HTTP não misturada com redesenho visual; contrato/DTO não misturado com limpeza cosmética; teste que prova o requisito no mesmo bloco lógico da mudança.

## 6. Como saberei que uma etapa terminou

Uma etapa só termina quando quatro perguntas têm resposta positiva:

1. **Implementação:** todos os requisitos P0/P1 do escopo estão implementados ou explicitamente bloqueados?
2. **Evidência:** os testes compatíveis com o ambiente foram realmente executados e registrados?
3. **Regressão:** etapas anteriores continuam passando?
4. **Rastreabilidade:** consigo apontar requisito → código/tela → endpoint/DTO → teste → resultado?

Se qualquer resposta for “não”, a etapa não será apresentada como concluída.
