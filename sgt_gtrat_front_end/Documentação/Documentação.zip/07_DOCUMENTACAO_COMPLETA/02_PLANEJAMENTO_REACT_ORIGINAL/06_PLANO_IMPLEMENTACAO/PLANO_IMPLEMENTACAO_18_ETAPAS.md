# SGT/GTRAT — Plano de Implementação React V3 — 18 Etapas Detalhadas + Procedimento Operacional

> **Complemento operacional V3:** este plano define o escopo e os gates. A ordem de execução real, passo a passo, está em `10_EXECUCAO_OPERACIONAL/SGT_GTRAT_REACT_PASSO_A_PASSO_IMPLEMENTACAO_V3.md`. O ambiente e as dependências necessárias estão em `10_EXECUCAO_OPERACIONAL/SGT_GTRAT_AMBIENTE_EXECUCAO_DEPENDENCIAS_V3.md`.

**Princípio:** a V1 tinha 13 macroetapas; a V2 mantém o mesmo objetivo funcional, mas decompõe riscos em **18 gates executáveis**. Etapa 01 é documental; após aprovação restam 17 etapas de implementação/validação.

## Regras gerais de execução

- iniciar sempre do ZIP aprovado da etapa anterior;  
- não alterar Java salvo bug reproduzível;  
- nenhuma etapa ignora regressões críticas do gate anterior;  
- todo código novo deve atualizar teste, rastreabilidade e inventário;  
- cada etapa entrega ZIP + alterações + testes + pendências/riscos + status dos requisitos/endpoints;  
- P0 impede avanço; P1 do domínio impede concluir o domínio; P2 pode avançar somente com justificativa registrada.

## Etapa 01 — Baseline documental V2

### Objetivo

Congelar a especificação de frontend antes de qualquer alteração de código e estabelecer rastreabilidade verificável.

### Pré-requisito

Pacotes Java e React antigos analisados.

### Checklist de implementação

- [ ] Consolidar requisitos transversais de arquitetura, segurança, UX, performance e testes.
- [ ] Mapear os 198 requisitos canônicos do backend para obrigações frontend.
- [ ] Inventariar 282 mapeamentos HTTP, DTOs e regras de segurança.
- [ ] Inventariar rotas, serviços e evidências de contrato legado no React.
- [ ] Classificar gaps em P0/P1/P2 e definir regra de congelamento do Java.
- [ ] Definir etapas, gates e artefatos de entrega.

### Escopo de API previsto

- Etapa predominantemente documental/infraestrutura; não possui grupo próprio de endpoints de domínio no inventário.

### Testes mínimos da etapa

- [ ] Validar contagens e consistência dos CSVs/MDs.
- [ ] Garantir que nenhum arquivo Java/React foi modificado.

### Gate de saída

**Documentação V2 aprovada como baseline; nenhuma implementação iniciada.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 02 — Higiene técnica, runtime e configuração

### Objetivo

Preparar uma base previsível de build/configuração sem permitir que variáveis locais decidam regras negociais.

### Pré-requisito

Etapa 01 aprovada.

### Checklist de implementação

- [ ] Revisar package.json, engines, Vite e scripts para Node 22.
- [ ] Classificar todas as VITE_* conforme matriz de configuração.
- [ ] Separar configuração de infraestrutura, UX, teste e regras não autoritativas.
- [ ] Eliminar uso autoritativo de VITE_FREQUENCIA_EDIT_WINDOW_HOURS e equivalentes.
- [ ] Definir bootstrap de /config.json e sua precedência, se mantido.
- [ ] Garantir fail-closed para credenciais de teste e feature flags de produção.
- [ ] Definir budgets de bundle e estratégia de lazy load.
- [ ] Atualizar documentação .env.example sem segredo.
- [ ] Adicionar validações de configuração inválida/NaN/faixas impossíveis.

### Escopo de API previsto

- **1 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `ConfiguracaoSistemaControlador` (1).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] npm install/build em Node 22.
- [ ] validate:runtime.
- [ ] varredura de bundle/config por credenciais de teste.
- [ ] testes de precedência de configuração.

### Gate de saída

**Build limpo e configuração classificada; regra negocial crítica não depende de VITE_*.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 03 — Core HTTP, CSRF, envelope e segurança de comandos

### Objetivo

Tornar a camada HTTP aderente ao contrato pós-auditoria antes de qualquer expansão funcional.

### Pré-requisito

Etapa 02 aprovada.

### Checklist de implementação

- [ ] Implementar coordenador CSRF com deduplicação de bootstrap.
- [ ] Injetar token no headerName retornado pelo backend para POST/PUT/PATCH/DELETE.
- [ ] Preservar envelope, meta, status e requestId ao normalizar respostas.
- [ ] Reestruturar catálogo de erros 400/401/403/404/409/413/415/422/428/429/5xx.
- [ ] Criar fluxo central de confirmação de senha X-User-Password.
- [ ] Criar representação de intenção para replay controlado após 428.
- [ ] Definir gerador e ciclo de vida de chave de idempotência.
- [ ] Revisar retry policy: GET seguro; mutações somente quando explicitamente seguras.
- [ ] Padronizar multipart e downloads.
- [ ] Padronizar serialização LocalDate, YearMonth, Instant e arrays.
- [ ] Implementar suporte a AbortSignal e resposta fora de ordem.
- [ ] Sanitizar logs/erros para não expor senha, headers ou PII.

### Escopo de API previsto

- Etapa predominantemente documental/infraestrutura; não possui grupo próprio de endpoints de domínio no inventário.

### Testes mínimos da etapa

- [ ] primeira mutação com CSRF
- [ ] CSRF expirado/renovado
- [ ] várias mutações concorrentes no bootstrap
- [ ] 428 + senha correta/incorreta/cancelamento
- [ ] 409 com conflito específico
- [ ] 429/Retry-After
- [ ] timeout após mutação não idempotente
- [ ] multipart/download
- [ ] cancelamento de busca
- [ ] requestId preservado

### Gate de saída

**Nenhuma mutação futura precisa implementar CSRF/senha/idempotência por conta própria.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 04 — Autenticação, sessão, 2FA e autoridades

### Objetivo

Substituir integralmente o contrato legado de autenticação/roles pelo contrato canônico do Java.

### Pré-requisito

Etapa 03 aprovada.

### Checklist de implementação

- [ ] Remover skipTwoFactor de serviço, contexto, formulário e testes.
- [ ] Implementar state machine do login incluindo HTTP 202/requiresTwoFactor.
- [ ] Remover ROLE_* como autoridade canônica e mapear seis PERFIL_*.
- [ ] Eliminar fallback ROLE_USER e user autoritativo em Web Storage.
- [ ] Restaurar sessão por /autenticacao/sessao e /usuarios/meu-perfil.
- [ ] Implementar logout servidor + limpeza local.
- [ ] Revisar renovação/heartbeat/inatividade para não concorrer.
- [ ] Tratar SESSION_REPLACED/EXPIRED/INVALID/DEVICE/ACCOUNT codes.
- [ ] Adaptar cadastro/solicitação de acesso com superintendência→gestão local.
- [ ] Validar recuperação de senha e primeira senha.
- [ ] Adaptar 2FA de perfil: status/configurar/ativar/desativar.
- [ ] Criar capacidades semânticas centralizadas e rota inicial por perfil.

### Escopo de API previsto

- **20 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `AutenticacaoControlador` (12), `PerfilControlador` (8).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] login sem 2FA
- [ ] login 202 + TOTP correto/incorreto
- [ ] sem opção de pular 2FA
- [ ] reload com sessão válida/inválida
- [ ] logout
- [ ] sessão substituída
- [ ] alteração de senha sem logout artificial
- [ ] seis perfis e rota inicial
- [ ] deep link não autorizado

### Gate de saída

**Zero skipTwoFactor/ROLE_* canônico; matriz dos seis perfis passa.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 05 — Shell visual, design tokens, navegação e acessibilidade base

### Objetivo

Preservar o design Correios, reduzir inconsistência visual e preparar shell para os novos módulos.

### Pré-requisito

Etapa 04 aprovada.

### Checklist de implementação

- [ ] Consolidar tokens CSS de cores, espaçamento, tipografia, radius, sombra e estados.
- [ ] Revisar index.css e reduzir utilidades globais específicas de componente.
- [ ] Padronizar layout de página: título, ações, filtros, loading, vazio, erro.
- [ ] Adaptar sidebar/header/mobile às capacidades canônicas.
- [ ] Criar padrão de modal, confirmação crítica e stepper de prévia/confirmação.
- [ ] Criar error boundary e tela de falha recuperável.
- [ ] Padronizar suporte/requestId em erros.
- [ ] Revisar lazy loading de rotas e dependências pesadas.
- [ ] Garantir teclado, foco, zoom 200% e labels base.

### Escopo de API previsto

- Etapa predominantemente documental/infraestrutura; não possui grupo próprio de endpoints de domínio no inventário.

### Testes mínimos da etapa

- [ ] snapshots/componentes principais
- [ ] navegação teclado
- [ ] menu por perfil desktop/mobile
- [ ] error boundary
- [ ] lazy routes
- [ ] bundle budget

### Gate de saída

**Shell comum estável e acessível; módulos seguintes não precisam reinventar estrutura visual.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 06 — Estrutura organizacional e catálogos

### Objetivo

Realinhar filtros e cadastros mestres ao escopo/permissões e à validade temporal do Java.

### Pré-requisito

Etapas 03–05 aprovadas.

### Checklist de implementação

- [ ] Integrar Superintendências e Gestões Locais por escopo.
- [ ] Preservar visão da estrutura por região.
- [ ] Adaptar Lotação, Jornada/Turno, Cargo, Tipo de Contratação, Regra Adicional, Banco, Agência, Tipo de Conta, Status e Motivos aplicáveis.
- [ ] Distinguir leitura histórica de opção válida para nova operação.
- [ ] Implementar ativação/inativação/reativação conforme endpoints disponíveis.
- [ ] Desabilitar escrita para perfis somente leitura.
- [ ] Limpar selects dependentes ao mudar escopo.
- [ ] Padronizar paginação/filtros e erros de vínculos/uso futuro.

### Escopo de API previsto

- **53 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `AgenciaControlador` (5), `BancoControlador` (5), `CargoControlador` (5), `GestaoLocalControlador` (4), `JornadaControlador` (5), `LotacaoControlador` (6), `RegraAdicionalControlador` (4), `StatusEmpregadoControlador` (5), `SuperintendenciaControlador` (5), `TipoContaControlador` (5), `TipoContratacaoControlador` (4).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] Admin vs Gestor Local vs leitura
- [ ] catálogo inativo hoje porém válido historicamente
- [ ] inativação bloqueada por programação futura
- [ ] reativação
- [ ] selects encadeados
- [ ] 403 por perfil

### Gate de saída

**Catálogos/escopo prontos para contratos, vínculos e frequência.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 07 — Usuários, perfil e configurações administrativas

### Objetivo

Concluir administração de identidade/aplicação sem contrato role legado e com segurança uniforme.

### Pré-requisito

Etapas 03–06 aprovadas.

### Checklist de implementação

- [ ] Migrar gestão de usuários para perfil/autoridade canônicos.
- [ ] Criar/editar/ativar/desativar/redefinir senha com confirmação central.
- [ ] Integrar concessão/revogação de acesso retroativo.
- [ ] Revalidar sessão/menu após mudança do próprio perfil/estado.
- [ ] Concluir avatar e 2FA de perfil com limpeza de dados sensíveis.
- [ ] Integrar configurações administrativas do sistema se mantidas na UI.
- [ ] Preservar auditoria e mensagens de senha temporária sem exposição persistente.

### Escopo de API previsto

- **19 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `ConfiguracaoSistemaControlador` (2), `PerfilControlador` (8), `UsuarioAplicacaoControlador` (9).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] CRUD usuário autorizado
- [ ] redefinição senha encerra sessões conforme resposta
- [ ] ativar/desativar
- [ ] acesso retroativo
- [ ] perfil alterado com SPA aberta
- [ ] avatar multipart
- [ ] config admin

### Gate de saída

**Administração de usuários/perfil aderente e sem roles legados.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 08 — Contratos — núcleo e ciclo de vida

### Objetivo

Transformar a tela de contratos de CRUD simples em representação do ciclo de vida temporal do domínio.

### Pré-requisito

Catálogos e segurança aprovados.

### Checklist de implementação

- [ ] Criar lista/resumo e detalhe contratual com identificação, empresa, vigência, gestão, situação temporal/negocial, habilitação e pendências.
- [ ] Implementar rascunho, criação e edição somente quando permitida.
- [ ] Implementar publicação com dados/composição requeridos.
- [ ] Implementar timeline de eventos, precedências, versões e posição temporal.
- [ ] Implementar inativação e reativação administrativa como eventos distintos.
- [ ] Implementar encerramento antecipado, cancelamento futuro e anulação.
- [ ] Implementar descarte físico apenas de rascunho elegível.
- [ ] Exibir data efetiva/data do ato/registro de forma distinta.
- [ ] Aplicar leitura nacional de Presidente/Gestor Nacional e escrita apenas autorizada.

### Escopo de API previsto

- **16 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `ContratoControlador` (16).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] rascunho incompleto
- [ ] publicação
- [ ] edição após publicação negada
- [ ] inativar/reativar
- [ ] encerrar antecipadamente
- [ ] cancelar futuro
- [ ] anular
- [ ] delete rascunho
- [ ] posição temporal/conhecidoAte
- [ ] matriz perfis

### Gate de saída

**Ciclo de vida contratual completo e rastreável.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 09 — Contratos — composição, excedentes, aditamentos e remanejamentos

### Objetivo

Implementar a parte de maior impacto operacional do contrato com prévias e validação de capacidade no servidor.

### Pré-requisito

Etapa 08 aprovada.

### Checklist de implementação

- [ ] Exibir composição explícita Lotação+Jornada+Cargo+efetivo por período.
- [ ] Implementar inclusão/alteração de composição conforme API.
- [ ] Exibir monitor de excedentes e desde-quando/justificativas quando fornecidos.
- [ ] Implementar aditamento: listar, prévia, registrar, retificar, cancelar programação.
- [ ] Implementar remanejamento: listar, prévia, registrar, retificar, cancelar programação.
- [ ] Representar impacto de redução abaixo da ocupação e bloqueio autoritativo.
- [ ] Não mover pessoas automaticamente no cliente.
- [ ] Invalidar prévia ao editar campos e refazer em 409/contexto alterado.

### Escopo de API previsto

- **15 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `AditamentoContratualControlador` (5), `ComposicaoContratualControlador` (5), `RemanejamentoContratualControlador` (5).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] soma de composição
- [ ] efetivo zero
- [ ] excedente permitido/confirmado
- [ ] capacidade zero bloqueada
- [ ] redução abaixo ocupação
- [ ] prévia expirada
- [ ] concorrência de ocupação
- [ ] retificação/cancelamento futuros

### Gate de saída

**Capacidade e mudanças de composição não podem ser concluídas com estado local desatualizado.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 10 — Contratos — documentos, transferências e correções excepcionais

### Objetivo

Cobrir documentos versionados, acesso restrito e ações excepcionais que não cabem no CRUD comum.

### Pré-requisito

Etapas 08–09 aprovadas.

### Checklist de implementação

- [ ] Criar módulo de documentos por contrato com metadados, arquivo e SEI.
- [ ] Implementar multipart metadados+arquivo opcional, download e verificação de estados.
- [ ] Exibir eventos/cadeia de versões documental.
- [ ] Implementar retificar SEI, substituir/acrescentar anexo, invalidar e descartar rascunho elegível.
- [ ] Implementar finalidade para PESSOAL_RESTRITO.
- [ ] Implementar concessão/revogação/lista de permissões e acessos conforme perfil.
- [ ] Implementar transferência excepcional de Gestão com mapeamentos e histórico.
- [ ] Implementar correção de identificador contratual e histórico pesquisável.
- [ ] Implementar correção de anulação por relação CANCELA/evento precedente sem “reativar” silenciosamente.

### Escopo de API previsto

- **19 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `ContratoControlador` (3), `CorrecaoIdentificadorContratoControlador` (3), `DocumentoComprobatorioControlador` (13).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] upload arquivo/SEI/ambos
- [ ] 413/415
- [ ] download
- [ ] documento restrito com/sem finalidade
- [ ] permissão admin
- [ ] substituição/versionamento
- [ ] transferência incompleta atomicamente bloqueada
- [ ] correção identificador
- [ ] corrigir anulação

### Gate de saída

**Ações excepcionais permanecem versionadas/auditáveis e dados restritos não vazam.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 11 — Pessoas e vínculos contratuais

### Objetivo

Migrar o cadastro operacional para a identidade canônica Pessoa + Vínculo e eliminar escrita negocial baseada em Empregado.

### Pré-requisito

Contratos/catálogos prontos.

### Checklist de implementação

- [ ] Remodelar rota/tela /empregados para Pessoas/Vínculos ou introduzir navegação canônica sem perder UX útil.
- [ ] Implementar listagem Pessoa paginada com busca, contratoId e ativoEm.
- [ ] Implementar detalhe Pessoa e dados restritos com finalidade/permissão.
- [ ] Implementar correções de identidade apenas pelos comandos autorizados.
- [ ] Implementar criação integrada de Vínculo com pessoa existente ou nova Pessoa embutida.
- [ ] Consultar opções de alocação/capacidade antes de criar vínculo.
- [ ] Implementar confirmação de inclusão excedente com justificativa/evidência/autorização.
- [ ] Implementar eventos/posição do vínculo, matrícula e retificação de início.
- [ ] Implementar desligar, prévia/retificar desligamento, cancelar desligamento programado e fim natural.
- [ ] Classificar endpoints Empregado restantes como projeção/compatibilidade e impedir POST/PUT canônico.

### Escopo de API previsto

- **32 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `EmpregadoControlador` (4), `HistoricoEmpregadoControlador` (4), `MotivoDesligamentoControlador` (4), `PessoaControlador` (6), `VinculoContratualControlador` (14).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] Pessoa paginação estável
- [ ] nova Pessoa+Vínculo
- [ ] Pessoa existente+Vínculo
- [ ] CPF/conflito concorrente
- [ ] excedente Gestor Local
- [ ] capacidade zero
- [ ] matrícula
- [ ] retificação início
- [ ] desligamento retroativo/futuro
- [ ] fim natural

### Gate de saída

**Zero criação/edição canônica por /empregados; IDs Pessoa/Vínculo governam o fluxo.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 12 — Alocações temporais e opções encadeadas

### Objetivo

Representar corretamente Lotação+Jornada+Cargo como faixas temporais do vínculo.

### Pré-requisito

Etapa 11 aprovada.

### Checklist de implementação

- [ ] Listar alocações por mês e eventos.
- [ ] Consultar posição da alocação por data e conhecidoAte.
- [ ] Implementar opções encadeadas contrato→lotação→jornada→cargo na data efetiva.
- [ ] Gerar prévia de alteração de alocação.
- [ ] Confirmar alteração com token/contexto da prévia.
- [ ] Retificar faixa na mesma data preservando versão anterior.
- [ ] Cancelar programação futura restaurando predecessora.
- [ ] Implementar confirmarPrecedenciaUltimoDia quando data efetiva coincide com último dia do vínculo.
- [ ] Exibir incompatibilidades e não criar lacuna/sobreposição localmente.

### Escopo de API previsto

- **8 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `VinculoContratualControlador` (8).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] troca interna sem novo vínculo
- [ ] retroativa com eventos posteriores
- [ ] retificação mesma data
- [ ] cancelamento futuro
- [ ] catálogo inativo histórico
- [ ] conhecidoAte
- [ ] último dia + desligamento
- [ ] opções sem efetivo

### Gate de saída

**Linha temporal de alocação reproduz o backend e não depende da alocação atual.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 13 — Frequência diária, lote e operação de grande volume

### Objetivo

Migrar frequência para vinculoContratualId e estados oficiais do backend, preservando usabilidade para grande efetivo.

### Pré-requisito

Etapas 11–12 aprovadas.

### Checklist de implementação

- [ ] Migrar payload individual/lote para vinculoContratualId.
- [ ] Usar endpoint de projeção de empregados somente se necessário para grade operacional, sem identidade paralela.
- [ ] Implementar filtros por data, contrato, lotação, jornada/turno e busca conforme API.
- [ ] Exibir previsto/lançado/pendente e estados de validade/revisão quando fornecidos.
- [ ] Remover autoridade local da janela de edição e seguir resposta/regras Java.
- [ ] Implementar lançamento individual e em lote com chunking somente se compatível com endpoint.
- [ ] Tratar jornada noturna pela data de início.
- [ ] Bloquear double-submit e preservar falhas parciais do lote de forma explicável.
- [ ] Otimizar renderização/paginação para >40 mil colaboradores sem carregar DOM inteiro.

### Escopo de API previsto

- **7 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `EmpregadoControlador` (1), `FrequenciaControlador` (6).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] Operacional dentro/fora janela
- [ ] Gestor Local retificação
- [ ] lote
- [ ] data noturna
- [ ] vínculo sem alocação válida
- [ ] desligamento retroativo
- [ ] registro sujeito a revisão
- [ ] 40k+ volume sintético
- [ ] 403 escopo

### Gate de saída

**Frequência canônica, escalável e sem regra crítica local conflitante.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 14 — Fechamentos, calendário, ocorrências, pendências e permissões excepcionais

### Objetivo

Completar fluxos de exceção e saneamento que influenciam frequência/relatórios.

### Pré-requisito

Etapa 13 aprovada.

### Checklist de implementação

- [ ] Integrar fechamentos de frequência, itens, status e reprocessamento conforme endpoints.
- [ ] Adaptar calendário de feriados/folgas por perfil/escopo.
- [ ] Adaptar ocorrências e anexos com leitura/escrita corretas.
- [ ] Integrar frequências exceções e adicionais.
- [ ] Criar central de pendências com filtros, resumo, iniciar tratamento e confirmar resolução.
- [ ] Integrar permissões excepcionais, revogação e usos.
- [ ] Tratar finalidade e expiração de permissão na UI.
- [ ] Vincular pendência às telas de contrato/vínculo/frequência quando houver referência.

### Escopo de API previsto

- **29 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `CalendarioEventoControlador` (4), `FechamentoFrequenciaControlador` (5), `FrequenciaAdicionalControlador` (4), `FrequenciaExcecaoControlador` (4), `OcorrenciaControlador` (4), `PendenciaAdministrativaControlador` (4), `PermissaoExcepcionalControlador` (4).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] fechamento e retificação
- [ ] reprocessamento
- [ ] Gestor Estadual visualiza calendário permitido
- [ ] Operacional leitura autorizada
- [ ] ocorrência anexada
- [ ] pendência tratada/resolvida
- [ ] permissão expirada/revogada
- [ ] dados restritos após revogação

### Gate de saída

**Exceções/pendências não escapam da trilha de auditoria e autorização.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 15 — Painel e cálculos gerenciais

### Objetivo

Realinhar o painel visual existente aos filtros/autoridades e cálculos atuais do Java.

### Pré-requisito

Frequência/pendências suficientemente estáveis.

### Checklist de implementação

- [ ] Validar os endpoints de painel e cálculo assíncrono.
- [ ] Implementar filtros canônicos de contrato/lotação/jornada/cargo/data conforme respostas reais.
- [ ] Manter seleção Todos e painéis separados por item quando requisito exigir.
- [ ] Exibir previsto, presentes, ausentes e pendentes sem recalcular autoridade no browser.
- [ ] Suportar navegação temporal entre dias.
- [ ] Garantir Gestor Nacional/Presidente com leitura nacional e Gestor Estadual por escopo.
- [ ] Eliminar regressão que exige refresh para refletir filtros/estado.
- [ ] Manter linhas/barras/dispersão/infográfico somente quando dados permitem e tabela alternativa acessível.
- [ ] Adaptar exportação do painel ao mesmo recorte.

### Escopo de API previsto

- **8 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `PainelCalculoControlador` (2), `PainelControlador` (6).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] cinco perfis gerenciais
- [ ] todos filtros/composições
- [ ] data passada/futura válida
- [ ] Todos + detalhamentos
- [ ] cálculo 202/poll
- [ ] sem refresh
- [ ] conferência API↔gráfico↔tabela
- [ ] performance

### Gate de saída

**Indicadores conferem com API no mesmo recorte e todas as visões atualizam reativamente.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 16 — Relatórios, emissões e exportações

### Objetivo

Garantir que relatórios e arquivos sejam versões do mesmo recorte oficial, incluindo pendências e temporalidade.

### Pré-requisito

Etapas 13–15 aprovadas.

### Checklist de implementação

- [ ] Revalidar frequência mensal, consolidada, absenteísmo, terceirizados e demais endpoints do RelatorioControlador.
- [ ] Implementar paginação e filtros para todos/lotação/turno/cargo/contrato conforme API.
- [ ] Preservar opções de página grandes apenas quando backend suportar e sem congelar navegador.
- [ ] Implementar exportações PDF/XLSX com feedback e recorte idêntico à tela.
- [ ] Integrar relatório administrativo: prévia, emissão, versões/conhecimento/comparação conforme endpoints.
- [ ] Exibir sujeito a revisão/quantidade de pendências quando informado.
- [ ] Impedir Presidente de emissão formal se @PreAuthorize negar, mantendo leitura nacional.
- [ ] Validar relatórios noturnos e grandes volumes.

### Escopo de API previsto

- **22 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `RelatorioAdministrativoControlador` (6), `RelatorioControlador` (16).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] todos perfis autorizados
- [ ] Presidente read-only
- [ ] mensal/absenteísmo todos filtros
- [ ] página 200/1000/2000/5000/Todos quando suportado
- [ ] PDF/XLSX
- [ ] pendência sujeita revisão
- [ ] emissão retificada
- [ ] conhecidoAte/versões
- [ ] grande volume

### Gate de saída

**Tela, total e exportação conferem; emissão formal respeita perfil e versão.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 17 — Governança de terceiros, auditoria avançada e saneamento legado

### Objetivo

Fechar módulos periféricos, limpar compatibilidade e assegurar decisão explícita para cada endpoint/gap.

### Pré-requisito

Módulos principais implementados.

### Checklist de implementação

- [ ] Adaptar governança de terceiros à camada CSRF/senha/perfil atual.
- [ ] Validar RegistroAuditoria admin e detalhes sem PII excessiva.
- [ ] Decidir se CacheDiagnostico terá UI técnica; caso contrário marcar não consumir.
- [ ] Revisar HistóricoEmpregado e outras projeções legadas, substituindo por histórico canônico quando possível.
- [ ] Remover imports/funções ROLE_* residuais.
- [ ] Remover skipTwoFactor residual e mutações /empregados.
- [ ] Executar diff do inventário de endpoints contra Java atual.
- [ ] Marcar os 282 endpoints como integrado, não consumir justificado, legado auxiliar ou bloqueado.
- [ ] Fechar P0/P1 da matriz de gaps e registrar P2 remanescente aceito.

### Escopo de API previsto

- **31 endpoints** associados diretamente a esta etapa no inventário V2.
- Controladores: `CacheDiagnosticoControlador` (1), `EmpregadoControlador` (4), `GovernancaTerceirosControlador` (20), `HistoricoEmpregadoControlador` (4), `RegistroAuditoriaControlador` (2).
- A lista endpoint por endpoint, com método, DTO, senha, CSRF e decisão, está em `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_INVENTARIO_V2_DETALHADO.md`.

### Testes mínimos da etapa

- [ ] governança completa
- [ ] auditoria admin
- [ ] grep contratos legados
- [ ] inventário endpoint decision completo
- [ ] security matcher diff
- [ ] testes arquiteturais

### Gate de saída

**Zero P0/P1; todo endpoint e requisito possui decisão/status explícito.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Etapa 18 — Gate final pré-homologação

### Objetivo

Validar o React completo contra o Java atual e produzir candidato rastreável à homologação.

### Pré-requisito

Etapas 02–17 aprovadas.

### Checklist de implementação

- [ ] Executar suíte unitária, componente, comportamento, robustez, estática e bundle.
- [ ] Executar build Node 22 e empacotamento/static quando aplicável.
- [ ] Executar smoke contra JAR Java atual com sessão/CSRF real.
- [ ] Executar matriz dos seis perfis e escopos.
- [ ] Executar cenários temporais/concorrência/arquivos/grande volume.
- [ ] Validar acessibilidade e responsividade das rotas principais.
- [ ] Comparar 198 requisitos canônicos e 282 endpoints com status final.
- [ ] Gerar relatório de bugs Java comprovados separadamente, se houver.
- [ ] Gerar ZIP candidato e MD final de aderência/limitações.

### Escopo de API previsto

- Etapa predominantemente documental/infraestrutura; não possui grupo próprio de endpoints de domínio no inventário.

### Testes mínimos da etapa

- [ ] suite completa
- [ ] smoke real Java
- [ ] performance/bundle
- [ ] a11y
- [ ] matriz requisitos/endpoints
- [ ] checagem de segredos

### Gate de saída

**Candidato a homologação funcional; Gate B de infraestrutura/produção do backend permanece separado.**

### Entregáveis

- `SGT_GTRAT_REACT_ETAPA_XX.zip`;  
- `ALTERACOES_ETAPA_XX.md`;  
- `TESTES_ETAPA_XX.md`;  
- `PENDENCIAS_RISCOS_ETAPA_XX.md`;  
- atualização de requisitos/rastreabilidade;  
- atualização de decisão dos endpoints da etapa;  
- registro separado de possível bug Java, quando aplicável.

## Dependências e caminho crítico

`02 → 03 → 04 → 05` forma a fundação. `06` alimenta contratos/vínculos. `08 → 09/10` fecha contratos. `11 → 12 → 13` fecha identidade/alocação/frequência. `13/14` alimentam a validação de `15/16`. `17` saneia legado e inventário antes do `18`.

## Critério para alterar Java durante estas etapas

Não corrigir o backend por conveniência do React. Abrir bug somente com: endpoint/método, payload redigido, perfil/escopo, CSRF/senha, requestId, resposta, requisito esperado, repetição e evidência de que o comportamento contradiz a baseline Java atual.