# SGT/GTRAT — Matriz Detalhada de Gaps React Legado × Java Atual V2

## Escala

- **P0-FE:** deve ser corrigido antes de desenvolver módulos negociais sobre a base.
- **P1-FE:** necessário para o módulo correspondente ficar aderente.
- **P2-FE:** melhoria/robustez que entra antes do Gate final.
- **Preservar:** base atual útil, apenas adaptar contrato.
- **Substituir:** contrato atual do React é incompatível conceitualmente.

| ID | Prioridade | Área | Evidência no React atual | Contrato Java atual | Decisão de implementação | Gate |
|---|---|---|---|---|---|---|
| GAP-001 | P0-FE | CSRF | camada HTTP não contém fluxo CSRF | toda mutação exige token obtido em `/api/autenticacao/csrf` | implementar coordenador CSRF central antes de qualquer nova mutação | Etapa 03 |
| GAP-002 | P0-FE | 2FA | `skipTwoFactor` existe em serviço/contexto/testes | parâmetro removido; 2FA ativo é obrigatório | remover campo e redesenhar state machine de login 202 | Etapa 04 |
| GAP-003 | P0-FE | Perfis | `ROLE_ADMIN`, `ROLE_USER`, `ROLE_SUPERINTENDENCIA`, etc. | seis `PERFIL_*` canônicos | substituir módulo de roles por capacidades derivadas de autoridade atual | Etapa 04 |
| GAP-004 | P0-FE | Envelope HTTP | interceptor pode retornar somente `parsed.data` | metadados/requestId podem ser necessários | preservar envelope/meta com contrato de resposta consistente | Etapa 03 |
| GAP-005 | P0-FE | Erro 409 | mensagem fixa sugere duplicidade/CPF | 409 cobre conflito temporal, concorrência, idempotência, estado | criar catálogo por code/contexto e permitir reprévia/refetch | Etapa 03 |
| GAP-006 | P0-FE | Confirmação de senha | header existe, fluxo ainda é distribuído | 123 mapeamentos inventariados usam `@ExigirSenha` | criar coordenador central de intenção + modal + replay controlado | Etapa 03 |
| GAP-007 | P0-FE | Pessoa/Vínculo | CRUD `/empregados` ainda é central | Pessoa + Vínculo + Alocação são canônicos | remodelar módulo; bloquear novas mutações canônicas por `/empregados` | Etapas 10-11 |
| GAP-008 | P0-FE | Frequência | serviços/telas derivam parte das regras localmente | frequência pública exige `vinculoContratualId` e temporalidade Java | migrar identidade, janela e estados para contrato da API | Etapa 12 |
| GAP-009 | P1-FE | Contratos | tela atual cobre CRUD básico | Java possui ciclo de vida, eventos, versões, transferências, correções | decompor em visão geral + submódulos/ações temporais | Etapas 08-10 |
| GAP-010 | P1-FE | Composição | UX atual não cobre toda temporalidade/capacidade | composição, excedente, aditamento e remanejamento possuem prévias e regras | implementar fluxos em duas fases com impacto/capacidade | Etapa 09 |
| GAP-011 | P1-FE | Documentos | cobertura insuficiente | 13 endpoints de documentos, versionamento, acesso restrito | criar módulo documental com multipart, versões, permissões e acessos | Etapa 10 |
| GAP-012 | P1-FE | Pendências | ausência/integração parcial | `/api/pendencias` possui listar/resumo/tratamento/resolução | central de pendências por escopo e vínculo com entidades | Etapa 14 |
| GAP-013 | P1-FE | Presidente | regras antigas confundem presidente/gestão nacional | leitura nacional; sem escrita/emissão formal | capacidades específicas e testes negativos | Etapa 04/16 |
| GAP-014 | P1-FE | Gestor Nacional | perfil não existe no contrato legado de roles | autoridade canônica com leitura nacional | incluir em guards, filtros, painel e relatórios | Etapa 04+ |
| GAP-015 | P1-FE | Gestor Estadual | `ROLE_SUPERINTENDENCIA` legado | `PERFIL_GESTOR_ESTADUAL` | migrar nomenclatura e escopo | Etapa 04+ |
| GAP-016 | P1-FE | Temporalidade | várias telas usam estado corrente/CRUD | Java expõe posição/eventos/conhecidoAte | adicionar UX de data efetiva, timeline e posição temporal | Etapas 08-13 |
| GAP-017 | P1-FE | Catálogos | telas atuais tratam cadastros majoritariamente como estado atual | ativação/inativação/reativação temporal | adaptar formulários/listas e opções históricas | Etapa 06 |
| GAP-018 | P1-FE | Relatórios | boa base visual/exportação local | API inclui emissão administrativa/versões/pendências | alinhar recorte, versão e exportação ao backend | Etapa 16 |
| GAP-019 | P1-FE | Painel | boa base, mas filtros/perfis legados | API autorizada a cinco perfis gerenciais e cálculo assíncrono | migrar guards e fontes; eliminar necessidade de refresh | Etapa 15 |
| GAP-020 | P1-FE | Dados restritos | proteção baseada sobretudo em perfil | finalidade/permissão excepcional/auditoria | fluxo explícito de finalidade e limpeza de dados | Etapas 11/14 |
| GAP-021 | P2-FE | Configuração | `.env` contém regras de negócio locais | backend é autoridade | classificar/remover uso autoritativo de vars negociais | Etapa 02 |
| GAP-022 | P2-FE | Storage | user/estado aparece em session/local storage em pontos do legado | sessão deve vir do servidor/cookies | limitar storage a preferências e motivos não autoritativos | Etapa 04 |
| GAP-023 | P2-FE | Bundle | dependências pesadas podem entrar no inicial | módulos podem ser lazy | revisar chunks de gráficos/PDF/face-api | Etapa 05/17 |
| GAP-024 | P2-FE | Observabilidade | requestId é gerado, mas não é uma UX consistente | backend usa rastreabilidade | mostrar/copiar requestId em erro/suporte | Etapa 03 |
| GAP-025 | P2-FE | Inventário | serviços legados não cobrem 282 mapeamentos atuais | API atual expandiu | todo endpoint recebe decisão: integrar, interno, legado, não aplicável | Gate 17 |
