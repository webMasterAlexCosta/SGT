# SGT/GTRAT — Inventário Detalhado do React Atual

## 1. Baseline técnica

- React: `19.2.8`  
- React Router: `^7.18.2`  
- Vite: `8.2.0`  
- Axios: `^1.19.0`  
- Node engine: `>=22.0.0 <25`  
- JSX em src: **142**  
- JS em src: **62**  
- CSS Modules: **113**  
- serviços JS: **29**  
- arquivos de teste no diretório test: **55**

## 2. Rotas atuais

| Rota | Componente | Decisão V2 |
|---|---|---|
| `/` | `Navigate` | preservar bootstrap; atualizar auth |
| `/perfil` | `PaginaPerfil` | preservar/adaptar contrato atual |
| `/painel` | `Painel` | preservar/evoluir |
| `/frequencia` | `PaginaFrequencia` | preservar/evoluir para vínculo canônico |
| `/ocorrencias` | `PaginaOcorrencias` | preservar/adaptar segurança |
| `/contratos` | `PaginaContratos` | expandir profundamente |
| `/governanca-terceiros` | `PaginaGovernancaTerceiros` | preservar/adaptar segurança |
| `/empregados` | `ListaEmpregados` | remodelar para Pessoas/Vínculos/Alocações |
| `/relatorios` | `PaginaRelatoriosTerceirizados` | preservar/evoluir |
| `/relatorio-mensal` | `PaginaRelatorioFrequencia` | preservar/evoluir |
| `/relatorio-absenteismo` | `PaginaRelatorioAbsenteismo` | preservar/evoluir |
| `/gestao-usuarios` | `PaginaUsuarios` | preservar/migrar perfil |
| `/calendario-folgas` | `PaginaCalendarioFolgas` | preservar/evoluir |
| `/lotacoes` | `PaginaLotacoes` | preservar/evoluir temporalidade |
| `/turnos` | `PaginaTurnos` | preservar visual; integrar Jornada |
| `/estrutura-organizacional` | `PaginaEstruturaOrganizacional` | preservar/evoluir escopo |
| `/logs` | `PaginaRegistrosAuditoria` | preservar/admin |
| `/cargos` | `CadastroGenerico` | preservar/evoluir catálogo |
| `/bancos` | `CadastroGenerico` | preservar/admin |
| `/agencias` | `PaginaAgencias` | preservar/admin |
| `/tipos-conta` | `CadastroGenerico` | preservar/admin |
| `*` | `Navigate` | revisar |

## 3. Evidências de contratos/decisões a revisar

| Padrão | Arquivo | Linha | Evidência resumida |
|---|---|---:|---|
| `skipTwoFactor` | `src/services/auth/ServicoAutenticacao.js` | 27 | `autenticar: async (matricula, password, totp, skipTwoFactor = false) => {` |
| `skipTwoFactor` | `src/services/auth/ServicoAutenticacao.js` | 32 | `data: { matricula, password, totp: totp // undefined, skipTwoFactor: skipTwoFactor // undefined },` |
| `skipTwoFactor` | `src/modules/auth/context.jsx` | 449 | `const efetuarLogin = async (matricula, password, totp, skipTwoFactor = false) => {` |
| `skipTwoFactor` | `src/modules/auth/context.jsx` | 451 | `const dadosRetorno = await ServicoAutenticacao.autenticar(matricula, password, totp, skipTwoFactor);` |
| `ROLE_ADMIN` | `src/core/security/roles.js` | 4 | `ADMIN: "ROLE_ADMIN",` |
| `ROLE_USER` | `src/core/security/roles.js` | 8 | `USER: "ROLE_USER",` |
| `ROLE_USER` | `src/services/auth/ServicoAutenticacao.js` | 41 | `role: res.role // "ROLE_USER",` |
| `ROLE_USER` | `src/modules/auth/context.jsx` | 52 | `perfil?.roles // base?.roles // base?.role // "ROLE_USER",` |
| `ROLE_USER` | `src/modules/auth/context.jsx` | 54 | `const role = roles[0] // "ROLE_USER";` |
| `ROLE_SUPERINTENDENCIA` | `src/core/security/roles.js` | 6 | `SUPERINTENDENCIA: "ROLE_SUPERINTENDENCIA",` |
| `ROLE_GESTOR_LOCAL` | `src/core/security/roles.js` | 7 | `GESTOR_LOCAL: "ROLE_GESTOR_LOCAL",` |
| `/empregados` | `src/services/rh/ServicoOcorrencia.js` | 53 | `buscarEmpregados: async (search, options = {}) => extrairLista(await requisitar({ method: 'GET', url: '/empregados', params: { search }, ...options })),` |
| `/empregados` | `src/services/rh/ServicoEmpregado.js` | 12 | `url: '/empregados',` |
| `/empregados` | `src/services/rh/ServicoEmpregado.js` | 24 | `return requisitarTodasAsPaginas({ url: '/empregados', params: cleanFilters, options });` |
| `/empregados` | `src/services/rh/ServicoEmpregado.js` | 46 | `url: '/empregados/resumo',` |
| `/empregados` | `src/services/rh/ServicoEmpregado.js` | 66 | `buscarPaginadosParaFrequencia: async (params, options = {}) => requisitar({ method: 'GET', url: '/empregados/filtrados-frequencia', params, ...options }),` |
| `/empregados` | `src/services/rh/ServicoEmpregado.js` | 68 | `url: '/empregados/filtrados-frequencia', params, options, otimizarContagem: true,` |
| `/empregados` | `src/services/rh/ServicoEmpregado.js` | 71 | `buscarPorId: async (id, options = {}) => requisitar({ method: 'GET', url: `/empregados/${id}`, ...options }),` |
| `/empregados` | `src/services/rh/ServicoEmpregado.js` | 75 | `url: empregado.id ? `/empregados/${empregado.id}` : '/empregados',` |
| `/empregados` | `src/services/rh/ServicoEmpregado.js` | 81 | `excluir: async (id, options = {}) => requisitar({ method: 'DELETE', url: `/empregados/${id}`, successMessage: 'Empregado removido.', ...options }),` |
| `/empregados` | `src/services/rh/ServicoEmpregado.js` | 107 | `buscarHistoricoContrato: async (id, options = {}) => requisitar({ method: 'GET', url: `/empregados/${id}/historico-contratos`, ...options }),` |
| `/empregados` | `src/Aplicacao.jsx` | 189 | `rh: ["/empregados", "/frequencia", "/ocorrencias", "/governanca-terceiros"].some((rota) =>` |
| `/empregados` | `src/Aplicacao.jsx` | 213 | `rh: estadoAtual.rh // ["/empregados", "/frequencia", "/ocorrencias", "/governanca-terceiros"].some((rota) => caminhoAtual.startsWith(rota)),` |
| `/empregados` | `src/Aplicacao.jsx` | 245 | `["/empregados", permissoes.empregados],` |
| `/empregados` | `src/Aplicacao.jsx` | 318 | `{permissoes.empregados && <Route path="/empregados" element={<ListaEmpregados onNavigate={lidarComNavegacao} />} />}` |
| `/empregados` | `src/modules/painel/components/FerramentasGestao/index.jsx` | 244 | `perfil.podeVisualizarEmpregados && { rota: "/empregados", rotulo: "Empregados", icone: Users },` |
| `/empregados` | `src/Leiaute/BarraLateral/index.jsx` | 91 | `<ItemNavegacao icone={Users} rotulo="Cadastro de empregados" id="/empregados" ativo={localizacao.pathname === "/empregados"} aoNavegar={onNavigate} />` |
| `withCredentials` | `src/core/http.js` | 65 | `withCredentials: true,` |
| `X-User-Password` | `src/core/http/configuracaoRequisicaoAxios.js` | 49 | `cabecalhos['X-User-Password'] = String(senhaConfirmacao);` |
| `localStorage` | `src/hooks/usePulsoAtividade.js` | 20 | `const valor = Number(localStorage.getItem(chave));` |
| `localStorage` | `src/hooks/usePulsoAtividade.js` | 29 | `localStorage.setItem(chave, String(valor));` |
| `localStorage` | `src/modules/rh/pages/EmpregadosLista/visualizacao.js` | 38 | `: lerModoVisualizacao(window.localStorage);` |
| `localStorage` | `src/modules/rh/pages/EmpregadosLista/useEmpregadosLista.js` | 67 | `? lerContratosFavoritos(window.localStorage)` |
| `localStorage` | `src/modules/rh/pages/EmpregadosLista/useEmpregadosLista.js` | 106 | `salvarModoVisualizacao(window.localStorage, modoVisualizacao);` |
| `localStorage` | `src/modules/rh/pages/EmpregadosLista/useEmpregadosLista.js` | 112 | `salvarContratosFavoritos(window.localStorage, contratosFavoritos);` |
| `localStorage` | `src/services/perfil/ServicoPerfil.js` | 37 | `if (res?.fotoUrl) localStorage.setItem('sgt_foto_url', res.fotoUrl);` |
| `localStorage` | `src/modules/AtualizacaoModulo/index.jsx` | 135 | `sessionStorage.getItem("user") // localStorage.getItem("user");` |
| `localStorage` | `src/modules/auth/context.jsx` | 191 | `localStorage.setItem(chaveArmazenamentoFoto, usuarioMesclado.fotoUrl);` |
| `localStorage` | `src/modules/auth/context.jsx` | 279 | `localStorage.removeItem(chaveArmazenamentoUsuario);` |
| `localStorage` | `src/modules/auth/context.jsx` | 280 | `localStorage.removeItem(chaveArmazenamentoFoto);` |
| `localStorage` | `src/modules/auth/context.jsx` | 284 | `localStorage.removeItem(chaveArmazenamentoUsuario);` |
| `localStorage` | `src/modules/auth/context.jsx` | 285 | `localStorage.removeItem(chaveArmazenamentoFoto);` |
| `localStorage` | `src/modules/auth/context.jsx` | 294 | `localStorage.removeItem(chaveArmazenamentoUsuario);` |
| `localStorage` | `src/modules/auth/context.jsx` | 295 | `localStorage.removeItem(chaveArmazenamentoFoto);` |
| `localStorage` | `src/modules/auth/context.jsx` | 316 | `localStorage.removeItem(chaveArmazenamentoUsuario);` |
| `localStorage` | `src/modules/auth/context.jsx` | 333 | `localStorage.setItem(` |
| `localStorage` | `src/modules/auth/pages/Login/index.jsx` | 71 | `const salvo = localStorage.getItem(chaveStorageDesempenho);` |
| `localStorage` | `src/modules/auth/pages/Login/index.jsx` | 78 | `localStorage.setItem(chaveStorageDesempenho, String(proximoValor));` |
| `localStorage` | `src/modules/perfil/pages/PaginaPerfil/index.jsx` | 72 | `localStorage.getItem("sgt_foto_url") // user?.fotoUrl,` |
| `localStorage` | `src/modules/rh/pages/PaginaFrequencia/components/TabelaFrequencia.jsx` | 554 | `const valorSalvo = localStorage.getItem("sgt_frequencia_virtualizacao");` |
| `localStorage` | `src/modules/rh/pages/PaginaFrequencia/components/TabelaFrequencia.jsx` | 595 | `localStorage.setItem(` |
| `localStorage` | `src/Leiaute/Cabecalho/components/AcoesCabecalho.jsx` | 8 | `const fotoSalva = localStorage.getItem(chaveArmazenamentoFoto) // usuario?.fotoUrl;` |
| `localStorage` | `src/core/ui/HomologacaoModal.jsx` | 13 | `const dadosExpiracao = localStorage.getItem(CHAVE_ARMAZENAMENTO);` |
| `localStorage` | `src/core/ui/HomologacaoModal.jsx` | 20 | `localStorage.removeItem(CHAVE_ARMAZENAMENTO);` |
| `localStorage` | `src/core/ui/HomologacaoModal.jsx` | 34 | `localStorage.setItem(CHAVE_ARMAZENAMENTO, JSON.stringify(expiraEm));` |
| `localStorage` | `src/core/ui/LembreteSegundoFator/index.jsx` | 32 | `limparLembrete2FA(localStorage, chaveArmazenamento);` |
| `localStorage` | `src/core/ui/LembreteSegundoFator/index.jsx` | 38 | `localStorage,` |
| `localStorage` | `src/core/ui/LembreteSegundoFator/index.jsx` | 50 | `localStorage,` |
| `localStorage` | `src/core/ui/LembreteSegundoFator/index.jsx` | 101 | `localStorage,` |
| `sessionStorage` | `src/core/events.js` | 54 | `sessionStorage.setItem('logout_reason', JSON.stringify(payload));` |
| `sessionStorage` | `src/Aplicacao.jsx` | 398 | `return sessionStorage.getItem(chaveArmazenamentoIntro) === "true";` |
| `sessionStorage` | `src/Aplicacao.jsx` | 409 | `sessionStorage.setItem(chaveArmazenamentoIntro, "true");` |
| `sessionStorage` | `src/Aplicacao.jsx` | 411 | `sessionStorage.removeItem(chaveArmazenamentoIntro);` |
| `sessionStorage` | `src/modules/AtualizacaoModulo/index.jsx` | 135 | `sessionStorage.getItem("user") // localStorage.getItem("user");` |
| `sessionStorage` | `src/modules/auth/pages/Login/index.jsx` | 109 | `const erroCacheado = sessionStorage.getItem("logout_reason");` |
| `sessionStorage` | `src/modules/auth/pages/Login/index.jsx` | 111 | `sessionStorage.removeItem("logout_reason");` |
| `sessionStorage` | `src/core/exportacao/context.jsx` | 13 | `const valor = JSON.parse(sessionStorage.getItem(CHAVE_SESSAO) // "[]");` |
| `sessionStorage` | `src/core/exportacao/context.jsx` | 23 | `sessionStorage.setItem(CHAVE_SESSAO, JSON.stringify(ids));` |

## 4. Avaliação da infraestrutura HTTP atual

- **Reaproveitar:** cliente Axios central, `withCredentials`, requestId, serializador, retry policy, mensagens base, cancelamento.  
- **Adaptar obrigatoriamente:** preservação de envelope/meta, CSRF central, 403/409/428 por domínio, retry de comandos, rastreabilidade de requestId.  
- **Já existe parcialmente:** `X-User-Password` em `configuracaoRequisicaoAxios.js`; deve virar fluxo central integrado a 428/@ExigirSenha.  
- **Ausente na varredura de src:** referência explícita a CSRF, embora o Java atual exija token em mutações.

## 5. Configuração local que não pode ser fonte de verdade

Variáveis como `VITE_FREQUENCIA_EDIT_WINDOW_HOURS`, limites administrativos e metas de absenteísmo podem continuar como preferência/UX somente quando não conflitarem com a API. Janela de edição, capacidade, vigência, escopo e autorização devem ser decididos pelo Java.
