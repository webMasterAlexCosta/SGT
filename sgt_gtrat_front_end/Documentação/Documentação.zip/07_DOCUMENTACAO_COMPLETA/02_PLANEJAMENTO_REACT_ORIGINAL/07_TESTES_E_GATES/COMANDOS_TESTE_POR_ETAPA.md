# SGT/GTRAT — Comandos e Gates de Teste por Etapa — V3

## 1. Pré-check de ambiente

```bash
node --version        # esperado: v22.16.0
npm --version         # esperado: 10.9.2
npm ls --all
npm run validate:runtime
```

Se `node_modules` ainda não estiver disponível, `npm ls`/scripts serão registrados como não executáveis.

## 2. Baseline React já previsto no package.json

```bash
npm run validar:nomenclatura
npm run test
npm run test:componentes
npm run test:camada2
npm run test:camada3:vitest
npm run test:qualidade:estatica
npm run test:integridade
npm run test:bundle
npm run test:completo
npm run test:tudo-com-build
npm run build
```

Nem todo comando precisa ser repetido após cada arquivo; a regra é: teste focal durante desenvolvimento, suíte da etapa ao fechar um bloco e `test:tudo-com-build` no gate final quando o baseline estiver saudável.

## 3. Smoke headless disponível sem dependência E2E extra

Com Vite/preview em execução e dependências npm presentes, o Chromium do sistema pode validar carregamento básico:

```bash
chromium --headless --no-sandbox --disable-gpu --dump-dom http://127.0.0.1:5173/
```

Isso **não substitui E2E interativo**. Para cliques/fluxos complexos, será adicionada uma ferramenta própria apenas se decidirmos formalmente incluí-la.

## 4. Integração HTTP

Com backend real disponível, `curl` já existe no ambiente e pode ser usado para smoke de status/headers/cookies/CSRF. Fluxos completos serão preferencialmente automatizados no próprio conjunto de testes do React ou em coleção de contrato; não dependeremos de Postman GUI.

## 5. Matriz mínima por etapa

| Etapa | Unitário/estático | Componente | Contrato HTTP mockado | Build | Browser headless | Java real |
|---|---|---|---|---|---|---|
| 02 | obrigatório | seletivo | seletivo | obrigatório | seletivo | não obrigatório |
| 03 | obrigatório | seletivo | **obrigatório** | obrigatório | seletivo | recomendado |
| 04 | obrigatório | **obrigatório** | **obrigatório** | obrigatório | recomendado | recomendado |
| 05 | obrigatório | **obrigatório** | não central | obrigatório | **obrigatório** | não obrigatório |
| 06-12 | obrigatório | obrigatório | **obrigatório** | obrigatório | recomendado | **recomendado/obrigatório no gate do domínio** |
| 13-16 | obrigatório | obrigatório | **obrigatório** | obrigatório | recomendado | **obrigatório para fechar o domínio** |
| 17 | **obrigatório** | seletivo | obrigatório | obrigatório | recomendado | recomendado |
| 18 | **tudo** | **tudo** | **tudo** | **obrigatório** | **obrigatório** | **obrigatório para pré-homologação full-stack** |

## 6. Critério para dizer “teste passou”

Registrar sempre:

- comando exato;
- data/hora;
- Node/npm;
- hash/versão do React;
- hash/versão do Java quando envolvido;
- número de testes executados;
- falhas/ignorados;
- duração quando disponível;
- limitação do ambiente;
- evidência/arquivo de relatório gerado.

“Li o código e parece correto” não é equivalente a “teste passou”.
