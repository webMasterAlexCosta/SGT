# SGT/GTRAT — Estratégia de Testes e Gates do React V2

## 1. Pirâmide de validação

1. **Estático/arquitetural:** nomenclatura, imports, URLs, contratos proibidos, bundle, configuração.
2. **Unitário:** mappers, formatters, guards, CSRF coordinator, idempotência, reducers/state machines.
3. **Componente:** formulários, modais, tabelas, estados loading/erro/vazio, acessibilidade.
4. **Contrato HTTP mockado:** método, rota, query, DTO, status e headers.
5. **Integração com Java atual:** smoke dos fluxos principais contra JAR/API real.
6. **Regressão por perfil:** seis perfis + escopos.
7. **Performance:** páginas grandes, frequência, painel, relatórios/exportação.

## 2. Gates invariantes

- zero `skipTwoFactor` no contrato;
- zero `ROLE_*` canônico;
- zero mutação sem CSRF;
- zero senha persistida;
- zero criação canônica por `/empregados`;
- todos os endpoints consumidos constam do inventário;
- todos os requisitos backend 198 possuem status/rastreabilidade;
- nenhum botão crítico depende somente de ocultação para segurança;
- 409/428/429 possuem cenário de teste;
- datas temporais possuem casos retroativos/futuros/mesma data;
- Presidente não escreve/emite formalmente quando proibido;
- Gestor Estadual/Nacional não recebem escrita negocial por engano;
- Operacional não ultrapassa escopo/janela de frequência.

## 3. Casos de concorrência obrigatórios

- duplo clique;
- resposta antiga chegando depois da nova busca;
- prévia calculada e contexto alterado antes de confirmar;
- dois operadores tentando ocupar a mesma capacidade;
- timeout após comando possivelmente concluído;
- sessão substituída durante mutação;
- CSRF renovado durante uma operação;
- alteração de perfil enquanto SPA está aberta.

## 4. Casos temporais obrigatórios

- fato retroativo com eventos posteriores;
- contrato futuro/cancelado/anulado;
- último dia de vínculo + alteração de alocação;
- desligamento retroativo;
- jornada atravessando meia-noite;
- consulta com e sem `conhecidoAte`;
- catálogo hoje inativo mas válido na data histórica;
- retificação de retificação.

## 5. Evidência por etapa

Cada `TESTES_ETAPA.md` deve registrar comando, ambiente, versão Node, versão do ZIP Java usado, quantidade de testes, falhas, casos manuais, endpoints exercitados e limitações do ambiente. Não declarar integração MySQL/browser real se ela não tiver sido executada.
