# Resumo executivo e decisões consolidadas

## Objetivo do projeto frontend

Evoluir o React legado para consumir o backend Java escalonado, sem reescrever desnecessariamente o que já funciona visualmente e sem transportar regras negociais do backend para o navegador.

## Estratégia

O trabalho será incremental, com gates. Primeiro estabiliza-se a infraestrutura de runtime/configuração e o cliente HTTP; depois autenticação/autorização; em seguida estrutura visual e módulos negociais. Cada etapa deve encerrar com build, testes focais, regressão acumulada e atualização da rastreabilidade.

## Pontos de incompatibilidade já identificados

- modelo legado de perfis/roles do React deve ser alinhado aos perfis canônicos do Java;
- fluxo legado que permite `skipTwoFactor` não deve permanecer;
- mutações devem respeitar o mecanismo CSRF do backend;
- operações protegidas por confirmação de senha devem enviar o mecanismo exigido pelo Java;
- erros de domínio e status HTTP como 409/428/429 devem ser tratados semanticamente;
- Pessoa → Vínculo Contratual → Alocação temporal é o modelo canônico novo, evitando reconstruir fluxos principais sobre o domínio legado de Empregado;
- regras negociais não devem ficar duplicadas em `.env` ou lógica local do React quando o Java já é fonte de verdade.

## Macroetapas

O plano consolidado possui 18 etapas no total. A Etapa 01 é documentação e preparação. As Etapas 02 a 18 cobrem implementação, integração e auditoria final.

A divisão detalhada, dependências, testes mínimos, controladores envolvidos e gate de saída estão em `06_PLANO_IMPLEMENTACAO/PLANO_IMPLEMENTACAO_18_ETAPAS.md` e `PASSO_A_PASSO_OPERACIONAL_ETAPAS_02_A_18.md`.

## Regra de alteração do Java

Não alterar o backend por conveniência do frontend. Diante de falha, verificar primeiro contrato, DTO/payload, CSRF, autenticação, autorização, escopo, confirmação de senha, temporalidade e regra negocial. Só abrir correção Java quando houver contradição reproduzível entre implementação e contrato/requisito.

## Ambiente de frontend

Baseline definida: Node 22.16.0 e npm 10.9.2. O cache npm Linux offline já foi validado reconstruindo dependências sem rede e executando build e testes. `node_modules` não precisa ser enviado.

## Dependências futuras

JAR Java e MySQL serão solicitados quando o primeiro gate de integração real exigir. JDK 17, Maven 3.9.16 e `.m2` só são necessários para certificação/rebuild do backend ou investigação de bug Java. Redis apenas nos testes que realmente dependam dele.
