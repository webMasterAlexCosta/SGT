# SGT/GTRAT — Planejamento consolidado da implementação React

**Objetivo:** evoluir o frontend React antigo para consumir integralmente o backend Java atual, preservando a identidade visual Correios e utilizando **React + CSS Modules, sem Tailwind**.

Este pacote é a **versão consolidada e limpa** do planejamento. Ele substitui, para uso cotidiano, os pacotes V1/V2/V3 anteriores. Os arquivos históricos e duplicados foram deliberadamente removidos para evitar dúvida sobre qual documento usar.

## Fonte de verdade

1. O backend Java atual e sua documentação são a fonte de verdade da API e das regras negociais.
2. O React antigo é referência de design, navegação e funcionalidades que podem ser reaproveitadas, não de contrato de API.
3. O Java não deve ser alterado para acomodar comportamento legado do React. Alteração de backend só deve ocorrer diante de bug reproduzível.
4. A implementação deve ser rastreada requisito por requisito e endpoint por endpoint.

## Escopo documental consolidado

A baseline documental contém:

- 403 requisitos formais de implementação frontend identificados no levantamento consolidado;
- rastreabilidade dos requisitos do backend para o React;
- inventário detalhado dos 282 mapeamentos HTTP identificados no Java analisado;
- contrato de integração Java ↔ React;
- catálogo de DTOs e regras de segurança relevantes;
- inventário do React legado e matriz de gaps;
- plano de implementação em 18 etapas;
- passo a passo operacional das Etapas 02 a 18;
- estratégia de testes, gates e comandos;
- ambiente e dependências offline;
- matriz de configuração frontend.

## Ordem recomendada de leitura

1. `01_REQUISITOS/REQUISITOS_IMPLEMENTACAO_DETALHADOS.md`
2. `02_INTEGRACAO_JAVA_REACT/CONTRATO_INTEGRACAO_JAVA_REACT.md`
3. `04_REACT_ATUAL_E_GAPS/MATRIZ_GAPS_REACT_ANTIGO_X_JAVA_ATUAL.md`
4. `06_PLANO_IMPLEMENTACAO/PLANO_IMPLEMENTACAO_18_ETAPAS.md`
5. `06_PLANO_IMPLEMENTACAO/PASSO_A_PASSO_OPERACIONAL_ETAPAS_02_A_18.md`
6. `03_API_JAVA/INVENTARIO_ENDPOINTS_JAVA_DETALHADO.md`
7. `05_RASTREABILIDADE/RASTREABILIDADE_BACKEND_REACT.md`
8. `07_TESTES_E_GATES/ESTRATEGIA_TESTES_E_GATES.md`
9. `08_AMBIENTE_E_DEPENDENCIAS/STATUS_AMBIENTE_OFFLINE_VALIDADO_2026-09-11.md`

## Estrutura

### 01_REQUISITOS
Especificação detalhada e checklist operacional dos requisitos frontend.

### 02_INTEGRACAO_JAVA_REACT
Contrato técnico de integração, incluindo autenticação, autorização, CSRF, erros, envelope, confirmação de senha e regras que não podem permanecer como decisão local do frontend.

### 03_API_JAVA
Inventário da API, DTOs, matchers/regras de segurança e decisão de consumo de cada endpoint pelo React.

### 04_REACT_ATUAL_E_GAPS
Levantamento do React legado e diferenças em relação ao Java atual.

### 05_RASTREABILIDADE
Mapeamento entre requisito backend, requisito frontend e evidência/implementação esperada.

### 06_PLANO_IMPLEMENTACAO
Plano das 18 etapas e sequência operacional detalhada para implementação.

### 07_TESTES_E_GATES
Critérios de validação, regressão e comandos previstos por etapa.

### 08_AMBIENTE_E_DEPENDENCIAS
Dependências necessárias para execução, estratégia offline e situação já validada do cache npm Linux.

### 09_CONFIGURACAO_FRONTEND
Classificação das configurações de frontend e distinção entre infraestrutura/UI e regras que pertencem ao backend.

### 10_GOVERNANCA
Baseline e hashes do pacote consolidado.

## Decisões técnicas principais

- React sem Tailwind.
- CSS Modules como padrão de estilo local.
- CSS global apenas para reset, tokens e estilos realmente globais.
- Node 22.16.0 e npm 10.9.2 como baseline operacional do frontend.
- `npm ci` como instalação reprodutível; não usar `npm install` para alterar silenciosamente o lock durante os gates.
- Cache npm Linux offline validado; não é necessário transportar `node_modules`.
- Java atual permanece inalterado salvo bug comprovado.
- Integração real com MySQL/JAR Java entra somente quando o gate da etapa exigir.

## Situação da Etapa 01

A Etapa 01 é exclusivamente documental e de preparação. Nenhum código React ou Java deve ser considerado alterado por este pacote.

A próxima etapa de implementação é a **Etapa 02 — higiene técnica, runtime e configuração**, seguida pela **Etapa 03 — core HTTP, CSRF, envelope e segurança de comandos**.
