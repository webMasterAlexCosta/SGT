# SGT/GTRAT — Status do ambiente offline React

## Situação atual

O ambiente offline para evolução do React foi preparado e validado em Linux x86_64 com:

- Node.js 22.16.0;
- npm 10.9.2;
- instalação pelo `package-lock.json` via `npm ci`;
- cache npm Linux dedicado;
- instalação posterior com `npm ci --offline` usando apenas o cache;
- 229 pacotes instalados na baseline observada;
- build Vite executado com sucesso;
- 2.942 módulos transformados no build observado;
- suíte Vitest da baseline executada com 3 arquivos de teste e 20 testes aprovados;
- 0 vulnerabilidades reportadas pelo `npm ci` da baseline.

## Decisão operacional

O `node_modules` não precisa ser enviado entre sessões. A instalação deve ser reconstruída a partir do `package-lock.json` utilizando o cache npm Linux validado.

Pacote preparado para reutilização entre sessões:

`SGT_GTRAT_REACT_DEPENDENCIAS_OFFLINE_LINUX_NODE22.16.0.zip`

Esse pacote contém o cache npm Linux compactado, manifesto do ambiente e hashes de integridade.

## O que enviar quando uma nova sessão de implementação React começar

1. ZIP mais recente do projeto React.
2. `SGT_GTRAT_REACT_DEPENDENCIAS_OFFLINE_LINUX_NODE22.16.0.zip`.
3. `node-v22.16.0-linux-x64.tar.xz` apenas se o ambiente da sessão não possuir Node 22.16.0 disponível.

## O que não precisa ser enviado no início

- `node_modules`;
- MySQL;
- Maven;
- repositório `.m2`;
- JDK 17;
- Redis.

Essas dependências devem ser solicitadas somente quando o gate da etapa exigir integração real com o backend ou investigação de possível defeito Java.

## Regra para backend Java

O backend Java atual é tratado como contrato aprovado. O React deve adaptar-se a ele. O Java só deve ser alterado quando houver evidência reproduzível de bug do backend, após exclusão de erro de payload, CSRF, autenticação, autorização, escopo, confirmação de senha e regra negocial.

## Quando pedir dependências adicionais

### JAR Java + MySQL
Solicitar no primeiro gate que exigir integração React → API → banco real.

### JDK 17
Solicitar somente quando for necessário certificar execução exatamente em Java 17 ou recompilar/testar o backend nessa versão.

### Maven 3.9.16 + `.m2`
Solicitar somente se for necessário recompilar o backend ou investigar/corrigir um provável bug Java em ambiente sem acesso externo a repositórios Maven.

### Redis
Solicitar somente em cenários que realmente dependam do comportamento de cache/infraestrutura Redis.
