# SGT/GTRAT — Como preparar dependências offline para meu ambiente — V3

## Objetivo

Permitir que eu execute `npm ci`/build/Vitest sem acesso ao registry externo e, quando necessário, compile/teste o backend Java sem acesso ao Maven Central.

## React — opção preferida

Gere as dependências em um Linux x86_64/glibc com as versões **Node 22.16.0** e **npm 10.9.2**, a partir do `package-lock.json` aprovado.

Estrutura do ZIP a enviar:

```text
SGT_GTRAT_REACT_DEPS_LINUX_NODE_22_16_0_NPM_10_9_2/
├── node_modules/
├── package.json
├── package-lock.json
├── AMBIENTE_ORIGEM.txt
└── SHA256SUMS.txt
```

Em `AMBIENTE_ORIGEM.txt`, registrar pelo menos `node --version`, `npm --version`, SO/arquitetura e o comando usado para instalar.

### Se você usa Windows

Não compacte diretamente o `node_modules` criado no Windows. Use WSL2/Ubuntu, VM Linux ou outro Linux x86_64. Vite 8/Rolldown e LightningCSS selecionam bindings por sistema operacional e arquitetura.

## React — alternativa por cache npm

Pode ser enviado um cache npm completo, desde que inclua **todos os tarballs do package-lock e os pacotes opcionais nativos Linux x64 GNU usados pelo build**. O cache produzido apenas em Windows pode não conter esses bindings Linux.

## Backend — opção mais econômica para integração

Se o Java não será alterado, prefiro receber:

```text
sig-gtrat-backend-<versao>.jar
.env                  # desenvolvimento/homologação, conforme sua política do projeto
README_EXECUCAO.txt
```

Isso evita recompilar um backend já aprovado.

## Backend — quando for preciso recompilar

Enviar:

```text
apache-maven-3.9.16-bin.zip
m2-repository.zip              # conteúdo de ~/.m2/repository compatível com o pom atual
# opcional para certificação exata:
jdk-17-linux-x64.tar.gz
```

O Maven Wrapper do projeto não resolve o problema sozinho: ele aponta para uma distribuição remota e este ambiente não consegue baixá-la.

## Banco

Para integração full-stack local, fornecer uma distribuição MySQL Linux x86_64 compatível. A linha 8.4.x é coerente com o backend atual. O banco pode ser recriado para desenvolvimento conforme a estratégia já adotada no projeto.

## Redis

Enviar Redis Linux apenas quando o gate exigir comportamento de cache real. Testes React mockados, build e a maioria dos testes de contrato não dependem dele.

## Regra de atualização

Sempre que o `package-lock.json` mudar, o pacote offline React deve ser considerado versionado junto com ele. Sempre que o `pom.xml` mudar, o `.m2` offline deve ser reavaliado.
