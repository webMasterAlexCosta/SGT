# SGT/GTRAT — Ambiente de Execução e Dependências para Implementação/Testes React — V3

## 1. Objetivo

Este documento elimina uma ambiguidade da V2: **o que é necessário para eu realmente implementar, compilar, testar e integrar o React no meu ambiente**, o que já está disponível e o que precisa ser fornecido quando o ambiente não consegue obter dependências pela internet.

A regra de evidência é rígida: **nenhum teste será declarado como executado se a dependência necessária não estiver presente**. Análise estática, implementação, build, teste unitário, browser headless e integração com API são evidências diferentes e serão registradas separadamente.

## 2. Ambiente que tenho disponível agora

| Recurso | Versão/estado | Situação | Uso |
|---|---|---|---|
| SO | Debian GNU/Linux 13 (trixie), x86_64, glibc 2.41 | disponível | execução principal |
| CPU/RAM | 5 vCPU / ~5.8 GiB | disponível | testes e builds moderados |
| Node.js | **22.16.0** | **disponível e exatamente igual ao projeto** | build/testes React |
| npm / npx | **10.9.2** | **disponível e exatamente igual ao projeto** | resolução/execução npm |
| Chromium | 144.0.7559.96 | disponível | smoke headless/DOM/screenshot |
| Git | 2.47.3 | disponível | diff, integridade, histórico técnico |
| curl | 8.10.1 | disponível | chamadas HTTP à API |
| Java | OpenJDK 21.0.11 | disponível | pode executar JAR compilado para Java 17 |
| JDK 17 | ausente | não disponível | necessário somente para validação exata do runtime Java 17 |
| Maven | ausente | não disponível | rebuild Java offline exige binário + repositório |
| Docker | ausente | não disponível | Testcontainers/Docker Compose indisponíveis |
| MySQL | ausente | não disponível | integração real com backend exige servidor MySQL local fornecido |
| Redis | ausente | não disponível | cache real exige Redis fornecido quando aplicável |
| Internet npm/Maven | indisponível | **bloqueada** | não posso baixar dependências sob demanda |

### 2.1 Compatibilidade exata com o React antigo

O próprio projeto determina:

- `.nvmrc`: `22.16.0`;
- `.node-version`: `22.16.0`;
- `packageManager`: `npm@10.9.2`;
- `engines.node`: `>=22.0.0 <25`.

Portanto, **Node e npm não precisam ser enviados** para a implementação React enquanto esse baseline for mantido.

## 3. Estado das dependências npm

O ZIP do React atual **não contém `node_modules`**. O `package-lock.json` possui lockfile v3 e 253 entradas de pacotes além da raiz. Ele fixa as versões exatas necessárias.

Uma tentativa controlada foi feita:

1. `npm ci` online não concluiu porque o ambiente não resolve `registry.npmjs.org`;
2. `npm ci --offline` falhou imediatamente em `xmlchars@2.2.0`, demonstrando que o cache local não contém todo o grafo;
3. logo, apenas `package.json` + `package-lock.json` **não bastam para executar testes aqui**.

O inventário completo de todas as versões resolvidas está em:

- `SGT_GTRAT_NPM_DEPENDENCIAS_LOCKFILE_V3.csv`;
- `SGT_GTRAT_NPM_PACOTES_PLATAFORMA_V3.csv` para bindings dependentes de SO/CPU.

## 4. Dependências diretas fixadas pelo lockfile

### Runtime

| Pacote | Versão resolvida |
|---|---:|
| `@vladmandic/face-api` | `1.7.15` |
| `axios` | `1.19.0` |
| `jspdf` | `4.2.1` |
| `jspdf-autotable` | `5.0.8` |
| `lucide-react` | `1.28.0` |
| `react` | `19.2.8` |
| `react-dom` | `19.2.8` |
| `react-icons` | `5.7.0` |
| `react-router-dom` | `7.18.2` |
| `react-toastify` | `11.1.0` |
| `recharts` | `3.10.1` |


### Desenvolvimento/testes

| Pacote | Versão resolvida |
|---|---:|
| `@vitejs/plugin-basic-ssl` | `2.3.0` |
| `@vitejs/plugin-react` | `6.0.5` |
| `vite` | `8.2.0` |
| `@testing-library/jest-dom` | `6.9.1` |
| `@testing-library/react` | `16.3.2` |
| `@vitest/coverage-v8` | `4.1.11` |
| `jsdom` | `27.4.0` |
| `vitest` | `4.1.11` |


## 5. O que você precisa me enviar — por nível de teste

### Nível A — análise, documentação e implementação estática

**Não precisa enviar nada além do React e Java.** Posso ler, comparar contratos, editar arquivos, gerar testes e fazer inspeção estática. Entretanto, sem dependências instaladas, não vou chamar isso de “build validado”.

### Nível B — build + Vitest + Testing Library + cobertura

É necessário disponibilizar o grafo npm completo de forma offline. Ordem de preferência:

1. **Preferido:** `node_modules` gerado em **Linux x86_64/glibc** com Node 22.16.0 e npm 10.9.2 usando exatamente este `package-lock.json`;
2. **Alternativa:** cache npm offline completo contendo todos os `.tgz` do lockfile, inclusive bindings Linux x64 GNU;
3. **Alternativa técnica:** diretório de tarballs espelhados/local registry exportado, desde que todas as URLs do lock possam ser resolvidas offline.

**Não recomendo `node_modules` gerado no Windows** para este ambiente Linux, porque Vite 8/Rolldown e LightningCSS possuem pacotes nativos por plataforma. Um `node_modules` Windows pode passar em parte dos testes jsdom e ainda falhar no build.

Pacotes nativos relevantes para este ambiente incluem, entre outros:

- `@rolldown/binding-linux-x64-gnu@1.2.4`;
- `lightningcss-linux-x64-gnu@1.33.0`.

### Nível C — smoke visual headless

Depois do Nível B, **não precisa enviar navegador**: já existe Chromium 144.0.7559.96. Posso usar modo headless para validar carregamento, DOM, recursos estáticos e screenshots. Para automação E2E rica (cliques complexos, múltiplas sessões, interceptação avançada), o projeto precisaria adicionar um framework como Playwright/Cypress/Selenium; isso será uma decisão explícita de implementação, não uma dependência presumida.

### Nível D — integração React ↔ Java real sem recompilar Java

Opção mais simples e segura, considerando que o backend está congelado:

- enviar o **JAR executável atual e aprovado do backend**;
- fornecer configuração `.env` adequada ao ambiente de teste;
- fornecer MySQL local compatível ou outro meio local suportado pelo backend;
- Redis somente para cenários que realmente dependam do cache.

Meu Java 21.0.11 consegue executar um JAR compilado com `release 17`. Isso serve para integração React/API. Porém, essa execução **não substitui** uma certificação de que o backend roda exatamente em JDK 17.

### Nível E — rebuild/testes do Java quando houver suspeita real de bug

Somente será necessário se precisarmos reproduzir ou confirmar um bug no backend. Como o projeto usa `mvnw` apontando para **Maven 3.9.16**, mas não há internet, preciso de um dos conjuntos:

**Opção E1 — recomendada:**
- `apache-maven-3.9.16-bin.zip`;
- repositório Maven local (`.m2/repository`) já populado para esse `pom.xml`;
- JDK 17 Linux x64 se quisermos validar exatamente o runtime alvo.

**Opção E2:**
- Maven 3.9.16 + todos os artefatos Maven em um repositório offline equivalente.

Sem `.m2`, o Maven também tentará alcançar repositórios externos e falhará.

### Nível F — integração de dados e desempenho

Para cenários de frequência, painel e relatórios com dados reais/grandes:

- MySQL 8.4.x Linux x86_64 (o mesmo ramo usado no projeto é preferível);
- massa de dados de homologação/seeds do próprio backend;
- Redis se o cenário medir cache/painel;
- JAR aprovado ou ambiente Maven completo;
- dependências npm completas.

Docker não está disponível, portanto **não devemos planejar Testcontainers** como requisito de execução local aqui.

## 6. O que eu NÃO preciso que você envie agora

Para começar a Etapa 02 e escrever código, não preciso de:

- Node 22.16.0;
- npm 10.9.2;
- navegador Chromium;
- Git;
- Python;
- Tailwind;
- bibliotecas CSS externas.

Mas, antes de declarar a Etapa 02 aprovada, preciso conseguir rodar ao menos `npm ci`/dependências disponíveis, `npm run build` e a suíte mínima prevista.

## 7. Pacote offline recomendado

Para evitar uploads repetidos, a melhor estratégia é manter um pacote de dependências chamado, por exemplo:

`SGT_GTRAT_REACT_DEPS_LINUX_NODE_22_16_0_NPM_10_9_2.zip`

Conteúdo recomendado:

```text
/node_modules/                  # gerado pelo package-lock aprovado em Linux x86_64
/package.json
/package-lock.json
/DEPENDENCIAS_ORIGEM.md         # SO, Node, npm, data, comando usado
/SHA256SUMS.txt
```

Se o `package.json`/`package-lock.json` mudar em uma etapa, esse pacote precisa ser regenerado. Não devemos reutilizar cegamente um `node_modules` antigo com um lockfile novo.

## 8. Validação de integridade das dependências recebidas

Ao receber dependências offline, farei, nessa ordem:

1. conferir Node/npm;
2. conferir hash e estrutura do pacote;
3. comparar `package.json` e `package-lock.json` do pacote com o React da etapa;
4. verificar `npm ls --all`;
5. executar `npm run validate:runtime`;
6. executar build baseline antes de qualquer alteração, sempre que possível;
7. executar suítes do projeto;
8. só então iniciar/continuar a implementação.

Se `npm ls` indicar árvore inválida ou se bindings forem da plataforma errada, o pacote será classificado como inadequado e isso será documentado; não tentarei mascarar o problema alterando versões arbitrariamente.

## 9. Política para versões

- Não atualizarei React, Vite, Vitest ou outra dependência “porque existe versão mais nova” durante uma etapa funcional.
- Mudança de versão só ocorrerá com requisito técnico explícito, bug comprovado ou incompatibilidade necessária.
- O `package-lock.json` é autoridade para reprodutibilidade.
- Dependência nova exige justificativa, impacto de bundle, teste e atualização deste inventário.

## 10. Conclusão operacional

**Hoje estou pronto para implementar com o runtime correto, mas não estou pronto para declarar testes npm executados porque faltam os pacotes offline.** A forma mais simples é você fornecer um `node_modules` Linux compatível ou outro repositório npm offline completo. Para integração real com o Java, o caminho de menor risco é fornecer o JAR aprovado e o MySQL; Maven/.m2 só são necessários se precisarmos recompilar o backend.
