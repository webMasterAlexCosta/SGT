# SGT/GTRAT — Matriz de Configuração do Frontend V2

Esta matriz não altera o `.env`; classifica o que deverá ser feito nas Etapas 02–04. Valores que parecem credenciais/senhas são omitidos deste documento.

| Variável | Valor baseline não sensível | Classificação/decisão |
|---|---|---|
| `VITE_API_URL` | `/api` | Infraestrutura/UX — pode parametrizar cliente |
| `VITE_HTTP_TIMEOUT` | `15000` | Infraestrutura/UX — pode parametrizar cliente |
| `VITE_HTTP_RETRY_BASE_MS` | `350` | Infraestrutura/UX — pode parametrizar cliente |
| `VITE_HTTP_RETRY_MAX_MS` | `2500` | Infraestrutura/UX — pode parametrizar cliente |
| `VITE_PING_INTERVAL_MS` | `300000` | UX de sessão — servidor permanece autoritativo |
| `VITE_SESSION_MAX_TIME_MS` | `7200000` | UX de sessão — servidor permanece autoritativo |
| `VITE_INTRO_MIN_DURATION_MS` | `1500` | Metadado/UX — revisar necessidade |
| `VITE_APP_NAME` | `SISTEMA GESTÃO DE TERCEIROS` | Metadado/UX — revisar necessidade |
| `VITE_APP_COMPANY` | `Correios` | Metadado/UX — revisar necessidade |
| `VITE_APP_CNPJ` | `34.028.316/0001-03` | Metadado/UX — revisar necessidade |
| `VITE_APP_AUTHOR_NAME` | `Alex Costa` | Metadado/UX — revisar necessidade |
| `VITE_APP_AUTHOR_ELABORADOR_1` | `ANA CLAUDIA CARNEIRO FONTES MARTINS` | Metadado/UX — revisar necessidade |
| `VITE_APP_AUTHOR_ELABORADOR_2` | `LAERCIO MARCOLINO JUNIOR` | Metadado/UX — revisar necessidade |
| `VITE_APP_AUTHOR_MATRICULA` | `89618815` | Metadado/UX — revisar necessidade |
| `VITE_EM_MANUTENCAO` | `false` | Metadado/UX — revisar necessidade |
| `VITE_PREVISAO_RETORNO` | `2026-12-31T23:59:59` | Metadado/UX — revisar necessidade |
| `VITE_FREQUENCIA_MAX_GRID_ITEMS` | `150000` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_FREQUENCIA_LIMIT_ADMIN_DAYS` | `3650` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_FREQUENCIA_LIMIT_UNLOCKED_DAYS` | `45` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_FREQUENCIA_LIMIT_DEFAULT_DAYS` | `30` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_FREQUENCIA_EDIT_WINDOW_HOURS` | `48` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_FREQUENCIA_EDIT_WARNING_MINUTES` | `30` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_ABSENTEISMO_DEFAULT_META` | `3.0` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_OCORRENCIA_MAX_DIAS` | `120` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_PAGINATION_MAX_SIZE` | `2000` | Metadado/UX — revisar necessidade |
| `VITE_SHOW_TEST_CREDENTIALS` | `true` | Teste — deve ficar desabilitado/sem segredo em produção |
| `VITE_TEST_GLOBAL_PASSWORD` | `[valor omitido na documentação]` | Teste — deve ficar desabilitado/sem segredo em produção |
| `VITE_TEST_GESTOR_PASSWORD` | `[valor omitido na documentação]` | Teste — deve ficar desabilitado/sem segredo em produção |
| `VITE_PAGINATION_DEFAULT_SIZE` | `50` | Metadado/UX — revisar necessidade |
| `VITE_EMPREGADOS_INITIAL_SIZE` | `0` | Metadado/UX — revisar necessidade |
| `VITE_AUDIT_DEFAULT_SIZE` | `20` | Metadado/UX — revisar necessidade |
| `VITE_PAGINATION_OPTIONS` | `10,50,100,1000` | Metadado/UX — revisar necessidade |
| `VITE_AUDIT_PAGINATION_OPTIONS` | `10,50,100,500,1000,5000` | Metadado/UX — revisar necessidade |
| `VITE_DASHBOARD_RECENT_ACTIVITIES` | `5` | Metadado/UX — revisar necessidade |
| `VITE_UPLOAD_MAX_SIZE_MB` | `5` | Infraestrutura/UX — pode parametrizar cliente |
| `VITE_TOAST_DURATION_MS` | `8000` | Infraestrutura/UX — pode parametrizar cliente |
| `VITE_TOAST_DEDUPE_WINDOW_MS` | `2500` | Infraestrutura/UX — pode parametrizar cliente |
| `VITE_HOMOLOGACAO_EXPIRY_DAYS` | `7` | Metadado/UX — revisar necessidade |
| `VITE_CONNECTION_SUCCESS_DELAY_MS` | `1500` | Metadado/UX — revisar necessidade |
| `VITE_OFFLINE_RETRY_INTERVAL_MS` | `10000` | Metadado/UX — revisar necessidade |
| `VITE_SESSION_WARN_5MIN_MS` | `300000` | UX de sessão — servidor permanece autoritativo |
| `VITE_SESSION_WARN_1MIN_MS` | `60000` | UX de sessão — servidor permanece autoritativo |
| `VITE_SESSION_REFRESH_INTERVAL_MS` | `120000` | UX de sessão — servidor permanece autoritativo |
| `VITE_HELP_TOOLTIP_DAYS` | `30` | Metadado/UX — revisar necessidade |
| `VITE_INACTIVITY_TIMEOUT_MS` | `1800000` | UX de sessão — servidor permanece autoritativo |
| `VITE_LATENCY_CHECK_INTERVAL_MS` | `8000` | Metadado/UX — revisar necessidade |
| `VITE_ABSENTEISMO_DISRUPCAO_THRESHOLD` | `50` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_AUTH_PASSWORD_MIN_LENGTH` | `[valor omitido na documentação]` | Metadado/UX — revisar necessidade |
| `VITE_APP_ALLOWED_DOMAIN` | `@correios.com.br` | Metadado/UX — revisar necessidade |
| `VITE_APP_CLIENT_ID` | `SGT` | Infraestrutura/UX — pode parametrizar cliente |
| `VITE_SEARCH_DEBOUNCE_MS` | `500` | Infraestrutura/UX — pode parametrizar cliente |
| `VITE_COMPANY_DEPARTMENT` | `RJ/GTRAT/GTRAT/CST RIO DE JANEIRO` | Metadado/UX — revisar necessidade |
| `VITE_JORNADA_REFERENCIA_HORAS` | `44` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_JORNADA_LIMIAR_INFERIOR` | `38` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |
| `VITE_JORNADA_LIMIAR_MEDIO` | `40` | Regra/limite local — NÃO pode ser fonte de verdade se Java define a regra |

## Regra central

Variáveis locais podem controlar apresentação, timeout, debounce, tamanhos e feature flags, mas não devem decidir capacidade, janela de edição, perfil, escopo, validade temporal, estado de contrato ou autorização quando essas regras existem no Java.