# Próxima etapa — Etapa 16

## Relatórios, emissões e exportações

Pré-requisito cumprido: Etapas 13–15 aprovadas.

### Escopo do planejamento consolidado

- revalidar frequência mensal, consolidada, absenteísmo, terceirizados e demais endpoints de `RelatorioControlador`;
- inventariar e integrar `RelatorioAdministrativoControlador`;
- trabalhar sobre **22 endpoints** previstos: 6 administrativos + 16 de relatórios;
- filtros compartilhados de contrato/lotação/turno/cargo e opção Todos conforme o Java;
- paginação 200/1000/2000/5000/Todos somente quando o backend realmente suportar e for seguro;
- cálculo sempre no backend;
- downloads PDF/XLSX com nome, content-type, erro, expiração e feedback;
- impedir geração duplicada por duplo clique quando houver job/identificador;
- prévia, emissão, versões, `conhecidoAte`, comparação e retificação administrativa;
- exibir pendências/sujeito a revisão quando o Java informar;
- Presidente permanece leitura nacional, sem emissão formal quando o backend negar;
- validar relatórios noturnos e grande volume;
- comparar **tela × total × arquivo** no mesmo recorte.

### Gate esperado

**Tela, total e exportação conferem; emissão formal respeita perfil e versão.**

### Regra de continuidade

Antes de alterar qualquer tela, localizar controlador, DTO, matcher e serviço Java correspondente. Ambiguidade deve falhar fechado; o Java não será adaptado para acomodar o React.
