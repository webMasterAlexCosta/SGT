# Possível bug Java não bloqueante — Etapa 15

## Local

`PainelServico.obterEstatisticas()`.

## Comportamento observado

O método verifica explicitamente `ehPresidente(user)` e retorna **403**, o que é coerente com a restrição de detalhamento da Presidência.

Entretanto, a mensagem textual da exceção diz:

> “O gestor nacional deve utilizar a visão consolidada por gestor estadual em /api/painel/gestao.”

A condição executada é Presidente, não Gestor Nacional.

## Avaliação

- autorização: aparentemente correta;
- texto da mensagem: aparentemente incorreto/inconsistente;
- impacto na Etapa 15: não bloqueante;
- ação tomada no Java: **nenhuma**;
- ação React: falhar fechado e não usar `/estatisticas` como dependência da visão presidencial.

## Recomendação futura

Corrigir somente a mensagem no backend em uma revisão Java formalmente autorizada, acompanhada de teste de regressão. Não alterar autorização para “corrigir” o texto.
