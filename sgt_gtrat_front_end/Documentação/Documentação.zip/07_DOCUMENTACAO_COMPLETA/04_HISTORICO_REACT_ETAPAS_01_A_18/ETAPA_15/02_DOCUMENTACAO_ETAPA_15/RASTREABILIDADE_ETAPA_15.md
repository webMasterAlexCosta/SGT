# Rastreabilidade — Etapa 15

| Requisito do planejamento | Evidência React | Evidência Java/contrato | Situação |
|---|---|---|---|
| Validar painel e cálculo assíncrono | `ServicoPainel.solicitarCalculo/consultarCalculo` + `usePainel` | `PainelCalculoControlador` | atendido |
| Oito endpoints da etapa | `ServicoPainel.js` | 2 em `PainelCalculoControlador` + 6 em `PainelControlador` | atendido |
| Filtros contrato/lotação/jornada/cargo/data | `IndicadorEfetivo` | `PainelControlador.obterFiltrosEfetivo/obterIndicadorEfetivo` | atendido |
| Todos + painéis separados | `GrupoPaineisTodos` / `PainelItemTodos` | detalhamentos devolvidos em `PainelEfetivoDTO` | atendido |
| Previsto/presentes/ausentes/pendentes sem fórmula local | `IndicadorEfetivo`, `GestaoExecutiva`, exportações | `PainelEfetivoDTO` e `PainelServico` | atendido |
| Navegação temporal | referência reativa + nova consulta | `referencia` LocalDate nos endpoints | atendido |
| Cinco perfis gerenciais | guards/capacidades e teste de contrato | matcher `/api/painel/**` | atendido |
| Presidente nacional sem detalhe operacional | UI omite ranking/atividades e respeita filtros | `permiteDetalhamentoOperacional=false` | atendido |
| Sem refresh | `AbortController` + efeitos por referência/período | API stateless/autoritativa | atendido |
| Linha/barra/dispersão/infográfico | `VisualizadorEfetivo` | usa somente payload da API | atendido |
| Tabela acessível equivalente | `TabelaAlternativa` | mesmos campos do DTO | atendido |
| Exportação no mesmo recorte | exportadores usam payload atual | percentuais devolvidos pelo Java | atendido |
| Sem correlação gerencial inventada | Pearson removido | Java não expõe essa métrica | atendido |
| Performance/grande volume | gate robustez + paginação visual dos painéis “Todos” | agregação permanece no servidor | atendido no escopo React |

## Regra preservada

O Java declara expressamente em sua metodologia de painel que os totais são calculados no servidor e filtrados pelo escopo do usuário autenticado. A Etapa 15 passa a refletir essa regra também nos indicadores, gráficos e exportações.
