# Matriz de permissões — Etapa 15

O matcher `/api/painel/**` do Java admite cinco perfis gerenciais. O perfil Operacional fica fora da etapa.

| Capacidade | Administrador | Gestor Nacional | Presidente | Gestor Estadual | Gestor Local | Operacional |
|---|---:|---:|---:|---:|---:|---:|
| Acessar painel | sim | sim | sim | sim | sim | não |
| Cálculo assíncrono | sim | sim | sim | sim | sim | não |
| Visão de gestão nacional | sim | sim | sim* | não | não | não |
| Visão de gestão por SE | sim/nacional | sim/nacional | sim/agregada | sim | não | não |
| Visão de gestão local | sim | sim | não | conforme escopo | sim | não |
| Indicador de efetivo por contrato | sim | sim | sim | sim | sim | não |
| Detalhamento por lotação/turno/cargo | sim | sim | **não** | sim | sim | não |
| Atividades recentes nominativas | sim | sim | **não** | sim | sim | não |
| Ranking de lotações | sim | sim | **não** | sim | sim | não |
| Estatísticas administrativas | sim | sim | **não** | sim | sim | não |

\* A Presidência recebe nível nacional com a descrição Java “Brasil — visão por gestor estadual”, sem detalhamento operacional.

## Regras adicionais observadas no serviço Java

- `permiteDetalhamentoOperacional = false` para Presidente;
- filtros `lotacaoId`, `jornadaId` e `cargoId` são ignorados/zerados para Presidente;
- atividades recentes retornam página vazia para Presidente;
- ranking de lotações retorna 403 para Presidente;
- estatísticas administrativas retornam 403 para Presidente;
- Administrador e Gestor Nacional possuem contexto nacional;
- Gestor Estadual fica restrito à sua Superintendência;
- Gestor Local fica restrito à sua Gestão Local.

## Confirmação de senha

Os controladores de painel desta etapa **não possuem `@ExigirSenha`**. O React não adiciona confirmação de senha que o Java não exija.
