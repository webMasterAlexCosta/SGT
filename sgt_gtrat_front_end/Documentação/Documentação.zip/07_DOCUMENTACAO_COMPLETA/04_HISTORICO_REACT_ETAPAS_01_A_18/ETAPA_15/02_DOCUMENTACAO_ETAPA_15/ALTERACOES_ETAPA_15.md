# Alterações — Etapa 15

## Escopo

Etapa **15 — Painel e cálculos gerenciais**, executada sobre a baseline aprovada da Etapa 14.

A implementação segue o princípio de que o **Java atual é a fonte de verdade** para contrato HTTP, escopo, autorização, temporalidade e cálculos gerenciais. O React somente seleciona o recorte, acompanha processamento, apresenta os valores devolvidos e faz transformações estritamente visuais.

## Implementações realizadas

### 1. Contrato completo dos controladores de painel

`src/services/painel/ServicoPainel.js` cobre os oito endpoints definidos por `PainelCalculoControlador` e `PainelControlador`:

- cálculo assíncrono `POST /api/painel/calculos`;
- polling `GET /api/painel/calculos/{id}`;
- filtros do efetivo;
- indicador de efetivo;
- visão síncrona de gestão;
- estatísticas;
- atividades recentes;
- ranking de lotações.

O fluxo principal da tela continua preferindo o cálculo assíncrono, evitando duplicar a consulta pesada. A rota síncrona permanece disponível no serviço porque faz parte do contrato Java da etapa.

### 2. Cálculos gerenciais removidos do navegador

Foram removidas fórmulas locais que atribuíam significado gerencial a razões calculadas no browser, incluindo a antiga cobertura baseada em `registros / previsto` e variações percentuais produzidas pelo React.

O React agora consome diretamente:

- `percentualCobertura`;
- `percentualAtendimento`;
- `efetivoPrevisto`;
- `efetivoAlocado`;
- `registrosLancados`;
- `presentes`;
- `ausentes`;
- `pendentesLancamento`;
- `deficitContratual`;
- `excedenteContratual`.

As únicas divisões remanescentes no visualizador servem para dimensionamento gráfico em pixels/faixas e não são apresentadas como indicador de negócio.

### 3. Perfil Presidente tratado conforme o Java

A Presidência mantém visão nacional, mas sem detalhamento operacional. O React não solicita ranking de lotações nem atividades nominativas para esse perfil e o indicador de efetivo respeita `permiteDetalhamentoOperacional` devolvido pelo backend.

### 4. Filtros canônicos e opção “Todos”

O indicador usa os filtros retornados por `/api/painel/efetivo/filtros` e consulta `/api/painel/efetivo` com contrato, lotação, jornada/turno, cargo, referência e período.

Quando um filtro permanece em **Todos**, o React exibe, além do consolidado, painéis separados para as dimensões que o Java devolveu no mesmo recorte:

- contratos;
- lotações, quando o backend permite detalhamento;
- turnos/jornadas, quando permitido;
- cargos, quando permitido.

Os desdobramentos são paginados no navegador somente como organização visual; totais e percentuais continuam sendo os valores do Java.

### 5. Visualizações e acessibilidade

Foram mantidas as visualizações já existentes no padrão visual do projeto:

- linha;
- barras;
- dispersão;
- infográfico.

A correlação de Pearson calculada localmente foi removida, pois criava interpretação analítica que não existe no contrato Java. O gráfico de dispersão permanece apenas como composição visual dos pontos.

Foi acrescentada **tabela alternativa acessível**, usando os mesmos dados da API apresentados nos gráficos.

### 6. Exportação alinhada ao mesmo recorte

As exportações do painel deixaram de recalcular percentuais. PDF/XLSX passam a utilizar os percentuais já existentes no payload do Java e distinguem corretamente:

- cobertura dos alocados;
- atendimento contratual.

### 7. Atualização reativa e cancelamento de contexto antigo

A troca de referência/período cria novo contexto, cancela requisições obsoletas com `AbortController` e reinicia o cálculo sem `location.reload`.

O polling usa o identificador devolvido pelo Java e encerra quando o processamento conclui ou falha.

## Arquivos produtivos alterados em relação à Etapa 14

- `src/services/painel/ServicoPainel.js`;
- `src/modules/painel/components/GestaoExecutiva/index.jsx`;
- `src/modules/painel/components/IndicadorEfetivo/index.jsx`;
- `src/modules/painel/components/IndicadorEfetivo/index.module.css`;
- `src/modules/painel/components/IndicadorEfetivo/exportacao.js`;
- `src/modules/painel/components/VisualizadorEfetivo/index.jsx`;
- `src/modules/painel/components/VisualizadorEfetivo/index.module.css`;
- `src/modules/painel/exportacao.js`.

## Testes alterados/adicionados

- novo `test/etapa15ContratoJava.test.js`;
- atualização de `test/painelIndicadorEfetivo.test.js`;
- atualização de `test/painelVisualizacoesGerenciais.test.js`.

## Java

**Nenhum arquivo Java foi alterado.**
