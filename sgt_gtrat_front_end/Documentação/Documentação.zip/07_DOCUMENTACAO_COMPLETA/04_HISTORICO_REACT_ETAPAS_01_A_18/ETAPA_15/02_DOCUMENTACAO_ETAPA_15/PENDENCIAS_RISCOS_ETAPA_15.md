# Pendências e riscos — Etapa 15

Nenhum item abaixo bloqueia o gate da Etapa 15.

## 1. Bundle `vendor-face`

O build continua emitindo aviso porque `vendor-face` fica em aproximadamente **1,31 MB minificado**. É dependência histórica de reconhecimento facial e não foi introduzida pela Etapa 15.

**Tratamento planejado:** Etapa 17/Gate de saneamento de bundle, conforme GAP-023, avaliando lazy loading/code splitting sem comprometer os fluxos que usam a biblioteca.

## 2. Endpoint síncrono `/api/painel/gestao`

O contrato Java mantém endpoint síncrono e cálculo assíncrono. O serviço React cobre ambos, mas a UI principal usa o assíncrono para evitar consulta pesada duplicada.

**Regra:** não chamar os dois para o mesmo carregamento apenas para “cobertura”.

## 3. `/api/painel/estatisticas` e Presidente

O matcher HTTP admite Presidente em `/api/painel/**`, porém o serviço recusa esse endpoint. O React segue a regra mais restritiva e não depende desse recurso para a Presidência.

Há ainda uma mensagem de erro Java com nomenclatura aparentemente incorreta; registrada separadamente em `POSSIVEL_BUG_JAVA_ETAPA_15.md`.

## 4. Transformações visuais

Gráficos ainda calculam escalas geométricas (largura/tamanho de elementos). Essas operações são permitidas porque não são exibidas nem persistidas como indicador gerencial.

**Proteção:** `etapa15ContratoJava.test.js` impede reintrodução de fórmulas autoritativas.
