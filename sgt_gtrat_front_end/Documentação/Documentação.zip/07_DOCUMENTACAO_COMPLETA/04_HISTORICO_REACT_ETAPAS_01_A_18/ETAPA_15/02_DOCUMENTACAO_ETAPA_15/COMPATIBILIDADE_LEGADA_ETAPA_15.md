# Compatibilidade legada — Etapa 15

A Etapa 15 **não cria nova dependência legada**. Permanecem os itens herdados e deliberadamente documentados na Etapa 14.

## 1. `empregadoId` em ocorrências

`POST /api/ocorrencias` ainda usa `empregadoId`. O React mantém a projeção de Empregado somente para satisfazer o contrato Java atual.

**Remover quando:** o Java migrar o comando para a identidade canônica Pessoa/Vínculo Contratual.

## 2. `empregadoId` em exceções e adicionais de frequência

`FrequenciaExcecaoDTO` e `FrequenciaAdicionalDTO` continuam expondo `empregadoId`.

**Remover quando:** o Java passar esses comandos para a identidade canônica Pessoa/Vínculo.

## 3. aliases nominais de Empregado

Permanecem aliases como `podeVisualizarEmpregados`, `podeGerenciarEmpregados` e o redirecionamento histórico `/empregados` → `/pessoas` enquanto módulos antigos ainda dependem da projeção Empregado.

**Remover quando:** nenhuma funcionalidade ativa consumir essa projeção/nomes históricos.

## 4. aliases de tokens visuais

`src/styles/tokens.css` mantém aliases do React legado para migração gradual, preservando o padrão visual Correios.

**Remover quando:** a busca estática confirmar que todos os módulos usam os tokens canônicos.

## 5. legado de painel saneado nesta etapa

Não deve ser restaurado em etapas futuras:

- cálculo local de “cobertura contratual” por razão inventada no browser;
- cálculo local de percentuais de presença/ausência apresentados como autoridade;
- variação percentual de indicadores calculada no browser;
- correlação Pearson apresentada como métrica gerencial sem contrato Java.

Esses itens foram **removidos**, não mantidos por compatibilidade.

## Governança

Compatibilidade não concede permissão, não define regra de negócio e não autoriza mudança no Java. A remoção só ocorre quando o Java deixar de exigir o contrato correspondente e a integridade React × Java permanecer verde.
