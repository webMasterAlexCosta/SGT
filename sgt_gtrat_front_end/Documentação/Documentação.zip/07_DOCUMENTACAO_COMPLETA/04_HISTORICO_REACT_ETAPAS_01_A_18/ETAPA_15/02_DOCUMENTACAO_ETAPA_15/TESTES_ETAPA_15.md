# Testes — Etapa 15

## Resultado consolidado

| Gate | Resultado |
|---|---:|
| Vitest principal | **117/117** |
| Componentes/importação/renderização | **375/375** |
| Camada 2 — comportamento | **640/640** |
| Camada 3 — robustez/performance | **526/526** |
| Integridade React × Java | **363/363** |
| Configuração | **16/16** |
| Qualidade estática | **251 arquivos, 0 erros, 0 avisos** |
| Nomenclatura | aprovada |
| Runtime | Node **22.16.0**, npm **10.9.2** |
| Build | aprovado |
| Bundle/segredos | aprovado / fail-closed |

## Teste focal da Etapa 15

A combinação abaixo foi executada durante a implementação e concluiu **35/35**:

- `test/etapa15ContratoJava.test.js`;
- `test/painelIndicadorEfetivo.test.js`;
- `test/painelVisualizacoesGerenciais.test.js`.

## O que o teste de contrato da Etapa 15 protege

- exatamente os oito endpoints Java associados à etapa;
- cálculo assíncrono + polling;
- cancelamento de contexto obsoleto;
- ausência de `location.reload`;
- cinco perfis gerenciais e exclusão do Operacional;
- Presidência sem detalhamento operacional;
- “Todos” com desdobramentos;
- ausência de fórmulas autoritativas de percentual no React;
- gráficos como composição visual, não motor analítico;
- tabela acessível equivalente;
- data futura rejeitada conforme Java;
- exportações usando percentuais da API;
- metodologia Java de totais calculados no servidor.

## Observação sobre execução da integridade

`npm run test:integridade` precisa de `SGT_BACKEND_DIR` apontando para a extração do `JAVA.zip`. A execução válida desta entrega foi feita com o backend atual anexado e terminou em **363/363**.

## Evidências

Os logs completos e relatórios JUnit/JSON/PDF ficam em `05_EVIDENCIAS_TESTES/`.
