# Orçamento de bundle React

- JS total: 3801.1 KB (1063.1 KB gzip)
- CSS total: 495.9 KB
- Maior JS: assets/vendor-face-BvM7HRcj.js — 1283.8 KB (318.3 KB gzip)
- Violações: 0
- Avisos de otimização: 1

## Avisos de otimização

- Chunk pesado para revisão: assets/vendor-face-BvM7HRcj.js (1314597 bytes / 325931 gzip).

## Maiores arquivos

- `assets/vendor-face-BvM7HRcj.js`: 1283.8 KB / 318.3 KB gzip
- `assets/vendor-react-D1nB2_Fu.js`: 634.3 KB / 188.1 KB gzip
- `assets/vendor-charts-lvNgAyK2.js`: 422.1 KB / 117.6 KB gzip
- `assets/vendor-pdf-CpYylP1Y.js`: 420.7 KB / 135.1 KB gzip
- `assets/pages-rkjfQI46.js`: 180.0 KB / 45.6 KB gzip
- `assets/index-C4j_hGhM.js`: 128.4 KB / 41.6 KB gzip
- `assets/PaginaContratos-CT5KRMS6.js`: 104.9 KB / 24.8 KB gzip
- `assets/index-BT1j9PDR.css`: 76.6 KB / 15.7 KB gzip
- `assets/PaginaPessoasVinculos-Bwp-3_vK.js`: 68.3 KB / 16.5 KB gzip
- `assets/pages-CJDfwqeY.css`: 65.8 KB / 12.0 KB gzip
- `assets/PaginaFrequencia-BZNE-cGr.js`: 64.6 KB / 19.4 KB gzip
- `assets/PaginaFrequencia-BM-L9Dr1.css`: 43.2 KB / 7.9 KB gzip
- `assets/vendor-icons-BJYoCOxW.js`: 41.8 KB / 12.1 KB gzip
- `assets/PaginaContratos-R1QFydq6.css`: 36.9 KB / 7.4 KB gzip
- `assets/PaginaTurnos-a2cce40N.js`: 34.2 KB / 10.3 KB gzip
- `assets/Login-BuPhdzz_.js`: 33.5 KB / 10.1 KB gzip
- `assets/PaginaRelatorioAbsenteismo-BSAJH892.js`: 33.3 KB / 8.8 KB gzip
- `assets/PaginaPerfil-DPf_1GdT.js`: 31.9 KB / 9.4 KB gzip
- `assets/PaginaRelatoriosTerceirizados-CaFkrfdU.js`: 31.2 KB / 9.8 KB gzip
- `assets/PaginaOcorrencias-D6a5uwwZ.css`: 27.0 KB / 5.1 KB gzip
