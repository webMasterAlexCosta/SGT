# Origem documental — Etapa 15

- Fonte local validada: `/mnt/data/etapa15_work/SGT_GTRAT_REACT_ETAPA_15`.
- Conteúdo preservado sem reescrita das pastas documentais/evidências.
- Arquivos recuperados desta fonte: **726**.
- Em conflito, prevalecem o Java atual e a documentação final da Etapa 18.
