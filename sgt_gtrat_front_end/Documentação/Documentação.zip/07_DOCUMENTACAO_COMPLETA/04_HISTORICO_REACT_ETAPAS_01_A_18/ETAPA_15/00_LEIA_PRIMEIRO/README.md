# SGT/GTRAT React — Etapa 15

Entrega da **Etapa 15 — Painel e cálculos gerenciais**.

## Fonte de verdade

O `JAVA.zip` atual fornecido pelo usuário é a fonte de verdade. **Nenhum arquivo Java foi alterado.**

## Destaques

- oito endpoints do painel cobertos no serviço React;
- cálculo gerencial autoritativo removido do browser;
- percentuais de cobertura/atendimento vindos diretamente do Java;
- cinco perfis gerenciais conforme matcher do backend;
- Presidente nacional sem detalhamento operacional;
- opção **Todos** com painéis separados por dimensão;
- linha, barra, dispersão e infográfico preservados;
- correlação Pearson local removida;
- tabela alternativa acessível adicionada;
- exportações usando o mesmo recorte e os mesmos percentuais da API;
- atualização sem refresh e cancelamento de requisições obsoletas.

## Estrutura

- `01_REACT_ETAPA_15/`: fonte React;
- `02_DOCUMENTACAO_ETAPA_15/`: alterações, endpoints, permissões, rastreabilidade, legado, riscos, possível bug Java e próximo passo;
- `03_DOCUMENTACAO_ORIGINAL/`: planejamento consolidado original preservado;
- `04_REACT_ETAPA_14_REFERENCIA/`: documentação da baseline imediatamente anterior;
- `05_EVIDENCIAS_TESTES/`: logs e relatórios dos gates;
- `06_ENTRADAS_ORIGINAIS/`: entradas relevantes preservadas.

## Gate

Etapa aprovada para seguir à **Etapa 16 — Relatórios, emissões e exportações**. Consulte `02_DOCUMENTACAO_ETAPA_15/STATUS_GATE_ETAPA_15.md`.

## Dependências

O pacote de dependências offline Node 22.16.0 permanece fornecido separadamente e não precisa ser duplicado dentro da fonte React.
