# Pendências e riscos — Etapa 14

## Impeditivos

Nenhum impeditivo funcional conhecido após os gates executados.

## Compatibilidade a remover futuramente

- `empregadoId` permanece obrigatório em ocorrência, exceção e adicional de frequência porque o Java atual ainda exige esse campo;
- aliases de Empregado e tokens visuais legados continuam enquanto módulos anteriores dependem deles.

Detalhes e critérios de remoção: `COMPATIBILIDADE_LEGADA_ETAPA_14.md`.

## Riscos técnicos não impeditivos

1. **Bundle `vendor-face` grande:** o build gera chunk em torno de 1,3 MB minificado. O gate de bundle aprova, mas o Vite emite aviso acima de 1 MB. Tratar em etapa de otimização sem quebrar as bibliotecas de exportação/documento.
2. **Diferença matcher/serviço em usos de permissão excepcional:** GET é permitido a cinco perfis no matcher, enquanto o serviço restringe o histórico de usos ao Administrador. O React segue a regra mais restritiva.
3. **Identidade legada em três comandos:** não migrar `empregadoId` por inferência enquanto os DTOs/controladores Java continuarem assim.
4. **Fechamento assíncrono:** o navegador apenas acompanha o job. Estado/progresso/erro/cancelamento/reprocessamento devem continuar vindo do Java.
5. **Tipos livres em calendário e ajustes:** o Java usa `String` em pontos relevantes; o React não deve transformar sugestões de UI em enum autoritativo sem mudança explícita no backend.

## Regra para a Etapa 15

O painel deve consumir valores calculados pelo Java e não reproduzir fórmulas de previsto/presentes/ausentes/pendentes no browser.
