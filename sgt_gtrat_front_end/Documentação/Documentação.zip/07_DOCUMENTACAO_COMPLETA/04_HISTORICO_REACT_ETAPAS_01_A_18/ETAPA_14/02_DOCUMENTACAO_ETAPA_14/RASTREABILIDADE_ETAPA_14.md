# Rastreabilidade — Etapa 14

| Requisito do planejamento | Implementação React | Estado |
|---|---|---|
| Fechamentos, itens, status e reprocessamento | painel de fechamento + serviços `/frequencias/fechamentos` | Atendido |
| Fechamento assíncrono/progresso/recuperação | polling com backoff, `buscarAtual`, recuperação após reload | Atendido |
| Calendário por perfil/escopo | tela existente alinhada aos matchers; tipos não restringidos localmente | Atendido |
| Ocorrências e anexos | multipart completo e download de anexos | Atendido |
| Frequências exceções e adicionais | nova tela `/frequencia-ajustes` | Atendido |
| Central de pendências | nova tela `/pendencias`, resumo/filtros/tratamento/resolução | Atendido |
| Permissões excepcionais | nova tela `/permissoes-excepcionais`, concessão/revogação/usos | Atendido |
| Finalidade/expiração de permissão | campos e estados exibidos conforme DTO Java | Atendido |
| Pendência vinculada ao domínio | referências/ação sugerida são exibidas sem inventar resolução local | Atendido |
| Perfis/capacidades | menu/rotas derivados de `roles.js` alinhado ao Java | Atendido |
| Sem retry cego | mutações da etapa usam `retries: 0` | Atendido |
| Java como fonte de verdade | teste `etapa14ContratoJava.test.js` lê diretamente o backend anexado | Atendido |
| Código legado documentado | `COMPATIBILIDADE_LEGADA_ETAPA_14.md` | Atendido |
| Backend preservado | nenhum arquivo Java alterado | Atendido |
