# Alterações — Etapa 14

## Escopo

A Etapa 14 implementa **fechamentos, calendário, ocorrências, exceções/adicionais de frequência, pendências administrativas e permissões excepcionais** sobre o `JAVA.zip` atual, sem alterar o backend.

## Implementado

- fechamento assíncrono integrado à tela de frequência, incluindo criação, recuperação do fechamento atual, consulta por ID, polling, percentual/progresso, cancelamento e reprocessamento;
- recuperação do fechamento em andamento após recarga da página;
- bloqueio visual do fechamento enquanto houver rascunhos locais não salvos, sem substituir a validação autoritativa do Java;
- calendário de eventos preservando tipos devolvidos/aceitos pelo Java em vez de impor enum restritivo no navegador;
- ocorrências multipart com `empregadoId`, `motivo`, `dataOcorrencia`, `observacao`, `tipoRo`, `numeroSei`, `dias` e múltiplos `anexos`;
- tela **Exceções e adicionais de frequência** consumindo `/frequencias-excecoes` e `/frequencias-adicionais`;
- central de **Pendências Administrativas**, com listagem, resumo, filtros, início de tratamento e confirmação de resolução;
- tela de **Permissões Excepcionais**, com os cinco tipos definidos no Java, concessão, revogação e histórico de usos quando autorizado;
- navegação/menu/rotas derivados das capacidades observadas no Java, sempre fail-closed;
- cancelamento de respostas antigas com `AbortController` nos fluxos assíncronos relevantes;
- mutações novas com `retries: 0`, evitando repetição cega de comandos.

## Autoridade do backend

O React não recalcula regras de fechamento, escopo, estado, sobreposição, expiração, finalidade, elegibilidade ou resolução. O Java continua sendo a autoridade final para todas essas decisões.

## Java

**Nenhum arquivo Java foi alterado.**
