# Compatibilidade legada — Etapa 14

Este arquivo registra código mantido deliberadamente por compatibilidade com contratos ainda existentes no Java. Esses pontos **não devem ser tratados como modelo canônico novo**.

## 1. `empregadoId` em ocorrências

O endpoint `POST /api/ocorrencias` ainda recebe `empregadoId` como parâmetro obrigatório. Por isso o React mantém busca de `/empregados` para selecionar a projeção exigida pelo comando.

**Onde:** `src/services/rh/ServicoOcorrencia.js` e `src/modules/rh/pages/PaginaOcorrencias/`.

**Remover quando:** o Java expuser Pessoa/Vínculo Contratual como identidade canônica do comando de ocorrência.

## 2. `empregadoId` em exceções e adicionais de frequência

`FrequenciaExcecaoDTO` e `FrequenciaAdicionalDTO` ainda possuem `empregadoId`. A tela de ajustes usa a projeção de empregado apenas para preencher esse contrato.

**Onde:** `src/modules/rh/pages/PaginaAjustesFrequencia/`, `ServicoExcecaoFrequencia` e `ServicoAdicionalFrequencia`.

**Remover quando:** os DTOs/comandos Java passarem a usar a identidade canônica definida para Pessoa/Vínculo.

## 3. aliases nominais de Empregado

A migração iniciada na Etapa 11 mantém aliases de capacidade `podeVisualizarEmpregados`/`podeGerenciarEmpregados` e a rota antiga `/empregados` redirecionando para `/pessoas`. Isso existe para compatibilidade entre módulos antigos enquanto a projeção de Empregado ainda é consumida por frequência/relatórios.

**Remover quando:** nenhum módulo funcional depender mais da projeção/nomes históricos de Empregado.

## 4. aliases de tokens visuais

`src/styles/tokens.css` conserva aliases de tokens do React legado para permitir migração gradual dos módulos sem quebrar o padrão visual Correios.

**Remover quando:** todos os módulos tiverem migrado para os tokens canônicos e a busca estática confirmar ausência de referências aos aliases.

## Regra de governança

Compatibilidade legada não concede permissão adicional, não cria regra negocial e não autoriza mudança no Java. Cada item deve ser removido somente quando o contrato Java correspondente deixar de exigi-lo e os testes de integridade confirmarem a migração.
