# Matriz de permissões observada — Etapa 14

A tabela abaixo reflete os matchers/controladores/serviços do Java atual. A autorização efetiva continua dependente de escopo, data, estado e validações internas do backend.

| Fluxo | Administrador | Gestor Nacional | Presidente | Gestor Estadual | Gestor Local | Operacional |
|---|---:|---:|---:|---:|---:|---:|
| Ler calendário | sim | sim | sim | sim | sim | sim |
| Alterar calendário | não | não | não | não | sim | não |
| Ler ocorrências | sim | sim | não | sim | sim | sim |
| Criar/excluir ocorrência | não | não | não | não | sim | não |
| Ler exceções/adicionais | sim | sim | não | sim | sim | sim |
| Criar/alterar/excluir exceções/adicionais | não | não | não | não | sim | não |
| Ler fechamento de frequência | sim | sim | não | sim | sim | sim |
| Criar/cancelar/reprocessar fechamento | não | não | não | não | sim* | sim* |
| Ler/tratar pendências administrativas | sim | sim | não | sim | sim | não |
| Ler permissões excepcionais | sim | sim | sim | sim | sim | não |
| Conceder/revogar permissões excepcionais | sim | não | não | não | não | não |
| Ler usos de permissão excepcional | sim** | não | não | não | não | não |

\* O matcher HTTP de `/api/frequencias/**` admite Gestor Local e Operacional em mutações, mas o serviço ainda aplica `exigirFrequenciaDiaria`, data e escopo. O React não antecipa aprovação negocial.

\** O matcher GET é mais amplo, porém `PermissaoExcepcionalServico.listarUsos` exige Administrador; o React segue a regra mais restritiva e falha fechado.

## Confirmação de senha (`@ExigirSenha`)

- calendário: criar/atualizar/excluir;
- fechamento: criar e reprocessar; **cancelamento não exige senha**;
- exceções/adicionais: criar/atualizar/excluir;
- ocorrências: criar/excluir;
- permissões excepcionais: conceder/revogar;
- pendências administrativas: iniciar tratamento e confirmar resolução **não possuem `@ExigirSenha` no Java atual**.
