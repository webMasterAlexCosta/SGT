# Próxima etapa — Etapa 15

## Painel e cálculos gerenciais

Pré-requisito: Etapa 14 aprovada e frequência/pendências estáveis.

Escopo do planejamento consolidado:

- validar `PainelCalculoControlador` e `PainelControlador`;
- consumir os **8 endpoints** associados à etapa;
- filtros canônicos de contrato/lotação/jornada/cargo/data;
- opção **Todos** e painéis separados quando exigido;
- previsto, presentes, ausentes e pendentes usando valores retornados pelo Java;
- navegação temporal entre dias;
- leitura nacional de Gestor Nacional/Presidente e escopo estadual/local conforme backend;
- eliminar dependência de refresh para atualização de filtros/estado;
- manter linha, barra, dispersão e infográfico somente com dados suportados, com alternativa tabular acessível;
- exportação no mesmo recorte do painel;
- polling/cálculo assíncrono sem duplicação de consultas e com cancelamento de contexto obsoleto.

Princípio: **nenhuma fórmula gerencial autoritativa será recriada no React.**
