# Origem documental — Etapa 14

- Fonte local validada: `/mnt/data/work_sgt_react/etapa14/SGT_GTRAT_REACT_ETAPA_14`.
- Conteúdo preservado sem reescrita das pastas documentais/evidências.
- Arquivos recuperados desta fonte: **26**.
- Em conflito, prevalecem o Java atual e a documentação final da Etapa 18.
