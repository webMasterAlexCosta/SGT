# SGT/GTRAT React — Etapa 14

Entrega da **Etapa 14 — Fechamentos, calendário, ocorrências, pendências e permissões excepcionais**.

## Fonte de verdade

O `JAVA.zip` fornecido é a fonte de verdade. Nenhuma alteração no Java foi necessária para esta etapa.

## Estrutura

- `01_REACT_ETAPA_14/`: fonte React da etapa;
- `02_DOCUMENTACAO_ETAPA_14/`: alterações, endpoints, permissões, rastreabilidade, legado, riscos e próximo passo;
- `04_REACT_ETAPA_13_REFERENCIA/`: documentação da baseline anterior preservada;
- `05_EVIDENCIAS_TESTES/`: logs dos gates executados;
- `06_ENTRADAS_ORIGINAIS/`: entradas relevantes recebidas, sem duplicar o pacote grande de dependências offline.

## Gate

Etapa aprovada para seguir à Etapa 15. Consulte `02_DOCUMENTACAO_ETAPA_14/STATUS_GATE_ETAPA_14.md`.

## Dependências

O pacote de dependências offline Node 22.16.0 foi enviado separadamente pelo usuário e não é duplicado neste ZIP.
