# Orçamento de bundle React

- JS total: 3756.8 KB (1053.4 KB gzip)
- CSS total: 520.1 KB
- Maior JS: assets/vendor-face-BvM7HRcj.js — 1283.8 KB (318.3 KB gzip)
- Violações: 0
- Avisos de otimização: 1

## Avisos de otimização

- Chunk pesado para revisão: assets/vendor-face-BvM7HRcj.js (1314597 bytes / 325931 gzip).

## Maiores arquivos

- `assets/vendor-face-BvM7HRcj.js`: 1283.8 KB / 318.3 KB gzip
- `assets/vendor-core-C0u3_FJt.js`: 493.5 KB / 143.9 KB gzip
- `assets/vendor-charts-lvNgAyK2.js`: 422.1 KB / 117.6 KB gzip
- `assets/vendor-pdf-BZmyc6F0.js`: 349.4 KB / 112.4 KB gzip
- `assets/vendor-react-6TxKP9aR.js`: 211.5 KB / 67.3 KB gzip
- `assets/pages-B4lsF8e4.js`: 176.8 KB / 45.1 KB gzip
- `assets/index-WtXUyw_u.js`: 126.2 KB / 41.0 KB gzip
- `assets/PaginaContratos-DRsy-18I.js`: 77.4 KB / 19.0 KB gzip
- `assets/index-BT1j9PDR.css`: 76.6 KB / 15.7 KB gzip
- `assets/pages-0TLfp-Ex.css`: 62.5 KB / 11.4 KB gzip
- `assets/EmpregadosLista-BQWrr9Lu.js`: 52.6 KB / 14.4 KB gzip
- `assets/PaginaFrequencia-C-_Rz2YC.js`: 52.5 KB / 16.1 KB gzip
- `assets/EmpregadosLista-CwrJ_Np2.css`: 42.0 KB / 7.8 KB gzip
- `assets/vendor-icons-IcjTXsxG.js`: 41.7 KB / 12.1 KB gzip
- `assets/FormularioEmpregado-CyE0Em1k.js`: 41.3 KB / 10.3 KB gzip
- `assets/PaginaFrequencia-BedYu8PB.css`: 38.2 KB / 7.0 KB gzip
- `assets/PaginaTurnos-BZiY5Pkw.js`: 34.2 KB / 10.3 KB gzip
- `assets/PaginaContratos-BcypfwkR.css`: 34.0 KB / 6.9 KB gzip
- `assets/Login-DBmH76ho.js`: 33.5 KB / 10.1 KB gzip
- `assets/PaginaRelatorioAbsenteismo-Dc2nbes2.js`: 33.3 KB / 8.8 KB gzip
