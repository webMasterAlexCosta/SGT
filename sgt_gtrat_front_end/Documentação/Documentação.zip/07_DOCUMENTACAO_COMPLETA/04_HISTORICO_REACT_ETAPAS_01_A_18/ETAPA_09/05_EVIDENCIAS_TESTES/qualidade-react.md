# Auditoria estática de qualidade React

- Arquivos analisados: 230
- Erros de gate: 0
- Avisos de otimização: 1

- **AVISO** `MODULO_MUITO_GRANDE` — `src/modules/rh/pages/PaginaFrequencia/useLogicaFrequencia.js`: 1237 linhas. Avaliar divisão para reduzir custo cognitivo e rerenderizações acopladas.
