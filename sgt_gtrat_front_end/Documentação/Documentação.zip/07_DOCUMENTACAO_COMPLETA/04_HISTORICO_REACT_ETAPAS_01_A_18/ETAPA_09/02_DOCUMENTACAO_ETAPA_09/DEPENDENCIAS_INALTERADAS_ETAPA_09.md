# Dependências — Etapa 09

Comparação Etapa 08 × Etapa 09:

- `package.json`: idêntico
- `package-lock.json`: idêntico
- `.node-version`: idêntico
- `.nvmrc`: idêntico

Nenhuma dependência npm foi adicionada/removida nesta etapa. Node permanece em **22.16.0**.
