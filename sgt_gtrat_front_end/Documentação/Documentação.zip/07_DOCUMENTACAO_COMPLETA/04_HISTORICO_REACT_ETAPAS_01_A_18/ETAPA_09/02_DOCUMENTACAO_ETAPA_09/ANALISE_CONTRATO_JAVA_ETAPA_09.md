# Análise do contrato Java — Etapa 09

O Java separa três grupos de API com cinco endpoints cada.

## Composição

`/api/contratos/{contratoId}/composicoes` permite consulta temporal e monitor de excedentes. POST/PUT/DELETE possuem `@ExigirSenha` e o serviço Java restringe CRUD direto ao rascunho acessível. Quantidade negativa é inválida; **zero é aceito**.

## Aditamentos

A confirmação depende de prévia gerada pelo servidor. A requisição final transporta `tokenPrevia`. O token representa também a versão/contexto corrente; quando o estado relevante muda, a confirmação falha e o frontend deve recalcular. A prévia informa redução, piso normal de 25%, necessidade de exceção, ocupação afetada, alertas e composição resultante.

## Remanejamentos

O Java exige pelo menos duas composições válidas, variações diferentes de zero e soma das variações igual a zero. Quantidade resultante não pode ser negativa. A prévia também é autoritativa e tem token. O frontend não deve mover colaboradores para “resolver” impacto.

## Concorrência

A Etapa 09 trata `409 Conflict` como perda de validade da prévia: invalida o contexto local e exige nova prévia. Não há retry cego de mutação.

## Segurança

As mutações de composição, registro/retificação/cancelamento de aditamento e remanejamento usam o fluxo central de confirmação de senha (`@ExigirSenha`) já implementado nas etapas anteriores. Consultas permanecem em modo leitura conforme a matriz canônica de perfis.
