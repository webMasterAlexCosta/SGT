# Permissões — Etapa 09

| Perfil | Consultar | Composição direta em rascunho | Aditamento/Remanejamento |
|---|---:|---:|---:|
| Administrador | Sim | Não | Não |
| Gestor Nacional | Sim | Não | Não |
| Presidente | Sim | Não | Não |
| Gestor Estadual | Sim | Não | Não |
| Gestor Local | Sim | Sim, no seu escopo e quando o Java permite | Sim, no seu escopo |
| Operacional | Sim | Não | Não |

A UI usa capacidades semânticas; o backend continua sendo a autoridade final de autorização e escopo.
