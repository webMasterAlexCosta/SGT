# SGT/GTRAT React — Etapa 09 — Alterações

## Escopo

Etapa 09 implementa **Composição Contratual, Excedentes, Aditamentos e Remanejamentos** sobre a baseline final da Etapa 08, sem alterar o backend Java e sem iniciar a Etapa 10.

## Implementação

- Serviço HTTP dedicado aos **15 endpoints** de `ComposicaoContratualControlador`, `AditamentoContratualControlador` e `RemanejamentoContratualControlador`.
- Painel no detalhe do contrato com abas **Composição**, **Aditamentos** e **Remanejamentos**.
- Composição explícita Lotação + Jornada/Turno + Cargo + efetivo previsto e vigência; efetivo zero é permitido e representa indisponibilidade para nova alocação conforme o backend.
- Monitor de excedentes com quantidade prevista/vinculada, excedente, início e justificativas quando fornecidos pelo Java.
- CRUD direto de composição somente quando o contrato está em **rascunho**; após publicação, alterações quantitativas seguem fatos negociais versionados.
- Aditamento e remanejamento em máquina de estados **editar → calcular prévia → revisar → confirmar**.
- `tokenPrevia` nunca é reutilizado após qualquer edição; HTTP 409 invalida a prévia e obriga novo cálculo.
- Prévia de aditamento exibe efetivo anterior/resultante, piso normal de redução de 25%, redução excepcional, impactos de ocupação e alertas do servidor.
- Remanejamento exige pelo menos duas composições, variações não nulas e soma igual a zero, preservando o efetivo total.
- Retificação e cancelamento futuro preservam histórico e usam os endpoints próprios do Java.
- **Nenhuma pessoa é movimentada automaticamente no frontend**.
- Linhas mutáveis usam chave de cliente estável, evitando reconciliação incorreta do React ao excluir itens intermediários.

## Arquivos centrais

- `src/services/admin/ServicoAlteracoesContrato.js`
- `src/services/admin/ServicoDominioAlteracoesContrato.js`
- `src/modules/admin/pages/PaginaContratos/components/PainelAlteracoesContrato/`
- `src/modules/admin/pages/PaginaContratos/components/ModalDetalhesContrato/index.jsx`
- testes focais/integrados da Etapa 09 e fixtures de componentes.

## Backend

O Java de referência foi apenas lido/validado. **Nenhum arquivo Java foi modificado.**
