# Pendências e riscos — Etapa 09

1. **XLSX de frequência no Java:** o gate integrado continua com uma única falha preexistente ligada a `XlsxStreamingWriter`. Fora do escopo da Etapa 09.
2. **RFE-CMP-006/007/009:** tratamento completo de vínculos, programações futuras e autorização de inclusão de pessoas acima do previsto cruza as etapas de Pessoas/Vínculos/Alocações. Nesta etapa o impacto é exibido e não há movimentação automática.
3. **RFE-ADI-008:** impactos de retificação são mostrados, porém gestão completa de pendências cruza módulos posteriores.
4. **RFE-REM-005:** `referenciaSei` é suportada; anexo documental opcional pertence à Etapa 10.
5. **Chunk `vendor-face`:** aviso antigo de tamanho acima de 1 MB permanece; o budget formal do projeto passa.
