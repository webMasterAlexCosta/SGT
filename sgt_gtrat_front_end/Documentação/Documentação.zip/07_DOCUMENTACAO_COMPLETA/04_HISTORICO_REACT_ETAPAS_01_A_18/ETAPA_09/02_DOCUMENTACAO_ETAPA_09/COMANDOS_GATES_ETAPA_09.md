# Comandos/gates — Etapa 09

A execução final utilizou o cache npm offline fornecido pelo usuário e o Java extraído de `JAVA(3).zip`.

Principais gates: instalação offline, runtime, configuração, testes focais, testes integrados focais, unitários, componentes, Camada 2, Camada 3, nomenclatura, análise estática, bundle/budget, segredos e integridade React × Java.

O gate de integridade retorna código 1 exclusivamente pela falha XLSX preexistente do backend. Os logs brutos estão em `05_EVIDENCIAS_TESTES`.
