# Matriz de prévia e concorrência

| Situação | Comportamento React | Autoridade |
|---|---|---|
| Usuário edita campo após prévia | Invalida imediatamente token/assinatura local | React impede confirmação com snapshot antigo |
| Prévia válida e dados inalterados | Confirma usando exatamente `tokenPrevia` retornado | Java revalida |
| HTTP 409 na confirmação | Descarta prévia e exige recalcular | Java |
| Ocupação mudou entre prévia e confirmação | Não força resultado; nova prévia | Java |
| Mutação falha/estado incerto | Sem retry automático cego | Java/usuário |
| Redução impacta ocupação | Exibe impactos e exige confirmação explícita quando aplicável | Java |
| Remanejamento não soma zero | Bloqueio local de UX e validação definitiva no Java | Java é autoridade final |
