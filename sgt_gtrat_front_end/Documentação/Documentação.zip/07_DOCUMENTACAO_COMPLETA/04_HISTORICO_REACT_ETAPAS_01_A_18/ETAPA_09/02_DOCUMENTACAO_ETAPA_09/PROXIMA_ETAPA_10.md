# Próxima etapa — Etapa 10

**Contratos — documentos, transferências e correções excepcionais**.

Escopo documental previsto: **19 endpoints** dos controladores `ContratoControlador` (3), `CorrecaoIdentificadorContratoControlador` (3) e `DocumentoComprobatorioControlador` (13).

Principais itens: documentos versionados, multipart/anexo/SEI, download, finalidade de acesso restrito, permissões documentais, transferência excepcional de Gestão Local, correção de identificador e correção de anulação por relação de precedência.

A Etapa 10 **não foi iniciada** neste pacote.
