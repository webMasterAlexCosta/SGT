# Composição e excedentes — Etapa 09

- A composição é explícita: **Lotação + Jornada/Turno + Cargo + efetivo**.
- Não há produto cartesiano automático no frontend.
- `efetivoPrevisto = 0` é representação válida e não significa exclusão histórica.
- O monitor de excedentes usa exclusivamente os valores calculados pelo Java.
- Excedente não é convertido pelo frontend em bloqueio rígido genérico.
- Se uma redução afeta ocupação, o React mostra o impacto recebido e não realoca pessoas automaticamente.
- Para contratos publicados, mudanças negociais passam por aditamento/remanejamento e não por CRUD simplificado de composição.
