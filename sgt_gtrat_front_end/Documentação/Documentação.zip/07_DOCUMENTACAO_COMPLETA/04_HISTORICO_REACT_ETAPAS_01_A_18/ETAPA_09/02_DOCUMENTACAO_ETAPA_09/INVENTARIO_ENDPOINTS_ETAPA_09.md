# Inventário dos 15 endpoints — Etapa 09

Todos os 15 endpoints planejados foram integrados/validados.

| # | Controlador | Método | Endpoint | Senha | Status |
|---:|---|---|---|---|---|
| 1 | ComposicaoContratualControlador | GET | `/api/contratos/{contratoId}/composicoes` | NAO | INTEGRADO_VALIDADO |
| 2 | ComposicaoContratualControlador | GET | `/api/contratos/{contratoId}/composicoes/excedentes` | NAO | INTEGRADO_VALIDADO |
| 3 | ComposicaoContratualControlador | POST | `/api/contratos/{contratoId}/composicoes` | SIM | INTEGRADO_VALIDADO |
| 4 | ComposicaoContratualControlador | PUT | `/api/contratos/{contratoId}/composicoes/{id}` | SIM | INTEGRADO_VALIDADO |
| 5 | ComposicaoContratualControlador | DELETE | `/api/contratos/{contratoId}/composicoes/{id}` | SIM | INTEGRADO_VALIDADO |
| 6 | AditamentoContratualControlador | GET | `/api/contratos/{contratoId}/aditamentos` | NAO | INTEGRADO_VALIDADO |
| 7 | AditamentoContratualControlador | POST | `/api/contratos/{contratoId}/aditamentos/previa` | NAO | INTEGRADO_VALIDADO |
| 8 | AditamentoContratualControlador | POST | `/api/contratos/{contratoId}/aditamentos` | SIM | INTEGRADO_VALIDADO |
| 9 | AditamentoContratualControlador | POST | `/api/contratos/{contratoId}/aditamentos/{aditamentoId}/retificar` | SIM | INTEGRADO_VALIDADO |
| 10 | AditamentoContratualControlador | POST | `/api/contratos/{contratoId}/aditamentos/{aditamentoId}/cancelar` | SIM | INTEGRADO_VALIDADO |
| 11 | RemanejamentoContratualControlador | GET | `/api/contratos/{contratoId}/remanejamentos` | NAO | INTEGRADO_VALIDADO |
| 12 | RemanejamentoContratualControlador | POST | `/api/contratos/{contratoId}/remanejamentos/previa` | NAO | INTEGRADO_VALIDADO |
| 13 | RemanejamentoContratualControlador | POST | `/api/contratos/{contratoId}/remanejamentos` | SIM | INTEGRADO_VALIDADO |
| 14 | RemanejamentoContratualControlador | POST | `/api/contratos/{contratoId}/remanejamentos/{remanejamentoId}/retificar` | SIM | INTEGRADO_VALIDADO |
| 15 | RemanejamentoContratualControlador | POST | `/api/contratos/{contratoId}/remanejamentos/{remanejamentoId}/cancelar` | SIM | INTEGRADO_VALIDADO |
