# SGT/GTRAT React — Etapa 16

Entrega da **Etapa 16 — Relatórios, emissões e exportações**.

## Fonte de verdade

O `JAVA_ATUAL.zip` desta entrega é a fonte de verdade para contrato HTTP, perfis, filtros, temporalidade, revisão, emissão, versionamento e arquivos. Nenhum arquivo Java foi alterado.

## Onde está o React

`01_REACT_ETAPA_16/`

## Documentação

`02_DOCUMENTACAO_ETAPA_16/` contém alterações, testes, matriz de permissões, endpoints, rastreabilidade, compatibilidade histórica/legada, riscos, possível bug Java e a próxima etapa.

## Dependências

`node_modules`, `dist` e `coverage` não fazem parte da fonte empacotada. Use o pacote de dependências offline já fornecido para Node 22.16.0.
