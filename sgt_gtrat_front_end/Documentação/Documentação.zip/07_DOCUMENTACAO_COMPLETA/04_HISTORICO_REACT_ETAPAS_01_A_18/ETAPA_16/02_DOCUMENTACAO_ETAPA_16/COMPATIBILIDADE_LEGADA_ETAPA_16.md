# Compatibilidade legada — Etapa 16

A Etapa 16 preserva apenas compatibilidades que ainda têm motivo verificável. O código produtivo novo não usa regra negocial antiga para contrariar o Java.

## Herdado das etapas anteriores

### `empregadoId` em ocorrências, exceções e adicionais

Os DTOs Java atuais ainda exigem `empregadoId` nesses comandos. A projeção Empregado permanece somente para esse contrato.

**Remover quando:** Java migrar os comandos para Pessoa/Vínculo Contratual canônicos.

### aliases nominais de Empregado

Aliases como `podeVisualizarEmpregados`, `podeGerenciarEmpregados` e o redirecionamento histórico `/empregados` → `/pessoas` permanecem enquanto módulos antigos ainda os referenciam.

**Remover quando:** a Etapa 17 confirmar zero consumidores.

### aliases de tokens visuais

`src/styles/tokens.css` conserva aliases do React antigo para migração gradual sem perder o padrão Correios.

**Remover quando:** busca estática provar uso exclusivo dos tokens canônicos.

## Compatibilidade específica de relatórios

### `consolidarAbsenteismo`

A função permanece exportada por compatibilidade com testes/performance antigos, porém **não é usada pela página produtiva** para calcular o resumo oficial. A tela usa os registros paginados e o resumo Java.

**Remover quando:** Etapa 17 migrar os testes históricos e confirmar ausência de import produtivo.

### fallback síncrono de frequência/absenteísmo

`iniciarDownloadNativo` e os helpers `obterUrlExportacaoFrequencia/Absenteismo` ainda preservam o endpoint síncrono Java caso o helper de exportação seja chamado fora do provedor de jobs. O fluxo normal da aplicação usa solicitação assíncrona.

**Remover quando:** inventário final da Etapa 17 decidir que nenhum fluxo suportado necessita fallback síncrono.

### helper síncrono de terceirizados

`ServicoRelatorioTerceirizados.obterUrlExportacao` permanece como cobertura auxiliar do endpoint Java síncrono, mas a página produtiva usa o job assíncrono.

**Remover ou manter:** decisão final na Etapa 17, quando os 282 endpoints forem classificados.

## Legado removido nesta etapa

O arquivo de geração local `PaginaRelatoriosTerceirizados/exportacao.js` foi removido. Não deve ser restaurada exportação oficial calculada/montada no browser para a página atual, pois o Java não expõe esse recorte de arquivo.

## Governança

Compatibilidade nunca amplia permissão, nunca substitui cálculo Java e nunca autoriza endpoint inventado.
