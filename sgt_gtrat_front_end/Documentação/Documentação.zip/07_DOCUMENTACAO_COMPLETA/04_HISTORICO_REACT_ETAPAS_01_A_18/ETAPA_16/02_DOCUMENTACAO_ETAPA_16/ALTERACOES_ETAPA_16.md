# Alterações — Etapa 16

## Escopo

Etapa **16 — Relatórios, emissões e exportações**, executada sobre a baseline aprovada da Etapa 15.

O **Java atual permanece como fonte de verdade**. O React não recalcula indicadores oficiais, não amplia perfil e não inventa endpoint de arquivo.

## Implementações realizadas

### 1. Inventário dos 22 endpoints

Foram confrontados diretamente `RelatorioControlador` (16 endpoints) e `RelatorioAdministrativoControlador` (6 endpoints). A decisão endpoint por endpoint está em `ENDPOINTS_ETAPA_16.csv`.

### 2. Separação correta entre relatórios operacionais e administrativos

`podeAcessarRelatorios` passou a refletir os métodos operacionais efetivos: Administrador, Gestor Nacional, Gestor Estadual e Gestor Local. Presidente não recebe essas telas apenas porque o matcher geral `/api/relatorios/**` é mais amplo.

Foi criada a capacidade separada `podeAcessarRelatoriosAdministrativos`, que admite Administrador, Gestor Nacional, Presidente, Gestor Estadual e Gestor Local. A emissão formal mantém outra capacidade e exclui Presidente conforme o `@PreAuthorize` do Java.

### 3. Emissões administrativas

Nova página `PaginaRelatoriosAdministrativos` no padrão visual Correios, com:

- prévia atual;
- emissão formal idempotente;
- histórico versionado;
- natureza `ORIGINAL` / `RETIFICADA`;
- estado `VIGENTE` / `SUPERADA`;
- consulta **conhecida até** por instante;
- comparação do snapshot com o recorte vigente;
- hash e metadados da emissão;
- indicação `SUJEITO A REVISÃO` e quantidade de pendências;
- paginação até 200, que é o máximo Java.

O React informa explicitamente que `XLSX`/`PDF` nessa série são metadados da emissão persistida. O controlador administrativo **não possui endpoint binário de download**, portanto a interface não inventa um.

### 4. Presidente em modo leitura

Presidente pode pré-visualizar, listar e consultar por `conhecidoAte` em escopo nacional. Emissão formal é desabilitada conforme Java.

Foi encontrada inconsistência adicional no serviço Java: `obter(id)` e `compararComVigente(id)` chamam `exigirAcesso`, que não possui ramo Presidente. O React falha fechado e desabilita essas ações para Presidente; o achado foi documentado em `POSSIVEL_BUG_JAVA_ETAPA_16.md`.

### 5. Paginação conforme limites reais

- Frequência consolidada: 25 / 100 / 200 / 500;
- Absenteísmo: 25 / 100 / 200 / 500;
- Terceirizados: 25 / 50 / 100 / 200 / 1000 / 2000 / 5000 / Todos, sendo “Todos” navegação em blocos de no máximo 5.000;
- Emissões administrativas: 25 / 50 / 100 / 200.

O React não oferece 1000/2000/5000 onde o serviço Java limita a página a 500 ou 200.

### 6. Revisão e pendências

Frequência e absenteísmo passaram a apresentar diretamente `AvisoRevisaoRelatorioDTO` devolvido pelo backend. Absenteísmo deixou de consolidar a página parcial como se fosse o total oficial; o resumo geral vem do endpoint Java de resumo.

### 7. Exportações oficiais e jobs

Frequência, absenteísmo e terceirizados usam o fluxo assíncrono Java:

1. POST de solicitação;
2. identificador do job;
3. polling de status/progresso;
4. restauração do job após reload da sessão;
5. download pelo endpoint oficial quando `podeBaixar`;
6. remoção local quando o Java responde 403/404 ao job expirado/inacessível.

Foi adicionada deduplicação **somente de solicitações simultâneas idênticas**, evitando dois jobs por duplo clique. Os endpoints Java não recebem chave de idempotência para exportação, então o React não simula idempotência permanente.

### 8. Correção da exportação de terceirizados

A Etapa 15 ainda possuía geração PDF/XLSX da **página atual no navegador**. O Java não oferece `page/size` nos endpoints de exportação de terceirizados; logo não existe arquivo oficial de “página atual”.

Esse gerador local foi removido. Os botões Excel/PDF agora sempre solicitam o **resultado filtrado completo** ao job Java e permanecem disponíveis em qualquer página da consulta.

### 9. Demais endpoints

Os endpoints não paginados de frequência/absenteísmo e `/horas-trabalhadas` permanecem cobertos no serviço React para o contrato da etapa. `/horas-trabalhadas` é auxiliar e não ganhou uma tela artificial separada; exige contrato/competência e possui perfil mais restrito no Java.

## Java

**Nenhum arquivo Java foi alterado.**
