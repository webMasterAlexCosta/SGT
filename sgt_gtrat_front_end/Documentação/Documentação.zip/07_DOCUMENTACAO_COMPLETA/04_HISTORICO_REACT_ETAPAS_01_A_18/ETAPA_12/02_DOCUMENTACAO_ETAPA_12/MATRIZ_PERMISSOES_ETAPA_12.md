# Matriz de permissões — Etapa 12

| Capacidade de API | Administrador | Gestor Nacional | Gestor Estadual | Gestor Local | Presidente | Operacional |
|---|---:|---:|---:|---:|---:|---:|
| Listar faixas de alocação | Sim | Sim | Sim | Sim | Não | Sim |
| Ler eventos de alocação | Sim | Sim | Sim | Sim | Não | Sim |
| Consultar posição bitemporal | Sim | Sim | Sim | Sim | Não | Sim |
| Consultar opções de alocação | Sim | Sim | Sim | Sim | Não | Sim |
| Gerar prévia de alteração | Não | Não | Não | Sim | Não | Não |
| Alterar alocação | Não | Não | Não | Sim | Não | Não |
| Retificar faixa | Não | Não | Não | Sim | Não | Não |
| Cancelar programação futura | Não | Não | Não | Sim | Não | Não |

As permissões acima reproduzem o `VinculoContratualControlador`. A navegação da página de gestão de Pessoas/Vínculos continua limitada aos perfis gerenciais definidos na Etapa 11; a leitura Operacional dos endpoints poderá ser consumida pela grade de frequência na Etapa 13 sem conceder comandos gerenciais. A autorização final e o escopo permanecem no Java.
