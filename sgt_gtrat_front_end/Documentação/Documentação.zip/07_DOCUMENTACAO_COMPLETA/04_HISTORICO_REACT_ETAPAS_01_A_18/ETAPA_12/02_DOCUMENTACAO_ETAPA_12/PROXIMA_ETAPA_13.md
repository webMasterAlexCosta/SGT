# Próxima etapa — Etapa 13

## Frequência diária, lote e operação de grande volume

Usar o React desta entrega como baseline e executar a Etapa 13 do planejamento consolidado:

- migrar payload individual e em lote para `vinculoContratualId`;
- usar a projeção de empregados apenas quando necessária à grade operacional, sem identidade paralela de escrita;
- implementar filtros por data, contrato, lotação, jornada/turno e busca conforme a API;
- exibir estados oficiais previsto/lançado/pendente, validade e revisão quando fornecidos;
- remover qualquer autoridade local da janela oficial de edição e seguir a resposta do Java;
- implementar lançamento individual e lote respeitando o limite/tamanho oficial do endpoint;
- tratar jornada noturna pela data de início;
- bloquear double-submit, não repetir timeout cegamente e explicar falhas parciais;
- otimizar paginação/renderização para mais de 40 mil colaboradores sem carregar todo o DOM;
- executar os testes mínimos do planejamento: Operacional dentro/fora da janela, Gestor Local retificação, lote, data noturna, vínculo sem alocação, desligamento retroativo, sujeito a revisão, 40k+ sintético e 403 de escopo.

### Escopo previsto

O planejamento associa **7 endpoints** à Etapa 13, distribuídos entre `EmpregadoControlador` (1 projeção de apoio) e `FrequenciaControlador` (6). Antes de alterar a página atual de frequência, reler DTOs, limites e permissões do Java anexado.

**Gate:** frequência canônica, escalável e sem regra crítica local conflitante.
