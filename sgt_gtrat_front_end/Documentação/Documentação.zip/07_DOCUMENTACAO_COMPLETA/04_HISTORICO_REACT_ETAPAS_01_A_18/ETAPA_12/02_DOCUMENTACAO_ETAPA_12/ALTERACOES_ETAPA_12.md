# Alterações — Etapa 12

## Escopo

Alocações temporais do vínculo contratual: Lotação + Jornada/Turno + Cargo como faixas temporais, conforme a Etapa 12 do planejamento consolidado e o contrato Java anexado.

## Implementado

- Linha temporal de alocações dentro do detalhe do Vínculo, sem voltar ao agregado legado `Empregado` como fonte de escrita.
- Filtro mensal usando `yyyy-MM`, conforme `YearMonth` do Java.
- Lista das faixas com Lotação, Jornada, Cargo, início, fim e estado negocial retornados pela API.
- Histórico de eventos de alocação com data efetiva, data de registro, relação do evento e fotografias anterior/nova quando fornecidas.
- Consulta bitemporal da posição da alocação por `data` e `conhecidoAte`.
- Opções encadeadas contrato → lotação → jornada → cargo na data efetiva.
- Proteção contra corrida nas opções encadeadas com `AbortController` e chave de contexto independente por nível.
- Ausência de fallback local quando o Java não devolve composição válida/efetivo para o recorte.
- Capacidade, ocupação e excedente exibidos exclusivamente a partir do `OpcaoAlocacaoTemporalDTO`; o React não recalcula a autoridade do servidor.
- Prévia de impacto antes da alteração/retificação, com exibição de impactos e incompatibilidades.
- Token da prévia invalidado visualmente quando data, composição ou campos auditáveis mudam.
- Alteração interna da alocação usando o mesmo `vinculoContratualId`, sem desligamento/recontratação.
- Retificação formal da faixa na mesma data inicial; a data fica bloqueada no formulário para impedir retificação da faixa errada.
- Cancelamento apenas sugerido para programação futura em estado `REGISTRADA`; o Java continua sendo a autoridade final e restaura a predecessora.
- Confirmação explícita `confirmarPrecedenciaUltimoDia` quando a data efetiva coincide com o último dia do vínculo.
- Mutações sem retry automático, integradas ao fluxo central de confirmação de senha/CSRF.
- Mensagem específica para HTTP 409 e resultado incerto, orientando releitura em vez de repetição cega.
- Fixtures de componentes atualizadas para que o novo modal participe dos testes gerais de renderização, comportamento e robustez.

## Arquivos principais

- `src/modules/rh/pages/PaginaPessoasVinculos/components/ModalAlocacoesVinculo.jsx`
- `src/modules/rh/pages/PaginaPessoasVinculos/components/ModalVinculo.jsx`
- `src/modules/rh/pages/PaginaPessoasVinculos/index.jsx`
- `src/modules/rh/pages/PaginaPessoasVinculos/index.module.css`
- `src/services/rh/ServicoDominioAlocacaoVinculo.js`
- `src/services/rh/ServicoVinculoContratual.js`
- `test/vitest/alocacoesEtapa12.test.js`
- `test/alocacoesEtapa12.test.js`

## Decisões preservadas

- O Java é a fonte de verdade para cobertura temporal, sobreposição/lacuna, catálogo vigente, capacidade, excedente, escopo, concorrência e transições.
- A linha histórica renderiza os dados persistidos da faixa; ela não depende das opções atualmente ativas do catálogo.
- Datas de negócio permanecem `LocalDate` (`yyyy-MM-dd`) sem conversão de fuso no payload. `conhecidoAte` é enviado como instante ISO quando informado.
- Senha nunca integra DTO de alocação. A confirmação continua no núcleo HTTP de segurança já existente.
- Frequência e consumidores de grande volume não foram antecipados; sua migração canônica pertence à Etapa 13.
