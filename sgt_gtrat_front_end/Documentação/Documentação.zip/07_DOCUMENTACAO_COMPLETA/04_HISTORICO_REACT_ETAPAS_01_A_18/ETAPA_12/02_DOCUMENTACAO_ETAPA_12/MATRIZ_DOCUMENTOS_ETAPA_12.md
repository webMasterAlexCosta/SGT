# Matriz de documentos — Etapa 12

| Documento | Finalidade |
|---|---|
| `ALTERACOES_ETAPA_12.md` | implementação realizada |
| `ANALISE_CONTRATO_JAVA_ETAPA_12.md` | contrato Java aplicado |
| `ENDPOINTS_ETAPA_12.csv` | 8 endpoints e segurança |
| `RASTREABILIDADE_ETAPA_12.csv` | requisitos RFE-ALO-001..008 |
| `MATRIZ_PERMISSOES_ETAPA_12.md` | capacidades por perfil |
| `TESTES_ETAPA_12.md` | gates e resultados |
| `PENDENCIAS_RISCOS_ETAPA_12.md` | riscos e itens fora do escopo |
| `PROXIMA_ETAPA_13.md` | continuidade planejada |
| `DIFF_ETAPA_11_X_ETAPA_12.patch` | alterações de fonte |
| `DIFF_RESUMO_ETAPA_11_X_ETAPA_12.txt` | resumo de arquivos alterados |
| `SHA256SUMS_FONTE_ETAPA_12.txt` | integridade do fonte entregue |
