# Dependências — Etapa 12

- `package.json` e `package-lock.json` foram preservados em relação à Etapa 11.
- Nenhuma biblioteca nova foi adicionada para a Etapa 12.
- O pacote offline fornecido foi usado como cache de instalação.
- Runtime validado: Node 22.16.0, npm 10.9.2.
- Build validado com Vite 8.2.0.
