# Pendências e riscos — Etapa 12

## Fora do escopo desta entrega

- Migração da frequência para `vinculoContratualId`, lote e operação para mais de 40 mil colaboradores pertence à Etapa 13.
- Fechamentos, calendário, ocorrências, pendências e permissões excepcionais permanecem na Etapa 14.
- Painel e cálculos gerenciais permanecem na Etapa 15.
- O React não corrige nem altera o Java sem autorização específica.

## Pendência preexistente do Java

O gate integrado conserva uma única falha já documentada nas Etapas 10 e 11: a verificação do streaming XLSX de frequência espera a construção de `XlsxStreamingWriter` com limites explícitos em uma forma específica. A Etapa 12 não tocou em frequência, exportação ou Java.

## Riscos controlados

- **Resposta assíncrona fora de ordem:** cada nível das opções encadeadas possui `AbortController` e chave de contexto; resposta obsoleta não atualiza a seleção nova.
- **Prévia obsoleta:** mudança de data, composição, justificativa, evidência ou autorização descarta token e aceite.
- **Concorrência/capacidade:** valores são apresentados conforme o Java e revalidados pelo servidor na mutação.
- **Lacuna/sobreposição:** a UI não tenta calcular cobertura; o Java executa `garantirCobertura`.
- **Retificação da faixa errada:** a data de início da faixa alvo é fixada durante a retificação.
- **Cancelamento indevido:** o botão só aparece para programação futura `REGISTRADA`, mas o Java continua sendo a autoridade final.
- **Repetição após timeout:** mutações usam zero retry; resultado incerto exige conferência da linha temporal antes de nova ação.
- **Catálogo inativo histórico:** a linha histórica exibe os nomes salvos/retornados no DTO da faixa e não depende do catálogo vigente para conseguir ser lida.

## Observação de acesso

Os endpoints de leitura de alocação também aceitam o perfil Operacional no Java. A tela canônica de administração de Pessoas/Vínculos continua com a navegação gerencial herdada da Etapa 11 porque os endpoints de listagem/cadastro dessa tela não são uma grade operacional. O serviço React mantém os métodos de leitura desacoplados para consumo operacional no contexto canônico da Etapa 13, sem ampliar artificialmente permissões de escrita.
