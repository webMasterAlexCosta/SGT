# Análise do contrato Java — Etapa 12

## Fontes verificadas

- `VinculoContratualControlador`.
- `AlocacaoVinculoServico`.
- DTOs `AlocacaoVinculoDTO`, `EventoAlocacaoVinculoDTO`, `PosicaoAlocacaoTemporalDTO`, `OpcaoAlocacaoTemporalDTO` e `PreviaImpactoAlocacaoDTO`.
- Requisições `AlteracaoAlocacaoVinculoRequisicao` e `AcaoVinculoContratualRequisicao`.
- Inventário de endpoints e requisitos RFE-ALO-001 a RFE-ALO-008 do planejamento consolidado.

## Contrato aplicado

1. `GET /api/vinculos-contratuais/{id}/alocacoes` aceita `mes` como `YearMonth` no formato `yyyy-MM`.
2. Eventos da alocação possuem trilha própria e não devem ser reconstruídos a partir do estado atual.
3. A posição temporal recebe uma `LocalDate data` e um `Instant conhecidoAte` opcional, mantendo separadas efetividade e conhecimento.
4. Opções de alocação são resolvidas pelo Java na data efetiva e podem ser refinadas por `lotacaoId` e `jornadaId`.
5. `efetivoPrevisto`, ocupação, excedente e disponibilidade da opção vêm do backend; o frontend não inventa capacidade.
6. Prévia de alteração pode retornar incompatibilidades e impactos, inclusive preservação de eventos posteriores e revalidação de frequências históricas.
7. A confirmação exige o token/contexto atual da prévia e campos auditáveis; alterações no contexto devem forçar nova prévia.
8. Retificação exige que `dataEfetiva` seja exatamente o primeiro dia da faixa alvo. O Java registra evento de retificação e não apaga a história anterior.
9. Cancelamento é permitido somente para alocação futura ainda `REGISTRADA`; o serviço cancela a programação e restaura o limite da predecessora quando existente.
10. O serviço Java executa `garantirCobertura(vinculo)` após mutações e rejeita lacuna ou sobreposição. O React não replica essa decisão.
11. Quando a alteração ocorre no último dia do vínculo, `confirmarPrecedenciaUltimoDia=true` torna explícito que a nova alocação vale nesse dia e o desligamento produz efeito depois dele.
12. Mutações de alocação são exclusivas do Gestor Local e protegidas por senha no controlador; leituras dos quatro endpoints da etapa são autorizadas também a Administrador, Gestor Nacional, Gestor Estadual e Operacional, sempre dentro do escopo validado pelo Java.

## Java

Nenhum arquivo Java foi alterado. O Java anexado foi utilizado como contrato de referência e diretamente pelos testes estáticos integrados da Etapa 12.
