# Testes — Etapa 12

## Resultado dos gates

| Gate | Resultado |
|---|---:|
| Focais Vitest Etapa 12 | 7/7 |
| Integração focal React × Java Etapa 12 | 9/9 |
| Unitários Vitest | 110/110 |
| Componentes/smoke | 367/367 |
| Camada 2 — comportamento | 628/628 |
| Camada 3 — robustez/performance | 503/503 |
| Nomenclatura | 245 arquivos aprovados |
| Qualidade estática | 0 erros de gate, 1 aviso preexistente |
| Runtime oficial | aprovado — Node 22.16.0 / npm 10.9.2 |
| Build Vite | aprovado — Vite 8.2.0 |
| Bundle/budget | aprovado |
| Segredos no bundle | aprovado |
| Dependências (`npm ls --all`) | aprovado |
| Integridade React × Java | 324/325 |

## Única falha integrada

`exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão`

É a mesma falha preexistente já registrada nas Etapas 10 e 11. A asserção espera uma forma específica de construção do `XlsxStreamingWriter` no `RelatorioExportacaoServico` Java. Nenhum arquivo de frequência/Java foi modificado na Etapa 12.

## Aviso de qualidade

O único aviso estático continua sendo `src/modules/rh/pages/PaginaFrequencia/useLogicaFrequencia.js` com 1.237 linhas. O novo módulo de alocação não gerou erro nem aviso de gate.

## Cobertura específica da etapa

- oito endpoints temporais comparados com o `VinculoContratualControlador` real;
- filtro `YearMonth` e consulta `conhecidoAte`;
- opções encadeadas com cancelamento de requisição e chave de contexto por nível;
- invalidação de prévia/token após edição;
- mutações com `retries: 0` e senha fora do DTO;
- precedência explícita no último dia do vínculo;
- retificação fixada no primeiro dia da faixa e evento de retificação no Java;
- cancelamento somente de faixa futura registrada e restauração da predecessora no Java;
- prévia retroativa com eventos posteriores preservados e revalidação de frequência;
- catálogo histórico renderizado a partir da faixa persistida;
- opção sem efetivo/composição sem fallback local;
- capacidade e garantia de cobertura mantidas como autoridade do backend.

## Limite do teste ponta a ponta

Não foi levantada uma instância HTTP do backend com MySQL para um smoke de navegador nesta etapa. O contrato Java real foi validado estaticamente e todos os gates React foram executados. O smoke funcional com API/banco deve ser repetido no ambiente de integração/homologação.
