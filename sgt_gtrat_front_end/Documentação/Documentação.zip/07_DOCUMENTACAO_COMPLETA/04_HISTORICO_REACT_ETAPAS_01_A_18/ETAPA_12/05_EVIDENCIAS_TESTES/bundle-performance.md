# Orçamento de bundle React

- JS total: 3747.7 KB (1046.9 KB gzip)
- CSS total: 478.1 KB
- Maior JS: assets/vendor-face-BvM7HRcj.js — 1283.8 KB (318.3 KB gzip)
- Violações: 0
- Avisos de otimização: 1

## Avisos de otimização

- Chunk pesado para revisão: assets/vendor-face-BvM7HRcj.js (1314597 bytes / 325931 gzip).

## Maiores arquivos

- `assets/vendor-face-BvM7HRcj.js`: 1283.8 KB / 318.3 KB gzip
- `assets/vendor-core-C0u3_FJt.js`: 493.5 KB / 143.9 KB gzip
- `assets/vendor-charts-lvNgAyK2.js`: 422.1 KB / 117.6 KB gzip
- `assets/vendor-pdf-BZmyc6F0.js`: 349.4 KB / 112.4 KB gzip
- `assets/vendor-react-6TxKP9aR.js`: 211.5 KB / 67.3 KB gzip
- `assets/pages-iCuJXgsF.js`: 176.8 KB / 45.1 KB gzip
- `assets/index-q6t_IW9G.js`: 126.1 KB / 41.1 KB gzip
- `assets/PaginaContratos-B3LgVhwp.js`: 104.9 KB / 24.8 KB gzip
- `assets/PaginaPessoasVinculos-CmeTBni7.js`: 80.0 KB / 19.4 KB gzip
- `assets/index-BT1j9PDR.css`: 76.6 KB / 15.7 KB gzip
- `assets/pages-0TLfp-Ex.css`: 62.5 KB / 11.4 KB gzip
- `assets/PaginaFrequencia-CDU87LlY.js`: 52.5 KB / 16.1 KB gzip
- `assets/vendor-icons-dmcpcmyE.js`: 41.4 KB / 12.0 KB gzip
- `assets/PaginaFrequencia-BedYu8PB.css`: 38.2 KB / 7.0 KB gzip
- `assets/PaginaContratos-R1QFydq6.css`: 36.9 KB / 7.4 KB gzip
- `assets/PaginaTurnos-0M8SnunK.js`: 34.2 KB / 10.3 KB gzip
- `assets/Login-DodRE4eK.js`: 33.5 KB / 10.2 KB gzip
- `assets/PaginaRelatorioAbsenteismo-CJ-0TS6p.js`: 33.3 KB / 8.8 KB gzip
- `assets/PaginaPerfil-LfJM0VKT.js`: 31.9 KB / 9.4 KB gzip
- `assets/PaginaRelatoriosTerceirizados-iRRclTpb.js`: 31.2 KB / 9.8 KB gzip
