# Próxima etapa — Etapa 14

## Fechamentos, calendário, ocorrências, pendências e permissões excepcionais

Com a Etapa 13 corrigida para seguir exclusivamente o Java existente, a baseline está pronta para a próxima fase do planejamento.

Escopo previsto no planejamento consolidado: 29 endpoints distribuídos entre:

- `CalendarioEventoControlador`;
- `FechamentoFrequenciaControlador`;
- `FrequenciaAdicionalControlador`;
- `FrequenciaExcecaoControlador`;
- `OcorrenciaControlador`;
- `PendenciaAdministrativaControlador`;
- `PermissaoExcepcionalControlador`.

Princípio mantido para a Etapa 14: **o React deverá consumir e refletir o contrato atual do Java; não será planejada alteração do backend para adaptar o frontend.**
