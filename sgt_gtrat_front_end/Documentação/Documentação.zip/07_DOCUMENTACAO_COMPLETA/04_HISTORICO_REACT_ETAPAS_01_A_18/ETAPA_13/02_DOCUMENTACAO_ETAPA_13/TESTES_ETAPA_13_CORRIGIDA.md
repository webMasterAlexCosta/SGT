# Testes e validações — Etapa 13 corrigida

| Gate | Resultado |
|---|---:|
| Testes focais Node da Etapa 13/correção Java | 18/18 aprovados |
| Testes focais Vitest da Etapa 13 | 7/7 aprovados |
| Vitest principal | 117/117 aprovados |
| Componentes | 367/367 aprovados |
| Camada 2 — comportamento | 628/628 aprovados |
| Camada 3 — robustez/performance | 503/503 aprovados |
| Qualidade estática | 245 arquivos; 0 erros; 0 avisos |
| Nomenclatura | aprovada |
| Runtime | Node 22.16.0 / npm 10.9.2 aprovado |
| Build Vite | aprovado |
| Segredos no bundle | fail-closed aprovado |
| Integridade global React × Java | **343/343 aprovados** |

## Cobertura específica da correção

Os testes garantem que:

- `EmpregadoFrequenciaDTO` pode continuar sem `vinculoContratualId` e o React não exige mudança no Java;
- o React usa `GET /api/vinculos-contratuais` com `ativoEm` para localizar o vínculo ativo;
- a posição temporal de alocação é consultada quando é necessário desambiguar;
- não existe conversão de `empregado.id` em `vinculoContratualId`;
- linhas pendentes permanecem editáveis e resolvem a identidade ao salvar;
- o lote respeita o teto de 1.000 itens e cenários sintéticos acima de 40 mil alterações;
- a projeção operacional é paginada no servidor em 250 itens;
- falha parcial não provoca retry cego;
- turno noturno mantém a data de início;
- estados oficiais e 403 são tratados sem substituir a decisão do Java.

## Correção da antiga divergência XLSX

A única verificação que antes falhava foi identificada como **teste React desatualizado**, e não como divergência funcional. O Java atual instancia `XlsxStreamingWriter` no bloco de frequência com `freezeRows=5` e `freezeColumns=5`; o teste ainda procurava `4,4`. A asserção foi corrigida e tornou-se mais específica, verificando apenas o bloco `gerarFrequenciaXlsxNoArquivo`. Resultado focal XLSX: **7/7**. Resultado de integridade: **343/343**.

As evidências estão em `05_EVIDENCIAS_TESTES/`.
