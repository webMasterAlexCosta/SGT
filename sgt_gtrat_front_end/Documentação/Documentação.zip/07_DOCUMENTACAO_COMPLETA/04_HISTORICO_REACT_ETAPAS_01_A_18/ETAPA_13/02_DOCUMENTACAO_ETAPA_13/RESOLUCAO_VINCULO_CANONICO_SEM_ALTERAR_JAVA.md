# Resolução do vínculo canônico usando somente o Java atual

## Objetivo

Garantir que a escrita de frequência envie exatamente o `vinculoContratualId` exigido pelo Java, mesmo quando a linha da projeção operacional ainda não contém esse campo, sem alterar o backend e sem confundir `empregado.id` com vínculo contratual.

## Fluxo implementado

### 1. Reaproveitamento do identificador oficial

Se a linha já contém `vinculoContratualId` válido, nenhum lookup adicional é feito.

### 2. Busca temporal do vínculo

Para uma linha pendente, o React usa `GET /api/vinculos-contratuais` com:

- `ativoEm = dataReferencia`;
- `busca = matrícula`, quando integral e disponível;
- senão CPF integral, quando disponível;
- senão nome;
- `contratoId` quando existe exatamente um contrato selecionado;
- paginação de até 100 itens por página, percorrendo páginas apenas quando necessário.

Quando existem vários contratos selecionados, os candidatos retornados são filtrados pelos IDs desses contratos.

### 3. Correspondência exata

Os candidatos são refinados por igualdade normalizada da matrícula, CPF ou nome, conforme a chave usada.

### 4. Desambiguação temporal

Se ainda houver mais de um candidato, o React consulta a posição de alocação de cada vínculo na data por:

`GET /api/vinculos-contratuais/{id}/alocacoes/posicao?data=AAAA-MM-DD`

São comparados os IDs de lotação e jornada/turno já presentes na linha da grade.

### 5. Segurança contra identidade incorreta

- 1 candidato compatível: o `id` do vínculo é usado no payload.
- 0 candidatos: a gravação é interrompida com mensagem do contexto.
- mais de 1 candidato compatível: a gravação é interrompida por ambiguidade.
- nunca é usado `empregado.id` como `vinculoContratualId`.

## Performance

A resolução não é executada para toda a população. Ela ocorre somente para rascunhos efetivamente alterados e ainda sem vínculo conhecido. O resultado é armazenado em cache durante o ciclo da tela por data + empregado + contratos selecionados.

Isso preserva a estratégia de grande volume da Etapa 13 e evita transformar a abertura da grade em milhares de consultas adicionais.

## Autoridade

Todas as decisões temporais e de autorização permanecem no Java. O frontend apenas localiza, por endpoints oficiais, a identidade que o próprio backend exige para a escrita.
