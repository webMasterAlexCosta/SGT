# Pendências e riscos — Etapa 13

## Pendências impeditivas do React

Nenhuma identificada após a correção de identidade canônica.

## Riscos tratados

- **Identidade ambígua:** a gravação é abortada se os endpoints Java não resultarem em um único vínculo compatível.
- **Grande volume:** resolução de vínculo ocorre apenas em linhas alteradas, não na população inteira.
- **Duplicidade de escrita:** double-submit bloqueado e escrita sem retry automático.
- **Falha parcial de lote:** o progresso já concluído é preservado e a sequência não reenvia chunks anteriores cegamente.
- **Autoridade no navegador:** o React não decide fechamento/janela/autorização em substituição ao Java.

## Auditoria global

Nenhuma divergência React × Java permanece nos 343 testes de integridade. A antiga checagem XLSX foi corrigida no teste React para refletir o congelamento `5,5` já existente no Java.
