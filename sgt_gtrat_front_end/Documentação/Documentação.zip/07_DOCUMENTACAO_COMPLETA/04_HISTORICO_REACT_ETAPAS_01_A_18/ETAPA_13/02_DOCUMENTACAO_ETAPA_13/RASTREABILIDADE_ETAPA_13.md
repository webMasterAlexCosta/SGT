# Rastreabilidade — Etapa 13

| Requisito/tema | Implementação React | Estado |
|---|---|---|
| Identidade canônica na escrita | `vinculoContratualId`; resolução sob demanda pelos endpoints de vínculo existentes | Atendido |
| Vínculo/alocação válidos na data | `ativoEm=dataReferencia` e posição temporal para desambiguação | Atendido |
| Não usar `empregado.id` como vínculo | proteção explícita em serviço e testes | Atendido |
| Janela/fechamento | `prazoEdicao` informativo; autoridade no POST Java | Atendido |
| Retificação do Gestor Local | justificativa + idempotência, respeitando estados oficiais | Atendido |
| Validade/auditoria | UI consome estados oficiais do Java | Atendido |
| Lote | chunks de até 1000, sequenciais, sem retry cego | Atendido |
| Falha parcial | progresso preservado e erro interrompe sequência segura | Atendido |
| Turno noturno | `dataReferencia` = início da jornada | Atendido |
| Grande volume | paginação 250 + virtualização do recorte + rascunhos fora do DOM | Atendido |
| Pesquisa operacional | `searchTerm` enviado ao servidor | Atendido |
| Linhas pendentes | editáveis; identidade resolvida ao salvar | Atendido |
| Ambiguidade de vínculo | gravação interrompida; nenhuma escolha por inferência silenciosa | Atendido |
| Backend | nenhuma alteração | Atendido |
