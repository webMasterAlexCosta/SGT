# Alterações — Etapa 13 corrigida conforme o Java

## Diretriz definitiva

O frontend deve se adaptar ao backend existente. Esta revisão não propõe alteração de DTO, controlador, serviço, repositório ou regra de negócio Java.

## Frequência diária e grande volume

A Etapa 13 mantém e valida:

- grade operacional paginada no servidor, com página de 250 registros e pesquisa por `searchTerm`;
- virtualização apenas do recorte exibido, sem renderizar dezenas de milhares de linhas;
- rascunhos de frequência fora do DOM;
- nenhuma presença implícita para linhas pendentes;
- gravação individual por `POST /api/frequencias`;
- gravação em lote por `POST /api/frequencias/lote`;
- limite de 1.000 itens por lote, dividido em chunks sequenciais;
- sem retry automático em escrita;
- preservação de progresso quando um chunk falha;
- proteção contra double-submit;
- Gestor Local com justificativa de retificação e chave de idempotência;
- data de referência do turno noturno como data de início da jornada;
- consumo dos estados oficiais do Java: `estadoNegocial`, `validadeOperacional`, `estadoAuditoria`, `bloqueadaEdicaoOperacional` e `versaoNegocial`;
- `prazoEdicao` somente informativo; autorização final permanece no Java.

## Correção desta revisão: identidade canônica

A projeção da grade fornece `empregado.id`, mas a escrita de frequência exige `vinculoContratualId`. Em vez de pedir mudança no Java, o React passou a resolver o identificador por APIs já existentes:

- `GET /api/vinculos-contratuais?ativoEm=...&busca=...`
- `GET /api/vinculos-contratuais/{id}/alocacoes/posicao?data=...`

A busca ocorre apenas no momento de salvar uma linha alterada que ainda não tenha vínculo conhecido. O React prioriza matrícula, depois CPF integral quando disponível, e por fim nome. Quando a primeira consulta devolve mais de um vínculo, lotação e jornada na posição temporal são usadas apenas para desambiguar usando a verdade fornecida pelo próprio backend.

Se o resultado não for unívoco, a gravação é interrompida. Não existe fallback para `empregado.id` e não há inferência silenciosa.

## Arquivos principais alterados nesta correção

- `src/services/rh/ServicoVinculoContratual.js`
- `src/modules/rh/pages/PaginaFrequencia/useLogicaFrequencia.js`
- `src/modules/rh/pages/PaginaFrequencia/components/TabelaFrequencia.jsx`
- `test/frequenciaEtapa13.test.js`
- `test/frequenciaEtapa13ContratoJava.test.js`

O diff integral contra a Etapa 12 está em `DIFF_ETAPA_12_X_ETAPA_13_CORRIGIDA.patch`.
