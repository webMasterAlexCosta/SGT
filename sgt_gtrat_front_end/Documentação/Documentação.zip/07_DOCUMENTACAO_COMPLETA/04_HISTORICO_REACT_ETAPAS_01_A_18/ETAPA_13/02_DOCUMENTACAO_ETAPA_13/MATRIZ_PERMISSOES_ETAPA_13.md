# Matriz de permissões observada — Etapa 13

| Fluxo | Administrador | Gestor Nacional | Gestor Estadual | Gestor Local | Operacional |
|---|---:|---:|---:|---:|---:|
| Ler frequência | sim | sim | sim | sim | sim |
| Ler projeção da grade | sim | sim | sim | sim | sim |
| Ler vínculos/posição para resolver identidade | sim | sim | sim | sim | sim |
| Mutar frequência | não | não | não | sim | sim |
| Retificação gerencial | não | não | não | sim, conforme serviço | não |
| Edição operacional | não | não | não | conforme serviço | sim, conforme escopo/janela/estado |

A autorização efetiva é sempre a devolvida pelo Java e também depende de escopo histórico, estado da frequência, janela e demais validações do serviço.
