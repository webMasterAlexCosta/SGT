# Origem documental — Etapa 11

- Fonte recuperada: `ZIP da Etapa 11 encadeado dentro da Etapa 12`.
- Conteúdo preservado sem reescrita: `00_LEIA_PRIMEIRO`, `02_DOCUMENTACAO_ETAPA_11` e `05_EVIDENCIAS_TESTES` quando existentes.
- Arquivos recuperados desta fonte: **34**.
- A documentação histórica é preservada para rastreabilidade; em conflito, prevalecem o Java atual e a documentação final da Etapa 18.
