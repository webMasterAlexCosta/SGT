# Matriz de documentos — Etapa 11

| Documento | Finalidade |
|---|---|
| `ALTERACOES_ETAPA_11.md` | Escopo implementado e arquivos principais |
| `ANALISE_CONTRATO_JAVA_ETAPA_11.md` | Decisões derivadas dos controladores/DTOs Java |
| `ENDPOINTS_ETAPA_11.csv` | Método, rota, uso e proteção dos 25 endpoints |
| `RASTREABILIDADE_ETAPA_11.csv` | Requisito → implementação → teste |
| `MATRIZ_PERMISSOES_ETAPA_11.md` | Capacidades por perfil |
| `TESTES_ETAPA_11.md` | Resultado dos gates e limitações |
| `PENDENCIAS_RISCOS_ETAPA_11.md` | Riscos controlados e pendências fora do escopo |
| `DEPENDENCIAS_INALTERADAS_ETAPA_11.md` | Integridade do package/lock/runtime oficial |
| `PROXIMA_ETAPA_12.md` | Handoff para alocações temporais |
| `DIFF_ETAPA_10_X_ETAPA_11.patch` | Diff funcional completo sem artefatos gerados |
| `INVENTARIO_FONTE_ETAPA_11.txt` | Inventário reproduzível da fonte |
| `SHA256SUMS_FONTE_ETAPA_11.txt` | Integridade por arquivo da fonte |
| `SHA256_DOCUMENTACAO_ORIGINAL.txt` | Integridade do planejamento consolidado preservado |
| `SHA256_ENTRADAS_ORIGINAIS_ETAPA_11.txt` | Integridade dos insumos preservados no pacote |
