# Pendências e riscos — Etapa 11

## Fora do escopo desta entrega

- Alterações temporais de alocação (programar, realocar, retificar e cancelar) pertencem à etapa 12.
- Migração dos consumidores de frequência, ocorrências e relatórios da projeção `Empregado` será feita nas etapas próprias; as leituras necessárias foram preservadas.
- O Painel gerencial continua na etapa 15 do planejamento consolidado.

## Limitações de validação no ambiente

- O runtime oficial do projeto é Node `22.16.0` com npm `10.9.2`.
- A sessão de construção disponibilizou Node `24.19.0` e npm `11.9.0`; por isso `validate:runtime` deve reprovar neste ambiente por desenho.
- O `package-lock.json` original foi preservado. As dependências foram reutilizadas da instalação offline validada, sem alteração de versões.

## Pendência preexistente do pacote Java

O gate estático integrado mantém uma única falha já documentada na etapa 10: a verificação do streaming XLSX de frequência espera a construção de `XlsxStreamingWriter` com limites explícitos de colunas compartilhadas. Não houve alteração Java porque a solicitação desta etapa é de continuidade do React e a falha não pertence a Pessoas/Vínculos.

## Riscos operacionais controlados

- Conflitos de CPF e matrícula: mutação sem retry e mensagem de 409 orientando releitura.
- Capacidade concorrente: valor é sempre obtido e novamente validado pela API.
- Token de prévia obsoleto: qualquer edição do formulário descarta token e impactos exibidos.
- Exposição de dados pessoais: CPF protegido por padrão, finalidade obrigatória e descarte do payload revelado ao ocultar/fechar.
- Duplicidade Pessoa/Vínculo: cadastro integrado usa o DTO transacional canônico e permite escolher Pessoa existente.
- Repetição após falha de rede: resultado incerto é sinalizado com referência de requisição; não há retry automático.
