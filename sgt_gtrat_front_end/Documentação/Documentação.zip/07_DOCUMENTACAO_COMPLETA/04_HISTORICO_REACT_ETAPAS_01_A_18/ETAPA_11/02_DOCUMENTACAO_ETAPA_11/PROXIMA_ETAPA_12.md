# Próxima etapa — Etapa 12

## Alocações temporais do vínculo

Usar o React desta entrega como baseline e implementar o planejamento consolidado da etapa 12:

- listar faixas de alocação do vínculo, inclusive por mês;
- mostrar eventos e posição temporal da alocação;
- programar mudança de Lotação/Turno/Cargo;
- gerar prévia de impacto antes da mudança;
- confirmar com token atual, justificativa, evidência e autorização;
- retificar uma faixa existente sem reescrever o histórico;
- cancelar somente programação futura elegível;
- tratar capacidade/excedente exclusivamente conforme resposta do Java;
- refletir retroatividade nos consumidores temporais previstos pelo backend;
- manter separação entre data efetiva e data de conhecimento.

Não iniciar Painel ou etapas posteriores antes de fechar os gates da etapa 12.
