# Alterações — Etapa 11

## Escopo

Pessoas e vínculos contratuais, conforme a etapa 11 do planejamento consolidado e o contrato da API Java anexada.

## Implementado

- Nova rota canônica `/pessoas`, com redirecionamento de compatibilidade de `/empregados`.
- Nova página responsiva “Pessoas e vínculos contratuais”, dividida em duas visões paginadas no servidor.
- Busca de Pessoa por texto, contrato e data ativa.
- Busca de Vínulo por texto, contrato, estado negocial, intervalo de início e data ativa.
- CPF minimizado por padrão e consulta de dados restritos somente após finalidade explícita.
- Detalhe de Pessoa com vínculos e histórico de correções de identidade.
- Atualização de dados opcionais com indicadores explícitos de limpeza.
- Correção excepcional de Nome/CPF com motivo, evidência, autorização e impactos encontrados.
- Cadastro transacional de Vínculo para Pessoa existente ou nova Pessoa.
- Consulta de opções de alocação inicial por contrato e data antes do cadastro.
- Bloqueio visual de composição indisponível e fluxo auditável de inclusão excedente.
- Detalhe de Vínculo com estado negocial, situação temporal derivada, vigência, matrícula e motivo de término.
- Linha do tempo com data efetiva separada da data de registro e fotografias históricas do evento.
- Consulta bitemporal da posição da Pessoa (`data` e `conhecidoAte`).
- Prévia, token e aceite de impacto para retificar início e desligamento.
- Comandos de alteração de matrícula, cancelamento de programação, desligamento e cancelamento de desligamento programado.
- Tratamento de fim natural condicionado a filtro de contrato específico.
- Gestão do catálogo de Motivos de Desligamento por categoria e situação.
- Capacidades de leitura para Administrador/Gestor Nacional/Gestor Estadual/Gestor Local; escrita somente para Gestor Local.
- Tratamento específico de conflito HTTP 409 e resultado incerto, sem repetição automática de mutações.
- Integração com CSRF e confirmação de senha do núcleo HTTP já existente.
- Bloqueio das funções de salvar/excluir no `ServicoEmpregado`; consultas legadas necessárias à frequência foram preservadas.

## Arquivos principais

- `src/modules/rh/pages/PaginaPessoasVinculos/index.jsx`
- `src/modules/rh/pages/PaginaPessoasVinculos/index.module.css`
- `src/modules/rh/pages/PaginaPessoasVinculos/components/ModalCadastroVinculo.jsx`
- `src/modules/rh/pages/PaginaPessoasVinculos/components/ModalPessoa.jsx`
- `src/modules/rh/pages/PaginaPessoasVinculos/components/ModalVinculo.jsx`
- `src/modules/rh/pages/PaginaPessoasVinculos/components/ModalMotivosDesligamento.jsx`
- `src/services/rh/ServicoPessoa.js`
- `src/services/rh/ServicoVinculoContratual.js`
- `src/services/rh/ServicoMotivoDesligamento.js`
- `src/services/rh/ServicoDominioPessoaVinculo.js`
- `test/vitest/pessoasVinculosEtapa11.test.js`
- `test/pessoasVinculosEtapa11.test.js`

## Decisões preservadas

- O Java é a fonte de verdade para escopo, temporalidade, concorrência, CPF, matrícula, capacidade, excedente e transições.
- A etapa 11 cria somente a alocação inicial. Alterações temporais de alocação pertencem à etapa 12.
- “Empregado” continua existindo como projeção operacional até a migração dos consumidores posteriores, mas não como agregado de escrita.
- Nenhum segredo ou senha integra estado de formulário, DTO de domínio, armazenamento persistente ou log do módulo.
