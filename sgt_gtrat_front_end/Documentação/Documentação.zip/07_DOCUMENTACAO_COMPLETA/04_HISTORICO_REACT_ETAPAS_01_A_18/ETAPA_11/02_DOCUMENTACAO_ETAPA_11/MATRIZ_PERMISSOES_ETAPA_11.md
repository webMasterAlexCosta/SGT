# Matriz de permissões — Etapa 11

| Capacidade | Administrador | Gestor Nacional | Gestor Estadual | Gestor Local | Presidente | Operacional |
|---|---:|---:|---:|---:|---:|---:|
| Abrir Pessoas e Vínculos | Sim | Sim | Sim | Sim | Não | Não |
| Listar Pessoa/Vínculo no escopo | Sim | Sim | Sim | Sim | Não | Não |
| Consultar posição temporal | Sim | Sim | Sim | Sim | Não | Não |
| Revelar dados restritos | Conforme permissão excepcional do Java | Conforme permissão excepcional do Java | Conforme permissão excepcional do Java | Conforme permissão excepcional do Java | Fora da rota desta tela | Não |
| Criar Pessoa/Vínculo | Não | Não | Não | Sim | Não | Não |
| Atualizar opcionais/corrigir identidade | Não | Não | Não | Sim | Não | Não |
| Comandos de ciclo do Vínculo | Não | Não | Não | Sim | Não | Não |
| Gerir Motivos de Desligamento | Não | Não | Não | Sim | Não | Não |

O frontend controla a exposição da capacidade, mas a decisão final de autorização e escopo permanece no Java.
