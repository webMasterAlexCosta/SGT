# Testes — Etapa 11

## Resultado dos gates

| Gate | Resultado |
|---|---:|
| Focais Vitest Etapa 11 | 7/7 |
| Integração focal React × Java Etapa 11 | 8/8 |
| Unitários Vitest | 103/103 |
| Componentes/smoke | 365/365 |
| Camada 2 — comportamento | 624/624 |
| Camada 3 — robustez/performance | 501/501 |
| Nomenclatura | 243 arquivos aprovados |
| Qualidade estática | 0 erros de gate, 1 aviso preexistente |
| Build Vite | aprovado, 2.954 módulos transformados |
| Bundle/budget | aprovado |
| Segredos no bundle | aprovado |
| Integridade React × Java | 315/316 |
| Dependências (`npm ls --all`) | árvore resolvida; pares opcionais ausentes não são dependências do projeto |
| Runtime oficial | não executável nesta sessão: esperado Node 22.16.0, disponível Node 24.19.0 |

## Única falha integrada

`exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão`

A falha já constava na etapa 10 e verifica uma construção do `XlsxStreamingWriter` no Java de frequência. Ela não foi causada pela Etapa 11 e permanece fora do escopo autorizado para esta continuidade React.

## Aviso de qualidade

O único aviso estático é o tamanho de `PaginaFrequencia/useLogicaFrequencia.js` (1.237 linhas), também preexistente. Os novos arquivos de Pessoa/Vínculo não geraram erro nem aviso de gate.

## Cobertura focal da etapa

- 25 chamadas de endpoint canônico de Pessoa, Vínculo e Motivo verificadas em ordem, método e URL.
- Pessoa existente e nova Pessoa no cadastro integrado.
- Normalização/mascaramento de CPF e rejeição estrutural de CPF inválido.
- Inclusão excedente com todos os elementos de aceite.
- Capacidade zero/indisponibilidade sem capacidade inventada no cliente.
- Dados restritos com finalidade.
- Paginação e filtros de contrato/data.
- Prévia/token de retificação e invalidação após edição.
- Matrícula, desligamento, cancelamentos e fim natural.
- Mutações sem retry e sem senha nos DTOs/armazenamento.
- Matriz de leitura/escrita por perfil.
- Redirecionamento do legado e ausência de escrita canônica em `ServicoEmpregado`.

## Comandos principais

```bash
npm run validar:nomenclatura
npm run test
npm run test:componentes
npm run test:camada2
npm run test:camada3:vitest
npm run test:qualidade:estatica
npm run test:bundle
npm run test:segredos:bundle
SGT_BACKEND_DIR=/caminho/JAVA npm run test:integridade
npm run validate:runtime
```

Para homologação oficial, repetir os gates com Node 22.16.0/npm 10.9.2 e a API/banco configurados para um smoke funcional ponta a ponta.
