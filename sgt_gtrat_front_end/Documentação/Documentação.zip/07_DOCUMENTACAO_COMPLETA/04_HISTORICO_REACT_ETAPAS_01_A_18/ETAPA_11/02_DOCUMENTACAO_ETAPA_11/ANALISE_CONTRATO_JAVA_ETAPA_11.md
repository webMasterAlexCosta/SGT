# Análise do contrato Java — Etapa 11

## Fontes verificadas

- `PessoaControlador` e DTOs `PessoaResumoDTO`, `PessoaDTO`, `CadastroPessoaRequisicao`, `AtualizacaoPessoaOpcionalRequisicao`, `CorrecaoIdentidadePessoaRequisicao` e `CorrecaoPessoaDTO`.
- `VinculoContratualControlador` e DTOs `CadastroVinculoContratualRequisicao`, `VinculoContratualDTO`, `EventoVinculoContratualDTO`, `PreviaImpactoVinculoDTO`, `RetificacaoInicioVinculoRequisicao`, `AlteracaoMatriculaVinculoRequisicao`, `AcaoVinculoContratualRequisicao` e `DesligamentoVinculoRequisicao`.
- `MotivoDesligamentoControlador`, `MotivoDesligamentoDTO` e `CategoriaTerminoVinculo`.
- `ConfiguracaoSeguranca`, serviços de domínio e testes Java relacionados a Pessoa, Vínculo, Alocação e temporalidade.

## Conclusões aplicadas

1. Pessoa é identidade única e não deve ser recriada a cada contrato.
2. Vínculo pertence simultaneamente a Pessoa, Contrato e Gestão Local; a situação temporal não substitui o estado negocial persistido.
3. O cadastro de Pessoa/Vínculo/Alocação inicial é transacional e admite `pessoaId` existente ou objeto `pessoa` novo, nunca ambos como fonte concorrente.
4. O endpoint de opções de alocação é obrigatório para mostrar composição vigente, capacidade e necessidade de justificativa de excedente.
5. A matrícula é do Vínculo e sua obrigatoriedade depende do tipo de contratação no servidor; matrícula anterior permanece reservada no histórico.
6. O desligamento recebe o último dia do vínculo e Motivo de Desligamento catalogado.
7. Retificações de início/desligamento usam dois passos: prévia sem senha e confirmação protegida com token da prévia e `confirmarImpacto`.
8. Datas efetivas e de registro não podem ser colapsadas na UI. A consulta de posição aceita uma data de negócio e um corte opcional de conhecimento.
9. Dados restritos de Pessoa exigem `finalidade` e autorização específica do serviço. A UI não presume que leitura resumida concede revelação documental.
10. A API pode responder 409 por CPF/matrícula concorrente, token vencido ou estado alterado. O frontend não repete o comando e orienta nova leitura.

## Fronteira com a etapa 12

O controlador Java já expõe endpoints de histórico/posição/mudança de alocação. Nesta entrega apenas `GET /contratos/{contratoId}/opcoes-alocacao` é usado para a alocação inicial, porque realocação, programação, retificação e cancelamento da alocação formam a etapa 12 do planejamento.

## Java

Nenhum arquivo Java foi alterado. O pacote Java anexado foi usado como referência contratual e para os testes integrados estáticos.
