# Alterações — Etapa 06

## Objetivo executado

Realinhar estrutura organizacional e cadastros mestres ao escopo/permissões e à temporalidade do Java, deixando os catálogos prontos para as etapas de contratos, vínculos e frequência sem transferir regras autoritativas ao React.

## Alterações implementadas

### 1. Capacidades de consulta e escrita separadas

- a matriz canônica passou a distinguir visualizar de gerenciar Lotação/Turno, Estrutura Organizacional, catálogos nacionais e Tipos de Contratação;
- usuários com direito de consulta não recebem botões de criação/edição/exclusão;
- resposta 403 do backend permanece a autoridade final;
- Presidente recebe apenas as superfícies compatíveis com o contrato Java; não foi incluído artificialmente nos catálogos cujo matcher o exclui.

### 2. Estrutura Organizacional

- Superintendências e Gestões Locais são carregadas por escopo para leitura;
- Administrador continua sendo o perfil com ações de escrita da estrutura;
- visão por região foi preservada;
- falha ao carregar Gestões Locais não derruba a leitura das Superintendências;
- Gestão Local inativa permanece visível historicamente;
- Superintendência inativa não aparece como nova escolha, salvo quando já é o vínculo atual em edição.

### 3. Lotação

- leitura separada de escrita;
- estado ativo/inativo explícito;
- DELETE é apresentado semanticamente como inativação, preservando histórico;
- reativação ocorre preservando a mesma identidade via atualização suportada pelo Java;
- alteração de Gestão Local limpa Turnos dependentes;
- Gestões Locais/Turnos inativos não entram em novas seleções, mas o item histórico já vinculado é preservado;
- conflitos de programação futura são devolvidos pelo Java e apresentados sem cálculo local.

### 4. Jornada/Turno e Regras Adicionais

- Turnos podem ser consultados por perfis de leitura e alterados somente pela capacidade de Gestão Local;
- inativação/reactivação seguem o estado temporal retornado pelo Java;
- edição passa a carregar Regras Adicionais do Turno;
- CRUD de Regra Adicional usa os quatro endpoints reais do backend;
- o formulário mantém regras de estrutura/forma, sem duplicar regra negocial autoritativa do Java.

### 5. Catálogos nacionais e de escopo

- `CadastroGenerico` passou a suportar paginação, busca, estado ativo/inativo, modo somente leitura e reativação quando o contrato comporta;
- Banco, Agência, Tipo de Conta e Status do Empregado têm leitura por escopo e escrita apenas quando autorizada;
- Tipo de Contratação ganhou superfície própria, administrável por Gestor Local e consultável conforme escopo;
- Cargo ganhou superfície temporal de leitura, mas sua escrita está intencionalmente bloqueada pela contradição do Java documentada em `BUG_JAVA_CARGO_ETAPA_06.md`.

### 6. Infraestrutura temporal e selects dependentes

- criado `catalogoTemporal.js` para normalizar `{id,label,ativo,historico,metadata}`;
- opções de nova operação excluem inativos, exceto o valor já selecionado para preservar edição histórica;
- criado `useRequisicaoEncadeada` com `AbortController`, cancelamento da chamada anterior e proteção contra resposta obsoleta;
- serviços genéricos passaram a oferecer paginação e extração consistente de listas/páginas;
- carregamentos auxiliares paginados usam tamanho máximo configurado para não truncar catálogos em 20 itens.

### 7. Navegação

- sidebar ganhou agrupamento de catálogos operacionais;
- rotas de Cargo, Tipo de Contratação e Status do Empregado foram conectadas à matriz de capacidades;
- Lotações/Turnos/Estrutura passam a ser abertas pelo direito de consulta, enquanto os componentes decidem ações de escrita por capacidade específica.

## O que não foi feito

- o backend Java não foi alterado;
- a contradição de Cargo não foi contornada com permissão inventada no React;
- fotografia histórica por data efetiva não foi simulada no cliente;
- motivos de término do vínculo não foram antecipados, pois pertencem a endpoints de etapa posterior;
- a divergência XLSX de frequência não foi mascarada.
