# Matriz de permissões — Catálogos Etapa 06

| Superfície | Consulta | Escrita apresentada pelo React | Observação |
|---|---|---|---|
| Superintendências/Gestões Locais | perfis autenticados conforme endpoint/escopo | Administrador | visão por região preservada |
| Lotação | Admin, Gestor Nacional, Gestor Estadual, Gestor Local, Operacional | Gestor Local | Presidente não é incluído no matcher específico |
| Turno/Jornada + Regra Adicional | Admin, GN, GE, GL, Operacional | Gestor Local | mutações passam por confirmação central quando o Java exige |
| Cargo | Admin, GN, GE, GL, Operacional | **nenhum** | fail-closed por bug Java matcher × serviço |
| Banco/Agência/Tipo de Conta | Admin, GN, GE, GL, Operacional | Administrador | catálogos nacionais |
| Status do Empregado | Admin, GN, GE, GL, Operacional | Administrador | rota própria |
| Tipo de Contratação | global/Presidente e demais conforme escopo do serviço | Gestor Local | cadastro vinculado à Gestão Local do usuário |

A matriz é usada apenas para UX. O backend continua sendo a autoridade final e um 403 nunca é reinterpretado como permissão concedida.
