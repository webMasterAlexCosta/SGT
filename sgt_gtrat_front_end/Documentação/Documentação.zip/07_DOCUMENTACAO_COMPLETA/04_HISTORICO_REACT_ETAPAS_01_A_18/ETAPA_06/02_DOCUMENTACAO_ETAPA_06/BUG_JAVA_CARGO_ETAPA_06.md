# Bug Java formal — mutações de Cargo sem perfil executável

## Resumo

O requisito `RFE-CAT-002` define Cargo como cadastro administrado pela **Gestão Local**. Entretanto, o Java atual contém dois controles incompatíveis para as mutações de Cargo.

## Evidência 1 — Spring Security

`ConfiguracaoSeguranca.java`, linhas 588–595, agrupa `/api/cargos/**` com Banco/Agência/Tipo de Conta e exige `PERFIL_ADMINISTRADOR` para operações que não sejam GET.

## Evidência 2 — serviço

`CargoServico.java`:

- criar: linhas 69–72 chama `exigirGestorLocalAtivo`;
- atualizar: linhas 85–88 chama `exigirGestorLocalAtivo`;
- helper: linhas 148–154 rejeita quem não for Gestão Local ativa com 403 e mensagem “Somente o Gestor Local ativo administra Cargos.”

## Consequência

- Administrador atravessa o matcher HTTP, mas é rejeitado pelo serviço;
- Gestor Local satisfaz o serviço, mas é bloqueado pelo matcher HTTP;
- logo, **nenhum perfil consegue executar POST/PUT/DELETE de Cargo pelo caminho HTTP normal**.

## Decisão do React na Etapa 06

A capacidade `podeGerenciarCargos` fica fail-closed e a tela de Cargo permanece em modo somente leitura. Não foi criado workaround, chamada alternativa nem autoridade fictícia.

## Correção Java recomendada para discussão futura

Como o requisito documental e o próprio `CargoServico` concordam que Cargo é administrado pela Gestão Local, a correção mais coerente é revisar os matchers de mutação de `/api/cargos/**` para autorizar `PERFIL_GESTOR_LOCAL`, mantendo validação de escopo no serviço. Essa alteração **não foi feita** nesta etapa porque o usuário solicitou evolução do React e o Java deve permanecer inalterado salvo autorização formal.
