# Testes — Etapa 06

## Execução final

| Gate | Resultado |
|---|---:|
| Runtime | Node 22.16.0 / npm 10.9.2 — aprovado |
| Nomenclatura | aprovado |
| Configuração | **16/16** |
| Focais Etapa 06 | **8/8** |
| Unitários | **64/64** |
| Componentes | **342/342** |
| Camada 2 | **580/580** |
| Camada 3 | **467/467** |
| Qualidade estática | **223 arquivos, 0 erros de gate, 1 aviso** |
| Bundle | aprovado — 3693.8 KB JS, 1037.6 KB gzip, 499.6 KB CSS; maior chunk 1283.8 KB |
| Segredos no bundle | aprovado/fail-closed |
| Integridade React × Java | **277/278** |

## Casos específicos da Etapa 06

Os 8 testes focais cobrem:

1. Administrador × Gestor Local × leitura;
2. comportamento de Presidente nas superfícies de consulta;
3. Cargo fail-closed enquanto o backend permanecer contraditório;
4. item inativo preservado no histórico e removido de nova operação;
5. item inativo já selecionado preservado durante edição;
6. limpeza de dependências ao mudar escopo;
7. cancelamento/descartar resposta obsoleta em requisição encadeada;
8. 403 como autoridade final sem conceder escrita por inferência local.

## Integridade Java

O teste integrado válido foi executado com:

`SGT_BACKEND_DIR=/mnt/data/java_etapa06/sgt_gtrat_back_end npm run test:integridade`

Resultado: **277 aprovados / 1 falha / 278 totais**.

A falha é `exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão`, já existente antes da Etapa 06 e localizada no backend de relatório de frequência.

## Observações

- avisos `requestSubmit()` observados nas suítes agressivas são limitação conhecida do JSDOM e não causaram falhas;
- o Vite continua advertindo sobre `vendor-face` > 1000 KB, porém o gate de budget do próprio projeto aprova o bundle;
- smoke contra API Java viva não foi executado porque nesta sessão há fonte Java, mas não uma instância backend levantada; a validação de contrato foi feita contra o código Java extraído.
