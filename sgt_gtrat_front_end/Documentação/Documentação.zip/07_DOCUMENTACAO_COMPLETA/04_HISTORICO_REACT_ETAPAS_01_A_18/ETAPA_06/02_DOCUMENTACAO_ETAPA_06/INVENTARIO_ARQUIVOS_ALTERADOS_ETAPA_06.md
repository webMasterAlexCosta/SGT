# Inventário de arquivos alterados — Etapa 06

Total de caminhos diferentes entre a Etapa 05 entregue e a Etapa 06 final: **34**.

- `ALTERADO` — `src/Aplicacao.jsx`
- `ALTERADO` — `src/Leiaute/BarraLateral/index.jsx`
- `ADICIONADO` — `src/core/catalogos/catalogoTemporal.js`
- `ALTERADO` — `src/core/security/roles.js`
- `ADICIONADO` — `src/hooks/useRequisicaoEncadeada.js`
- `ALTERADO` — `src/modules/admin/components/CadastroGenerico.jsx`
- `ALTERADO` — `src/modules/admin/components/CadastroGenerico.module.css`
- `ALTERADO` — `src/modules/admin/pages/PaginaAgencias/components/CabecalhoAgencias/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaAgencias/components/TabelaAgencias/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaAgencias/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaAgencias/index.module.css`
- `ALTERADO` — `src/modules/admin/pages/PaginaEstruturaOrganizacional/components/GradeGestoresEstaduais/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaEstruturaOrganizacional/components/ModaisEstrutura/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaEstruturaOrganizacional/components/TabelaGestoesLocais/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaEstruturaOrganizacional/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaLotacoes/components/CabecalhoLotacoes/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaLotacoes/components/CartaoLotacao/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaLotacoes/components/CartaoLotacao/index.module.css`
- `ALTERADO` — `src/modules/admin/pages/PaginaLotacoes/components/ListaLotacoes/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaLotacoes/components/ModalLotacao/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaLotacoes/components/ModalLotacao/index.module.css`
- `ALTERADO` — `src/modules/admin/pages/PaginaLotacoes/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaTurnos/components/CabecalhoHero/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaTurnos/components/CartaoDeTurno/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaTurnos/components/CartaoDeTurno/index.module.css`
- `ALTERADO` — `src/modules/admin/pages/PaginaTurnos/components/ListaDeTurnos/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaTurnos/components/ModalDeTurno/index.jsx`
- `ALTERADO` — `src/modules/admin/pages/PaginaTurnos/components/ModalDeTurno/index.module.css`
- `ALTERADO` — `src/modules/admin/pages/PaginaTurnos/index.jsx`
- `ALTERADO` — `src/services/admin/ServicoJornada.js`
- `ALTERADO` — `src/services/admin/ServicoRecursoGenerico.js`
- `ALTERADO` — `src/services/rh/ServicoEmpregado.js`
- `ALTERADO` — `test/regressaoEstruturaLotacoesPainel.test.js`
- `ADICIONADO` — `test/vitest/catalogosEtapa06.test.jsx`
