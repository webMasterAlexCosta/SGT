# Rastreabilidade — Etapa 06

| Requisito | Status | Evidência/decisão |
|---|---|---|
| RFE-CAT-001 | **ATENDIDO** | Tipo de Contratação possui catálogo/rota próprios; leitura por escopo e escrita somente para Gestor Local. |
| RFE-CAT-002 | **BLOQUEADO_JAVA** | Frontend reconhece Cargo como catálogo próprio, mas mantém escrita fail-closed devido ao conflito ConfiguracaoSeguranca × CargoServico. |
| RFE-CAT-003 | **ATENDIDO** | Lotação, Turno e Cargo preservam itens inativos para leitura/edição histórica; opções novas filtram inativos. |
| RFE-CAT-004 | **PARCIAL_RASTREADO** | Adapter preserva metadata/estado e não apaga item histórico; fotografia/denominação efetiva por data depende dos endpoints temporais usados nas etapas de contrato/vínculo. |
| RFE-CAT-005 | **ATENDIDO_BACKEND_AUTORITATIVO** | Inativação de Lotação/Turno delega ao Java, que bloqueia programação futura; conflitos são apresentados sem cálculo autoritativo no React. Cargo fica sem escrita pelo bug Java. |
| RFE-CAT-006 | **PARCIAL_RASTREADO** | Reativação preserva identidade onde o Java oferece operação/PUT; Cargo fica impedido pelo conflito de autorização do backend. |
| RFE-CAT-007 | **PARCIAL_RASTREADO** | Infraestrutura distingue histórico de nova operação; uso retroativo por data efetiva será comprovado nas telas de contrato/vínculo que fornecem a data ao backend. |
| RFE-CAT-008 | **ATENDIDO** | Itens atualmente inativos são removidos de novas escolhas, salvo o valor já vinculado em edição histórica; reativação explícita é exigida para futuro. |
| RFE-CAT-009 | **DIFERIDO_ETAPA_11** | Motivos/categorias de término não fazem parte dos 53 endpoints da Etapa 06; o inventário os associa à etapa de desligamentos/vínculos. |

## Contagem

- Atendidos: 4 (`001`, `003`, `005`, `008`);
- Parciais rastreados: 3 (`004`, `006`, `007`);
- Bloqueado por bug Java: 1 (`002`);
- Diferido para etapa apropriada do domínio: 1 (`009`).

A classificação é deliberadamente conservadora: a etapa não declara como concluída uma regra temporal que só pode ser comprovada quando a UI possuir a data efetiva do fato.
