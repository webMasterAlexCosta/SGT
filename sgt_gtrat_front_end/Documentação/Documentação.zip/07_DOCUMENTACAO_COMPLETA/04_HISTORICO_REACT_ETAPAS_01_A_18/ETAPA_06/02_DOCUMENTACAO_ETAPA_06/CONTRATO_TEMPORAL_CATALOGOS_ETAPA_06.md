# Contrato temporal dos catálogos — Etapa 06

## Estado atual e histórico

O React agora carrega `ativo` junto do ID/label e preserva o item inativo quando ele representa um vínculo histórico já existente. Para nova operação, itens inativos são filtrados.

## Programação futura

O React não tenta calcular programação futura. O Java possui `ProgramacaoFuturaCatalogoServico` e o chama antes de inativar:

- Cargo: `CargoServico`, linhas 96–99 e 123–126;
- Lotação: `LotacaoServico`, linhas 129–132 e 149–151;
- Jornada/Turno: `JornadaServico`, linhas 264–266 e 289–291.

A UI envia a intenção de inativação e apresenta o conflito retornado pelo servidor.

## Reativação

Quando o endpoint aceita o mesmo registro com `ativo=true`, a UI reativa preservando ID/histórico. Superintendência utiliza o endpoint explícito `/ativar` já existente.

## Limite desta etapa

A comprovação “qual nome/opção valia em uma data efetiva passada” exige o contexto temporal do fato (contrato/vínculo/frequência). A infraestrutura desta etapa não substitui endpoints de opção por data. Esses cenários permanecem rastreados para as etapas que fornecem a data efetiva ao Java.
