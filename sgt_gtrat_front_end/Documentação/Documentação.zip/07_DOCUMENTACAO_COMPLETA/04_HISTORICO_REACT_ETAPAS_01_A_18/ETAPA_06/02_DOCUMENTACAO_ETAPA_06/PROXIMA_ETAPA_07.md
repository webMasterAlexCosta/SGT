# Próxima etapa — Etapa 07

## Nome

**Usuários, perfil e configurações administrativas**

## Objetivo

Concluir administração de identidade/aplicação sem contrato role legado e com segurança uniforme.

## Escopo previsto

- **19 endpoints**;
- `ConfiguracaoSistemaControlador` (2);
- `PerfilControlador` (8);
- `UsuarioAplicacaoControlador` (9).

## Checklist principal

- migrar gestão de usuários para perfil/autoridade canônicos;
- criar/editar/ativar/desativar/redefinir senha com confirmação central;
- integrar concessão/revogação de acesso retroativo;
- revalidar sessão/menu após mudança do próprio perfil/estado;
- concluir avatar e 2FA do perfil sem persistir dado sensível;
- integrar configurações administrativas mantidas na UI;
- preservar auditoria e senha temporária sem exposição persistente.

A Etapa 07 **não foi iniciada** no ZIP da Etapa 06.
