# Comandos de gates — Etapa 06

```bash
npm run validate:runtime
npm run validar:nomenclatura
npm run test:configuracao
npx vitest run --config vitest.config.js test/vitest/catalogosEtapa06.test.jsx --coverage.enabled=false
npm run test
npm run test:componentes
npm run test:camada2
npm run test:camada3:vitest
npm run test:qualidade:estatica
npm run test:bundle
npm run test:segredos:bundle
SGT_BACKEND_DIR=/caminho/para/java npm run test:integridade
```

O teste focal usa coverage desabilitado porque o threshold global só é significativo na suíte unitária completa; os 8 casos focais passam e a cobertura global é medida por `npm run test`.
