# Dependências — Etapa 06

Nenhuma dependência npm foi adicionada/removida.

- `package.json`: baseline `554a4c4dabb1030a70d9c1391cd9a890d79a3459927a94762be5d73a08058bec` / etapa06 `554a4c4dabb1030a70d9c1391cd9a890d79a3459927a94762be5d73a08058bec` / iguais: **True**
- `package-lock.json`: baseline `356cbe7921f287648acbcff5a5802b5e640f662a13dd3d33d90b811e10a11123` / etapa06 `356cbe7921f287648acbcff5a5802b5e640f662a13dd3d33d90b811e10a11123` / iguais: **True**
