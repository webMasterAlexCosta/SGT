# Pendências e riscos — Etapa 06

## P1 — Bug Java em Cargo

Mutações de Cargo não têm perfil executável devido à contradição entre `ConfiguracaoSeguranca` e `CargoServico`. React permanece somente leitura. Ver `BUG_JAVA_CARGO_ETAPA_06.md`.

## P1 — Divergência XLSX preexistente

O gate integrado continua 277/278 por uma expectativa de `XlsxStreamingWriter` no Java. Não pertence à Etapa 06 e não foi mascarada.

## P2 — Fotografia histórica por data efetiva

O adapter temporal preserva estado/metadata e itens inativos históricos, mas a seleção efetiva por data deve usar endpoints temporais dos domínios de contrato/vínculo. Requisitos `RFE-CAT-004` e `RFE-CAT-007` continuam parciais até essas etapas.

## P2 — Causas de término

`RFE-CAT-009` depende do domínio de desligamentos/vínculos e não faz parte dos 53 endpoints da Etapa 06. Não foi antecipado.

## P3 — Chunk vendor-face

Vite alerta para chunk de aproximadamente 1,31 MB. O budget oficial do projeto passou; manter monitoramento nas próximas etapas e evitar importar bibliotecas pesadas no shell inicial.

## Ambiente

Smoke com backend real não foi executado porque não há servidor Java ativo nesta sessão. Isso foi registrado como não executado, não como sucesso.
