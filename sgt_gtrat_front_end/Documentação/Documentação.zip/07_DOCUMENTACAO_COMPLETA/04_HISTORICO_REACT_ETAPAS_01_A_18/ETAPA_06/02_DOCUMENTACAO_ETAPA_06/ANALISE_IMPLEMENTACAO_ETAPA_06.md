# Análise de implementação — Etapa 06

## Escopo conferido

A documentação original associa **53 endpoints** diretamente à Etapa 06, distribuídos assim:

- `AgenciaControlador`: **5 endpoint(s)**
- `BancoControlador`: **5 endpoint(s)**
- `CargoControlador`: **5 endpoint(s)**
- `GestaoLocalControlador`: **4 endpoint(s)**
- `JornadaControlador`: **5 endpoint(s)**
- `LotacaoControlador`: **6 endpoint(s)**
- `RegraAdicionalControlador`: **4 endpoint(s)**
- `StatusEmpregadoControlador`: **5 endpoint(s)**
- `SuperintendenciaControlador`: **5 endpoint(s)**
- `TipoContaControlador`: **5 endpoint(s)**
- `TipoContratacaoControlador`: **4 endpoint(s)**

O CSV `ENDPOINTS_ETAPA_06.csv` preserva método, path, controlador, DTO, CSRF, confirmação de senha e segurança do inventário original e adiciona o resultado desta implementação.

## Decisão arquitetural

A Etapa 06 segue quatro regras:

1. **consulta != escrita**: possuir direito de visualizar um catálogo não concede botões de mutação;
2. **histórico != nova operação**: item inativo pode continuar legível/historicamente selecionado, mas não entra em nova seleção futura;
3. **frontend não arbitra regra temporal**: programação futura, validade efetiva e conflitos pertencem ao Java;
4. **fail-closed em contrato contraditório**: quando o backend não oferece um perfil capaz de concluir a mutação, a UI não tenta adivinhar uma permissão.

## Resultado

- 50 dos 53 endpoints da etapa ficaram integrados/validados sem bloqueio contratual;
- os 3 endpoints de mutação de Cargo (`POST`, `PUT`, `DELETE`) permanecem bloqueados na UI por contradição interna do Java;
- o gate React × Java permanece **277/278**, sem nova regressão da Etapa 06;
- a única falha do gate integrado continua sendo XLSX de frequência, fora deste domínio.

## Gate de saída

A infraestrutura de catálogos/escopo está pronta para ser consumida nas etapas de contratos, vínculos e frequência, com a ressalva formal do Cargo e das comprovações temporais que exigem uma data efetiva de negócio.
