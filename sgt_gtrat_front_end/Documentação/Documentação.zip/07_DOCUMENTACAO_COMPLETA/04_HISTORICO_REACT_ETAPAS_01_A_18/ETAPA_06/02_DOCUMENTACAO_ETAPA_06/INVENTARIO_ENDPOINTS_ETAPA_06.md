# Inventário de endpoints — Etapa 06

Total: **53**.

- `AgenciaControlador`: **5 endpoint(s)**
- `BancoControlador`: **5 endpoint(s)**
- `CargoControlador`: **5 endpoint(s)**
- `GestaoLocalControlador`: **4 endpoint(s)**
- `JornadaControlador`: **5 endpoint(s)**
- `LotacaoControlador`: **6 endpoint(s)**
- `RegraAdicionalControlador`: **4 endpoint(s)**
- `StatusEmpregadoControlador`: **5 endpoint(s)**
- `SuperintendenciaControlador`: **5 endpoint(s)**
- `TipoContaControlador`: **5 endpoint(s)**
- `TipoContratacaoControlador`: **4 endpoint(s)**

Detalhamento completo: `ENDPOINTS_ETAPA_06.csv`. As três mutações de Cargo estão marcadas `BLOQUEADO_JAVA`; os demais 50 endpoints estão `INTEGRADO_VALIDADO` ou `INTEGRADO_LEITURA`.
