# SGT/GTRAT React — Entrega Etapa 06

Esta entrega contém o frontend após a **Etapa 06 — Estrutura organizacional e catálogos**.

## Estrutura

- `01_REACT_ETAPA_06/` — fonte final da etapa, sem `node_modules`, `dist`, `reports` ou `.git`;
- `02_DOCUMENTACAO_ETAPA_06/` — alterações, testes, decisões de endpoint, rastreabilidade, patch e pendências;
- `03_DOCUMENTACAO_ORIGINAL/` — documentação original das 18 etapas preservada byte a byte a partir da Etapa 05;
- `04_REACT_ETAPA_05_REFERENCIA/` — baseline anteriormente entregue, para auditoria antes × depois;
- `05_EVIDENCIAS_TESTES/` — logs/exit codes, JUnit, relatórios de qualidade/bundle e integridade Java;
- `06_ENTRADAS_ORIGINAIS/` — React antigo e planejamento original preservados desde a baseline.

## Situação

**Gate técnico da Etapa 06 aprovado com uma divergência React × Java preexistente e um bug Java novo formalmente identificado no domínio Cargo.**

Todos os gates determinísticos da Etapa 06 passaram. A integridade React × Java ficou em **277/278**; a única falha executada é a mesma exportação XLSX de frequência do backend já registrada nas Etapas 04–05 e não pertence aos catálogos.

Para **Cargo**, o Java atual contém uma contradição de autorização: o matcher HTTP exige Administrador nas mutações `/api/cargos/**`, enquanto `CargoServico` exige Gestor Local ativo. Como nenhum perfil satisfaz simultaneamente os dois contratos, o React mantém Cargo em **somente leitura/fail-closed**. O Java não foi alterado sem autorização.

A Etapa 07 não foi iniciada neste pacote.
