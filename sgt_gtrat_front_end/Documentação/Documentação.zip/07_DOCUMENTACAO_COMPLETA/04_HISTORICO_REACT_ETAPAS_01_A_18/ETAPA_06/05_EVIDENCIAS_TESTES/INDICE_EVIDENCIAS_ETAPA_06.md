# Índice de evidências — Etapa 06

Os arquivos `*.log` e `*.exit` foram gerados em uma execução final do mesmo estado-fonte entregue no ZIP.

- `validate_runtime.*`
- `validar_nomenclatura.*`
- `test_configuracao.*`
- `test_focal_etapa06.*`
- `test_unitarios.*`
- `test_componentes.*`
- `test_camada2.*`
- `test_camada3.*`
- `qualidade_estatica.*`
- `bundle.*`
- `segredos_bundle.*`
- `integridade_java.*` — exit 1 esperado/documentado por uma única divergência XLSX preexistente
- relatórios JUnit, qualidade, bundle e resultados React copiados de `reports/`.
