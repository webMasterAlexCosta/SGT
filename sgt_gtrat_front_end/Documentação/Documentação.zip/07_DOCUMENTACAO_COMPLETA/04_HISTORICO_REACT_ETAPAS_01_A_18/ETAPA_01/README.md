# SGT/GTRAT — Documentação React Etapa 01 V2 Detalhada

Esta versão substitui a V1 como baseline para evolução do React antigo contra o Java pós-auditoria.

## Conteúdo

1. `00_GOVERNANCA_DOCUMENTAL` — método, escopo e regras de manutenção.
2. `01_REQUISITOS_IMPLEMENTACAO` — requisitos transversais detalhados + 198 obrigações derivadas do domínio Java.
3. `02_CONTRATO_INTEGRACAO` — HTTP, CSRF, 2FA, perfis, status e temporalidade.
4. `03_INVENTARIO_API` — 282 endpoints, 183 DTOs detectados e 44 matchers de segurança em MD/CSV.
5. `04_INVENTARIO_REACT_ATUAL` — rotas, dependências, evidências de legado e referências atuais a endpoints.
6. `05_MATRIZ_GAPS` — P0/P1/P2 do frontend.
7. `06_RASTREABILIDADE` — 198 requisitos canônicos Java → responsabilidade React.
8. `07_PLANO_IMPLEMENTACAO` — 18 etapas com gates menores.
9. `08_TESTES_E_GATES` — estratégia de validação e não-regressão.
10. `09_CONFIGURACAO_FRONTEND` — classificação das variáveis Vite/.env.
11. `99_REFERENCIA_V1` — cópia da documentação anterior para histórico.

## Decisão de congelamento do backend

O Java não deve ser alterado durante a implementação normal do React. Quando uma integração falhar, primeiro validar DTO, método/URL, CSRF, senha, perfil, escopo, data efetiva, idempotência e estado negocial. Alteração Java só entra após bug reproduzível e documentado.

## Observação sobre inventário

“282 endpoints” é inventário técnico, não obrigação de criar 282 telas. Cada endpoint recebe uma decisão de integração na etapa correspondente; rotas `denyAll`, diagnósticas ou projeções legadas podem ser deliberadamente não consumidas.

## Arquivos operacionais de acompanhamento

- `01_REQUISITOS_IMPLEMENTACAO/SGT_GTRAT_REACT_REQUISITOS_IMPLEMENTACAO_V2_CHECKLIST.csv`: 403 requisitos com status e etapa planejada.
- `03_INVENTARIO_API/SGT_GTRAT_API_ENDPOINTS_DECISAO_FRONTEND_V2.csv`: decisão de consumo e etapa para cada endpoint.
- `00_GOVERNANCA_DOCUMENTAL/MANIFESTO_SHA256_V2.txt`: hashes dos arquivos documentais para conferência de integridade.
