# Inventário do React Antigo — Baseline

**Data:** 11/09/2026

## Stack observada

- React 19.2.x
- React Router 7.18.x
- Vite 8.2.x
- Axios 1.19.x
- Recharts 3.10.x
- jsPDF / AutoTable
- Vitest
- Node alvo >=22 <25
- CSS Modules; não há dependência Tailwind CSS.

## Estrutura observada

- 22 rotas declaradas (incluindo wildcard).
- 30 arquivos de serviço/integração detectados.
- 113 arquivos `.module.css`.
- 69 arquivos sob estrutura de testes na baseline analisada.

## Dívida de contrato prioritária

- `role/roles` legado;
- `ROLE_*` legado;
- `skipTwoFactor`;
- ausência de CSRF central;
- CRUD negocial via `/empregados`;
- contratos insuficientes para o backend escalonado;
- normalização HTTP descarta metadados úteis;
- algumas regras configuráveis no browser precisam deixar de ser autoritativas.

## Base reaproveitável

- padrão visual Correios;
- CSS Modules;
- componentes e layout;
- Axios `withCredentials`;
- mecanismo inicial de confirmação de senha;
- serviços de frequência/relatórios/painel/governança como ponto de partida;
- suíte Vitest e scripts de qualidade.
