# SGT/GTRAT — Plano de Implementação do React em 13 Etapas

**Versão:** 1.0  
**Data:** 11/09/2026  
**Total recomendado:** **13 etapas**, contando esta Etapa 01 de levantamento.  
**Etapas de código restantes após esta entrega:** **12**.  

## Estratégia

O fracionamento abaixo reduz risco de regressão e respeita a dependência real entre segurança, domínio temporal e telas. O Java será mantido congelado funcionalmente, salvo bug comprovado.

| Etapa | Escopo | Código React? | Gate de saída |
|---:|---|:---:|---|
| **01** | Levantamento, contrato Java↔React, gaps, inventário e plano | Não | Baseline documental aprovada |
| **02** | Core HTTP: envelope, CSRF, erros, requestId, paginação, senha, idempotência | Sim | Testes unitários do cliente HTTP + mutações seguras |
| **03** | Autenticação, sessão, 2FA, senha inicial, `perfil/autoridade`, guards | Sim | Login completo para 6 perfis sem contrato legado |
| **04** | Shell, menu, rotas, design system Correios, CSS Modules, responsividade/a11y base | Sim | Navegação coerente por perfil e padrão visual consolidado |
| **05** | Perfil, usuários, escopos e catálogos administrativos/organizacionais | Sim | CRUDs/consultas autorizados integrados e testados |
| **06** | Contratos — núcleo e ciclo de vida temporal/administrativo | Sim | criação/publicação/versões/eventos/ações de ciclo funcionando |
| **07** | Contratos avançados — composições, aditamentos, remanejamentos, documentos, transferências, correções | Sim | prévias, documentos, excedentes e exceções testados |
| **08** | Pessoas, vínculos, alocações, identidade, desligamento e histórico temporal | Sim | substituição do CRUD negocial de Empregado concluída |
| **09** | Frequência, fechamentos, exceções/adicionais, calendário e ocorrências | Sim | fluxo operacional e gerencial temporal validado |
| **10** | Pendências, permissões excepcionais, auditoria e governança de terceiros | Sim | estados administrativos e trilhas de auditoria cobertos |
| **11** | Painel/indicadores — filtros, “Todos”, datas, gráficos, perfis e performance | Sim | indicadores consistentes nos escopos e sem refresh forçado |
| **12** | Relatórios, emissões administrativas, comparação histórica e exportações PDF/XLSX | Sim | consultas/exports conferíveis e grandes volumes assíncronos |
| **13** | Regressão integral, E2E, performance, acessibilidade, build, empacotamento e Gate pré-homologação | Sim | relatório final de aderência + ZIP candidato à homologação |

## Etapa 01 — Levantamento e baseline (ATUAL)

### Entregáveis
- levantamento completo de requisitos frontend;
- contrato de integração Java↔React;
- matriz de gaps do frontend antigo;
- plano em 13 etapas;
- inventário dos endpoints Java.

### Proibição
Nenhuma alteração de código nesta etapa.

## Etapa 02 — Core HTTP e segurança transversal

### Implementar
- normalizador de `RespostaApi` sem perder meta/requestId;
- CSRF lazy/bootstrap + revalidação;
- tratamento central 202/400/401/403/404/409/413/415/428/5xx;
- confirmação de senha central;
- idempotência por intenção;
- request cancellation/stale response;
- paginação comum;
- download/multipart robustos.

### Gate
Todas as mutações de serviço passam pela infraestrutura comum e testes demonstram CSRF/senha/idempotência.

## Etapa 03 — Autenticação, sessão, 2FA e autorização

### Implementar
- remover `skipTwoFactor`;
- máquina de login 202/TOTP;
- seis perfis e authorities;
- sessão/restauração/renovação/logout;
- troca de senha inicial;
- guards/menu capabilities;
- eliminar dependência negocial de `ROLE_*`.

### Gate
Matriz de seis perfis validada contra endpoints principais, sem regressão do login.

## Etapa 04 — Shell e design system Correios

### Implementar
- tokens globais + CSS Modules;
- header/sidebar/menu/breadcrumbs;
- componentes de formulário, tabela, paginação, modal, confirmação, status, empty/error state;
- responsividade e acessibilidade base;
- eliminar utilidades globais desnecessárias sem reescrita visual brusca.

### Gate
Aplicação navegável, consistente e pronta para receber módulos sem duplicar padrões.

## Etapa 05 — Perfil, usuários e cadastros de apoio

- Perfil/2FA/avatar/senha.
- Gestão de usuários com `perfil`.
- Acesso retroativo.
- Lotação, Jornada/Turno, Cargo, Banco, Agência, Tipo de Conta e outros catálogos necessários.
- Estrutura organizacional e escopos.

### Gate
Administração básica alinhada às authorities e sem roles legadas.

## Etapa 06 — Contrato núcleo

- lista/opções/detalhe;
- rascunho e publicação;
- edição autorizada;
- eventos/precedências/versões/posição temporal;
- inativar/reativar;
- encerrar antecipadamente;
- cancelar futuro;
- anular/corrigir anulação;
- transferência de gestão + histórico;
- delete apenas quando permitido.

### Gate
Ciclo de vida completo do contrato validado com confirmação de senha e conflitos.

## Etapa 07 — Contrato avançado

- composições e monitor de excedentes;
- prévias/opções de capacidade;
- aditamentos;
- remanejamentos;
- documentos comprobatórios + versões + downloads + acessos;
- correção de identificador;
- permissões relacionadas e idempotência.

### Gate
Cenários de excesso, redução abaixo de ocupação, documento restrito e correções históricas aprovados.

## Etapa 08 — Pessoa/Vínculo/Alocação

- Pessoa paginada + detalhe;
- dados opcionais/restritos e correções de identidade;
- criação integrada de vínculo;
- opções de alocação;
- eventos e posição temporal;
- prévias/retificações;
- alocação e retificação temporal;
- precedência no último dia;
- alteração de matrícula;
- desligamento/retificação/cancelamento/fim natural;
- retirar Empregado como fonte negocial paralela.

### Gate
Todos os fluxos principais funcionam por IDs canônicos Pessoa/Vínculo/Alocação.

## Etapa 09 — Frequência e operação diária

- diária/mensal/intervalo/eventos;
- individual e lote por vínculo;
- prazo/bloqueio/revisão/retificação;
- fechamentos e reprocessamento;
- exceções/adicionais;
- calendário/folgas/feriados;
- ocorrências e anexos.

### Gate
Operacional e Gestor Local validados em datas-limite e cenários históricos/noturnos.

## Etapa 10 — Pendências, exceções, auditoria e governança

- pendências + tratamento/resolução;
- permissões excepcionais + revogação/usos;
- logs/auditoria Admin;
- governança de terceiros completa com security stack atual.

### Gate
Fluxos excepcionais não escapam dos controles de perfil, finalidade, senha e auditoria.

## Etapa 11 — Painel

- filtros canônicos;
- recortes por contrato/lotação/jornada/cargo;
- “Todos” + detalhamentos;
- navegação de data;
- métricas previsto/presente/ausente/pendente;
- linhas/barras/dispersão/infográfico onde aplicável;
- ajustes de performance/estado sem refresh;
- seis perfis.

### Gate
Conferência cruzada com respostas da API e regressões históricas dos indicadores eliminadas.

## Etapa 12 — Relatórios e exportações

- frequência consolidada;
- absenteísmo;
- terceirizados;
- horas trabalhadas;
- paginação;
- exportação assíncrona/síncrona conforme volume;
- relatório administrativo: prévia/emissão/conhecimento/comparação;
- PDF/XLSX e feedback de geração.

### Gate
Totais/tabelas/exportações do mesmo recorte conferem entre si e respeitam perfis.

## Etapa 13 — Gate final React

### Executar
- suíte completa unitária/integrada/E2E;
- regressões históricas;
- acessibilidade;
- performance e grande volume;
- build Node 22;
- auditoria de contrato obsoleto;
- verificação de endpoints sem decisão;
- segurança client-side;
- empacotamento e smoke com Java atual;
- relatório final de aderência frontend↔backend.

### Resultado
Candidato a homologação. O Gate B de produção do backend continua sendo tratado separadamente do Gate funcional do React.

## Padrão de entrega sugerido para as próximas etapas

Em cada etapa de código:

1. ZIP do React completo da etapa;
2. `MD` do que foi alterado;
3. `MD` de testes executados e resultado;
4. `MD` de pendências/riscos encontrados;
5. atualização da matriz de aderência;
6. somente então avançar à etapa seguinte.

Esse formato reduz o risco de regressões e facilita restauração de uma etapa estável.
