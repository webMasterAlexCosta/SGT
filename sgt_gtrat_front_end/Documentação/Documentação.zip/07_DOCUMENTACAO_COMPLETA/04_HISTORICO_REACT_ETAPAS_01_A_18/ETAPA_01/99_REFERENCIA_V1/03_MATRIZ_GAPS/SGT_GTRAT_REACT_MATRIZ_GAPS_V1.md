# SGT/GTRAT — Matriz de Gaps do React Antigo frente ao Java Atual

**Versão:** 1.0  
**Data:** 11/09/2026  

## 1. Diagnóstico executivo

O React antigo **não deve ser descartado**. Ele tem uma base visual Correios consistente, CSS Modules, Axios centralizado, rotas funcionais, módulos de painel/frequência/relatórios/governança e testes. Entretanto, o backend foi escalonado e o contrato de segurança/domínio mudou significativamente.

A estratégia recomendada é **evolução controlada**, com substituição dos pontos de contrato obsoletos antes de expandir telas.

## 2. Classificação dos principais componentes

| Área | Situação | Decisão |
|---|---|---|
| Identidade visual Correios | Boa base | **PRESERVAR / organizar tokens** |
| CSS Modules | Já amplamente utilizado | **PRESERVAR** |
| `index.css` com utilidades globais tipo Tailwind | Não é Tailwind, mas cria padrão utility global | **REDUZIR gradualmente** |
| React 19 + Vite | Compatível com alvo | **PRESERVAR** |
| Axios `withCredentials` | Compatível com cookies | **PRESERVAR + ADAPTAR** |
| Interceptor de resposta | Faz unwrap, mas pode descartar `meta/requestId` | **ADAPTAR** |
| CSRF | Ausente no fluxo central | **IMPLEMENTAR antes das mutações** |
| Confirmação `X-User-Password` | Base existente | **PRESERVAR + CENTRALIZAR** |
| Login | Envia `skipTwoFactor` legado | **ADAPTAR imediatamente** |
| Contexto de autenticação | Normaliza `roles/role` antigos | **SUBSTITUIR contrato** |
| `core/security/roles.js` | `ROLE_ADMIN`, `ROLE_USER`, `ROLE_SUPERINTENDENCIA` etc. | **SUBSTITUIR por perfil/autoridade canônicos** |
| Gestão de usuários | Usa `role` | **MIGRAR para `perfil`** |
| Empregados | CRUD canônico por `/empregados` | **REMODELAR para Pessoa/Vínculo/Alocação** |
| Contratos | CRUD genérico | **EXPANDIR profundamente** |
| Frequência | Vários endpoints já próximos do atual | **ADAPTAR domínio e segurança** |
| Painel | Estrutura já existe | **ADAPTAR guards/filtros/estado** |
| Relatórios | Boa base e exportações | **ADAPTAR ao contrato atual/assíncrono** |
| Governança terceiros | Endpoints em grande parte alinhados | **PRESERVAR + segurança/authorities** |
| Testes | Cobertura significativa | **PRESERVAR + atualizar contrato** |

## 3. Rotas existentes e destino

| Rota atual | Avaliação | Evolução requerida |
|---|---|---|
| `/` | login/home | atualizar login/2FA/sessão |
| `/perfil` | aproveitável | 2FA, senha, avatar pelo contrato atual |
| `/painel` | aproveitável | seis perfis, filtros canônicos, indicadores e data |
| `/frequencia` | aproveitável | vínculo canônico, revisão/fechamento/escopo |
| `/ocorrencias` | aproveitável | segurança, anexos, escopo |
| `/contratos` | insuficiente | ciclo de vida, temporalidade, composições e submódulos |
| `/governanca-terceiros` | boa base | CSRF/senha/guards |
| `/empregados` | conceitualmente legado | transformar em Pessoas/Vínculos/Alocações ou renomear rota |
| `/relatorios` | aproveitável | filtros/exports atuais |
| `/relatorio-mensal` | aproveitável | contrato de frequência atual |
| `/relatorio-absenteismo` | aproveitável | paginação/resumo/export atual |
| `/gestao-usuarios` | aproveitável | `perfil/autoridade` e escopo |
| `/calendario-folgas` | aproveitável | revisar permissão por perfil/escopo |
| `/lotacoes` | aproveitável | vigência/escopo atual |
| `/turnos` | nomenclatura visual aceitável | integração canônica com Jornada |
| `/estrutura-organizacional` | aproveitável | manter organização por região/escopo |
| `/logs` | aproveitável | Admin only, dados minimizados |
| `/cargos` | aproveitável | estado/vigência/permissão atual |
| `/bancos` | aproveitável | autorização de escrita Admin |
| `/agencias` | aproveitável | autorização de escrita Admin |
| `/tipos-conta` | aproveitável | autorização de escrita Admin |

## 4. Funcionalidades relevantes ausentes ou insuficientes no React antigo

### 4.1 Segurança/infraestrutura

- bootstrap de CSRF e injeção em todas as mutações;
- preservação de `meta`/`requestId` no envelope;
- state machine central de confirmação de senha;
- errors de domínio 202/403/409/428;
- idempotência central por intenção;
- guards dos seis perfis;
- restauração de sessão baseada no contrato atual.

### 4.2 Contratos

- eventos, precedências, versões e posição temporal;
- publicar/inativar/reativar/encerrar antecipadamente/cancelar futuro/anular/corrigir anulação;
- transferência de gestão e histórico;
- composições + excedentes;
- aditamentos + prévias + retificação/cancelamento;
- remanejamentos + prévias + retificação/cancelamento;
- documentos comprobatórios e versionamento;
- permissões/acessos de documento;
- correção de identificador contrato + histórico.

### 4.3 Pessoas/Vínculos/Alocações

- listagem paginada de Pessoa;
- dados restritos com finalidade;
- correções de identidade;
- vínculo integrado pessoa-contrato;
- opções de alocação/capacidade/excedente;
- histórico/eventos do vínculo;
- prévias e retificações temporais;
- alocação temporal, posição e eventos;
- precedência no último dia;
- desligamentos e suas retificações.

### 4.4 Frequência/Operação

- consolidar uso de `vinculoContratualId`;
- exibir estados de auditoria/revisão/validade/bloqueio;
- fluxos de fechamento/reprocessamento de forma completa;
- eliminar regra autoritativa de janela configurada apenas no frontend.

### 4.5 Administração e auditoria

- permissões excepcionais + usos;
- pendências administrativas;
- dados restritos por finalidade;
- adequação total `perfil/autoridade`.

### 4.6 Relatórios

- emissão administrativa histórica;
- conhecimento temporal;
- comparação com vigente;
- exportação assíncrona padronizada em todos os grandes relatórios.

## 5. Evidências de contrato legado no React

A varredura encontrou referências recorrentes a:

- `role` / `roles`;
- `ROLE_ADMIN`, `ROLE_USER`, `ROLE_SUPERINTENDENCIA`, `ROLE_GESTOR_LOCAL`;
- `skipTwoFactor`;
- `/empregados` como origem de CRUD negocial.

Essas ocorrências devem ser removidas do **contrato funcional**, mas não por busca-e-substituição cega. Cada uso deve ser classificado entre autenticação, exibição, teste ou compatibilidade remanescente.

## 6. Risco de alterar Java sem necessidade

Os pontos acima são predominantemente **gaps do React antigo**, não bugs do backend. O backend passou pelo Gate A pré-React e a documentação descreve explicitamente mudanças backward-incompatible em perfis, 2FA, CSRF e cadastro canônico de pessoas/vínculos.

Portanto, a primeira reação a um 403/400/409 durante a migração deve ser validar contrato/payload/escopo do React. Só após reprodução contra o contrato atual deve-se abrir bug Java.

## 7. Ordem de migração obrigatória

1. HTTP/CSRF/envelope/error handling.
2. autenticação/2FA/sessão/perfis/guards.
3. shell visual/navegação.
4. módulos negociais.

Implementar telas novas antes dos itens 1–2 multiplicaria dívida técnica e retrabalho.
