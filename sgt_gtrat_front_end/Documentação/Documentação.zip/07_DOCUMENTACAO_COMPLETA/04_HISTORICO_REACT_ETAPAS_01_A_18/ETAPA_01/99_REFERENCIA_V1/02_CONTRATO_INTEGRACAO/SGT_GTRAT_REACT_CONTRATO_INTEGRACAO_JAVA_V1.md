# SGT/GTRAT — Contrato de Integração Java ↔ React

**Versão:** 1.0  
**Data:** 11/09/2026  
**Objetivo:** traduzir o contrato pós-auditoria do backend em regras de implementação do cliente React.  

## 1. Regra de precedência

1. DTO/controlador/segurança executável do Java atual.
2. Documentação pós-auditoria (`CONTRATO_API_REACT_POS_AUDITORIA.md` e Etapa 13).
3. Requisitos canônicos V8 e documentos das Etapas 07–10.
4. React antigo apenas como referência visual e de fluxo legado.

Em caso de divergência, não adaptar o Java ao frontend antigo sem demonstrar bug.

## 2. Sessão e cookies

- Axios deve operar com `withCredentials: true`.
- O React não recebe/gerencia Bearer JWT de sessão.
- Restauração da sessão: `GET /api/autenticacao/sessao`.
- Renovação: `POST /api/autenticacao/renovar-sessao`.
- Encerramento: `POST /api/autenticacao/encerrar-sessao`.
- Tratar estados/códigos de sessão como parte do fluxo e não apenas pelo status HTTP.

## 3. CSRF obrigatório

Fluxo obrigatório antes de POST/PUT/PATCH/DELETE:

1. obter `GET /api/autenticacao/csrf`;
2. conservar `token` em memória e ler `headerName` da resposta;
3. enviar o token no header indicado (normalmente `X-XSRF-TOKEN`);
4. reobter token quando a sessão/contexto mudar ou a API indicar necessidade.

Não confundir CSRF com cookie de autenticação.

## 4. Login e 2FA

Payload canônico:

```text
matricula
password
totp (quando requerido)
```

O React **não envia `skipTwoFactor`**.  
Se o backend responder HTTP 202 com `requiresTwoFactor=true`, o fluxo permanece no login e solicita TOTP. `canSkipTwoFactor=false` deve ser respeitado.

## 5. Perfis e authorities

| Perfil (`perfil`) | Authority (`autoridade`) | Diretriz principal de frontend |
|---|---|---|
| ADMINISTRADOR | PERFIL_ADMINISTRADOR | Administração técnica e exceções autorizadas; não presumir domínio negocial geral |
| GESTOR_NACIONAL | PERFIL_GESTOR_NACIONAL | Leitura/auditoria nacional; painéis/relatórios autorizados |
| GESTOR_ESTADUAL | PERFIL_GESTOR_ESTADUAL | Leitura/auditoria estadual |
| GESTOR_LOCAL | PERFIL_GESTOR_LOCAL | Principal executor de comandos negociais no escopo local |
| PRESIDENTE | PERFIL_PRESIDENTE | Leitura nacional; sem mutações/emissões formais proibidas |
| OPERACIONAL | PERFIL_OPERACIONAL | Frequência e consultas estritamente autorizadas |

Não usar `ROLE_*`, `role`, `roles` como contrato novo.

## 6. Envelope de resposta

O backend padroniza respostas JSON com campos como:

- `timestamp`;
- `status`;
- `error`;
- `message`;
- `requestId`;
- `meta`;
- `data`;
- `path`.

O cliente deverá disponibilizar `data` para a camada funcional sem perder `meta`/`requestId` necessários a paginação, diagnóstico e UX. Respostas binárias/stream não devem passar por unwrap JSON.

## 7. Confirmação de senha

Diversos comandos estão protegidos por confirmação de senha (`@ExigirSenha`). O mecanismo cliente já parcialmente existente deve ser padronizado via header:

`X-User-Password`

Regras:

- nunca persistir a senha;
- acionar confirmação de maneira centralizada;
- interpretar 428 / `PASSWORD_CONFIRMATION_REQUIRED` como solicitação de confirmação;
- após confirmação, repetir apenas a intenção original, com proteção contra double-submit;
- para comando idempotente, manter a mesma chave enquanto a intenção não mudou.

## 8. Idempotência e concorrência

- 409 não é “erro genérico”: pode representar conflito temporal, ocupação, versão ou uso incorreto de chave.
- Chave idempotente deve ser estável para a mesma intenção.
- Alterar campos significativos cria nova intenção e exige nova chave.
- Prévia exibida no browser nunca substitui validação final sob lock no backend.
- Após 409, oferecer atualizar/recarcular prévia/rever alterações conforme o domínio.

## 9. Modelo canônico de pessoa/trabalho

**Pessoa** = identidade.  
**Vínculo Contratual** = relação da pessoa com um contrato e sua vigência.  
**Alocação** = posição temporal em composição/lotação/jornada/cargo.  
**Frequência** = fato diário associado canonicamente ao `vinculoContratualId` e resolvido pelo backend na data.

`Empregado` remanescente não será usado como CRUD negocial paralelo pelo novo frontend.

## 10. Pessoa e Vínculo

- `GET /api/pessoas` é paginado e suporta filtros.
- Não existe criação operacional isolada de Pessoa por POST canônico.
- `POST /api/vinculos-contratuais` é o fluxo integrado para vínculo e, quando cabível, nova pessoa.
- Antes da inclusão, consultar opções de alocação por contrato/data.
- Excesso de capacidade usa dados retornados pelo servidor e, quando permitido ao Gestor Local, exige confirmação + justificativa/evidência/autorização.

## 11. Alocação temporal

- Usar prévias antes de confirmações quando o endpoint as oferece.
- Exibir faixas temporais, eventos e posição “conhecido até”.
- Alterações retroativas podem gerar impactos/pendências; nunca editar silenciosamente registros históricos.
- No último dia do vínculo, alterações sujeitas à precedência exigem confirmação explícita do usuário.

## 12. Frequência

Payload canônico inclui `vinculoContratualId` e data/status/horários conforme DTO. O React não deve selecionar simultaneamente um `Empregado` paralelo. Estados como bloqueio operacional, revisão, validade operacional e versão devem ser exibidos quando retornados.

## 13. Documentos

- Base: `/api/contratos/{contratoId}/documentos`.
- Multipart com `metadados` JSON + arquivo conforme origem.
- Retificação/substituição/invalidação são versionadas.
- Dado/documento restrito pode exigir `finalidade` e autorização excepcional.
- 413/415 precisam de mensagem especializada.

## 14. Relatórios e exportações

- Consultas e agregações permanecem no backend.
- Preferir paginação server-side.
- Para exportação de grande volume, usar solicitação assíncrona + consulta de status + download.
- Relatório administrativo separa prévia, emissão, conhecimento e comparação vigente.
- Presidente não deve receber ação de emissão formal se o backend a proíbe.

## 15. Erros que exigem estado específico de UI

| HTTP/código | Tratamento esperado |
|---|---|
| 202 no login | desafio 2FA |
| 400 | validação / payload / campo inválido |
| 401 | sessão não autenticada/expirada; consultar código quando presente |
| 403 | perfil, escopo ou permissão insuficiente/expirada |
| 404 | recurso ausente ou contrato de rota incorreto |
| 409 | conflito negocial, temporal, idempotência ou concorrência |
| 413 | arquivo maior que o permitido |
| 415 | tipo de mídia não aceito |
| 428 | confirmação de senha necessária |
| 5xx | falha de servidor; exibir requestId para suporte |

## 16. Inventário de superfície REST

O inventário automatizado encontrou **282 mapeamentos HTTP em 44 controladores**. A lista completa está no CSV anexo. Abaixo, a distribuição por controlador:

- `VinculoContratualControlador`: 22 endpoint(s)
- `GovernancaTerceirosControlador`: 20 endpoint(s)
- `ContratoControlador`: 19 endpoint(s)
- `RelatorioControlador`: 16 endpoint(s)
- `DocumentoComprobatorioControlador`: 13 endpoint(s)
- `AutenticacaoControlador`: 12 endpoint(s)
- `UsuarioAplicacaoControlador`: 9 endpoint(s)
- `EmpregadoControlador`: 8 endpoint(s)
- `PerfilControlador`: 8 endpoint(s)
- `LotacaoControlador`: 6 endpoint(s)
- `FrequenciaControlador`: 6 endpoint(s)
- `RelatorioAdministrativoControlador`: 6 endpoint(s)
- `PainelControlador`: 6 endpoint(s)
- `PessoaControlador`: 6 endpoint(s)
- `RemanejamentoContratualControlador`: 5 endpoint(s)
- `ComposicaoContratualControlador`: 5 endpoint(s)
- `BancoControlador`: 5 endpoint(s)
- `AditamentoContratualControlador`: 5 endpoint(s)
- `TelefoneControlador`: 5 endpoint(s)
- `EnderecoControlador`: 5 endpoint(s)
- `SuperintendenciaControlador`: 5 endpoint(s)
- `StatusEmpregadoControlador`: 5 endpoint(s)
- `ContaControlador`: 5 endpoint(s)
- `FechamentoFrequenciaControlador`: 5 endpoint(s)
- `JornadaControlador`: 5 endpoint(s)
- `TipoContaControlador`: 5 endpoint(s)
- `AgenciaControlador`: 5 endpoint(s)
- `CargoControlador`: 5 endpoint(s)
- `PermissaoExcepcionalControlador`: 4 endpoint(s)
- `RegraAdicionalControlador`: 4 endpoint(s)
- `GestaoLocalControlador`: 4 endpoint(s)
- `FrequenciaAdicionalControlador`: 4 endpoint(s)
- `MotivoDesligamentoControlador`: 4 endpoint(s)
- `OcorrenciaControlador`: 4 endpoint(s)
- `HistoricoEmpregadoControlador`: 4 endpoint(s)
- `CalendarioEventoControlador`: 4 endpoint(s)
- `TipoContratacaoControlador`: 4 endpoint(s)
- `PendenciaAdministrativaControlador`: 4 endpoint(s)
- `FrequenciaExcecaoControlador`: 4 endpoint(s)
- `ConfiguracaoSistemaControlador`: 3 endpoint(s)
- `CorrecaoIdentificadorContratoControlador`: 3 endpoint(s)
- `RegistroAuditoriaControlador`: 2 endpoint(s)
- `PainelCalculoControlador`: 2 endpoint(s)
- `CacheDiagnosticoControlador`: 1 endpoint(s)


## 17. Política de cobertura no React

Nem todo endpoint exige uma rota própria. Um endpoint poderá ser consumido por modal, aba, drawer, componente auxiliar ou serviço. Entretanto, todo endpoint necessário aos requisitos de negócio deve ter uma decisão explícita na matriz de implementação: **consumir agora**, **consumir por fluxo pai**, **somente administrativo**, **somente backend/interno** ou **não aplicável ao React**.

A ausência de uma tela separada não autoriza ignorar um endpoint que seja pré-requisito de segurança, prévia, auditoria, histórico ou download.
