# SGT/GTRAT — Levantamento Completo de Requisitos de Implementação do Front-end React

**Versão:** 1.0  
**Data:** 11/09/2026  
**Status:** BASELINE PARA IMPLEMENTAÇÃO — sem alteração de código nesta etapa  
**Backend de referência:** pacote `JAVA.zip`, Java 17 / Spring Boot 3.5.16, pós-auditoria pré-React  
**Front-end de referência visual e estrutural:** `ReactFrontEndAntigo.zip`  
**Tecnologia-alvo:** React 19, Vite, JavaScript, CSS Modules, sem Tailwind CSS  

---

## 1. Objetivo

Este documento define a baseline funcional, técnica, de segurança, UX, integração e qualidade para evoluir o front-end React legado do SGT/GTRAT de modo que consuma corretamente a API Java atual.

O backend atual é a **fonte de verdade do contrato negocial e de segurança**. O React legado é uma **fonte de referência de identidade visual, navegação, componentes e experiência existente**, mas não pode prevalecer sobre regras que tenham sido alteradas no Java.

A implementação do React deve ser feita **sem alterar o backend**, salvo se durante a integração for demonstrado um defeito objetivo no Java. Divergência entre o React antigo e o contrato novo não é, por si só, bug no Java.

## 2. Fontes analisadas

Foram considerados, entre outros, os seguintes materiais presentes no pacote Java:

- `docs/CONTRATO_API_REACT_POS_AUDITORIA.md`;
- `docs/ETAPA_13_CORRECOES_POS_AUDITORIA_PRE_REACT.md`;
- `docs/LEVANTAMENTO_REQUISITOS.md` / referência V8;
- `docs/SGT_GTRAT_API_ALOCACAO_TEMPORAL_ETAPA_07.md`;
- `docs/SGT_GTRAT_API_DOCUMENTOS_ETAPA_08.md`;
- `docs/SGT_GTRAT_API_FREQUENCIA_ETAPA_09.md`;
- `docs/SGT_GTRAT_API_PERFIS_PERMISSOES_ETAPA_10.md`;
- controladores REST, DTOs, configuração Spring Security, tratamento de resposta/erro e testes do backend;
- toda a estrutura `src` do React antigo, suas rotas, serviços, contexto de autenticação, camada HTTP, CSS Modules, testes e arquivos de ambiente.

### 2.1 Indicadores da análise

- Backend: **44 controladores REST** e **282 mapeamentos HTTP** inventariados.
- Backend: documentação pós-auditoria específica para início do React e **198 requisitos canônicos** no levantamento V8 do domínio Java.
- React antigo: **22 rotas declaradas**, **30 arquivos de serviço/integração**, **113 CSS Modules** e suíte de testes já significativa.
- O React antigo já utiliza `axios` com `withCredentials: true`, mas ainda não implementa o contrato CSRF atual.
- O React antigo contém referências ao contrato legado `role/roles`, `ROLE_*`, `skipTwoFactor` e cadastro operacional via `/empregados`, que não podem ser mantidas como contrato canônico.

---

## 3. Decisões arquiteturais mandatórias

- **RFE-ARC-001** — O backend Java pós-auditoria será a fonte de verdade para regras negociais, escopo, permissões, validações e estados temporais.
- **RFE-ARC-002** — O React não duplicará regras negociais que possam divergir do servidor; fará apenas validações de UX que não substituam a validação oficial da API.
- **RFE-ARC-003** — O frontend será mantido em React + Vite, sem Tailwind CSS.
- **RFE-ARC-004** — CSS Modules serão o padrão para estilos de componentes e páginas; CSS global ficará restrito a reset, tokens, tipografia, acessibilidade e utilidades realmente transversais.
- **RFE-ARC-005** — A identidade visual Correios existente será preservada e organizada em design tokens reutilizáveis, sem gradientes não previstos no padrão do sistema.
- **RFE-ARC-006** — A base visual do React antigo deve ser evoluída, não descartada integralmente.
- **RFE-ARC-007** — A camada de integração HTTP será centralizada; páginas e componentes não deverão criar clientes Axios próprios.
- **RFE-ARC-008** — URLs, códigos de perfil, headers de segurança e convenções de resposta não deverão ser espalhados como literais sem centralização.
- **RFE-ARC-009** — O domínio canônico de colaborador no frontend será Pessoa + Vínculo Contratual + Alocação temporal; `Empregado` não poderá ser tratado como fonte negocial paralela.
- **RFE-ARC-010** — O frontend deverá respeitar bitemporalidade e data efetiva exibidas pelo backend, sem inferir estado apenas pela data do navegador.
- **RFE-ARC-011** — O frontend deverá representar estados de negócio (conflito, pendência, revisão, excesso, bloqueio, expiração de permissão) como estados de interface, e não como erro genérico.
- **RFE-ARC-012** — Toda operação destrutiva, irreversível ou de alto impacto deverá ter confirmação explícita e resumo do impacto antes do envio.
- **RFE-ARC-013** — Operações que exigem confirmação de senha usarão o mecanismo oficial `X-User-Password`, nunca senha no payload salvo quando o endpoint formalmente assim exigir.
- **RFE-ARC-014** — Operações que exigem idempotência deverão gerar e conservar chave estável por intenção negocial até sucesso ou abandono da ação.
- **RFE-ARC-015** — Nenhum segredo, JWT de sessão ou token HttpOnly será lido ou persistido pelo React.
- **RFE-ARC-016** — O backend não será modificado para acomodar código legado do React quando o contrato novo já estiver documentado e implementado.
- **RFE-ARC-017** — Qualquer possível bug encontrado no Java deverá ser registrado com endpoint, payload, resposta, resultado esperado, reprodução e evidência antes de propor correção no backend.
- **RFE-ARC-018** — Cada etapa futura deverá entregar código, testes, MD de alterações, MD de pendências e pacote ZIP versionado, preservando rastreabilidade.

## 4. Integração HTTP, segurança e sessão

### 4.1 Segurança

- **RFE-SEC-001** — Todas as requisições autenticadas deverão enviar cookies com `credentials/include` / `withCredentials: true`.
- **RFE-SEC-002** — Antes de qualquer POST, PUT, PATCH ou DELETE, o cliente deverá garantir token CSRF válido obtido por `GET /api/autenticacao/csrf`.
- **RFE-SEC-003** — O token CSRF será enviado no header indicado pela própria resposta do endpoint CSRF, normalmente `X-XSRF-TOKEN`.
- **RFE-SEC-004** — O cliente deverá suportar renovação/reobtenção de CSRF após nova autenticação, troca de sessão, falha compatível com token inválido ou reinicialização do estado da aplicação.
- **RFE-SEC-005** — Requisições GET/HEAD não deverão disparar confirmação de senha ou mutação de estado no cliente.
- **RFE-SEC-006** — A camada HTTP deverá continuar aceitando `X-Request-Id`, `X-Client` e `X-Timezone`, usando valores consistentes e rastreáveis.
- **RFE-SEC-007** — O frontend deverá tratar HTTP 202 do login como estado de desafio 2FA, não como login concluído.
- **RFE-SEC-008** — O campo legado `skipTwoFactor` não poderá mais ser enviado.
- **RFE-SEC-009** — Quando 2FA estiver ativo, ausência de TOTP deverá conduzir à etapa obrigatória de código; a UI não apresentará opção de ignorar 2FA.
- **RFE-SEC-010** — Credenciais de sessão serão mantidas exclusivamente por cookies/servidor; não armazenar JWT em localStorage, sessionStorage ou IndexedDB.
- **RFE-SEC-011** — O logout deverá limpar somente estado local de sessão e chamar o endpoint oficial de encerramento; não simular logout apenas removendo dados locais.
- **RFE-SEC-012** — O React deverá consultar `/api/autenticacao/sessao` para restaurar/validar sessão e considerar códigos de sessão retornados pela API.
- **RFE-SEC-013** — O frontend deverá lidar com sessão expirada, substituída, dispositivo ausente/divergente, conta inativa e claims inválidos com fluxos distintos quando o backend os distinguir.
- **RFE-SEC-014** — A renovação de sessão deverá usar o endpoint oficial, evitando timers excessivos ou chamadas concorrentes duplicadas.
- **RFE-SEC-015** — 401 deverá invalidar o estado autenticado somente quando realmente representar sessão não autenticada/expirada, evitando loops de redirecionamento.
- **RFE-SEC-016** — 403 deverá ser interpretado como ausência de autorização/escopo/permissão, não como sessão necessariamente inválida.
- **RFE-SEC-017** — 409 deverá ser tratado como conflito negocial/idempotência/concorrência e permitir orientação específica ao usuário.
- **RFE-SEC-018** — 428 / código `PASSWORD_CONFIRMATION_REQUIRED` deverá abrir ou acionar o fluxo padronizado de confirmação de senha e repetir a intenção de forma controlada.
- **RFE-SEC-019** — A senha de confirmação não poderá ser armazenada de forma persistente, logada ou reutilizada fora da intenção explicitamente confirmada.
- **RFE-SEC-020** — Falha de senha de confirmação deverá limpar a senha da memória de formulário e manter a ação pendente apenas se seguro.
- **RFE-SEC-021** — Uploads e downloads de documentos deverão respeitar credenciais, CSRF nas mutações, tipo MIME e limites retornados pelo backend.
- **RFE-SEC-022** — A interface não deverá inferir acesso a dados pessoais restritos apenas por perfil; deverá obedecer à permissão excepcional e finalidade exigidas pelo servidor.
- **RFE-SEC-023** — Finalidade de acesso a dados restritos deverá ser preenchida explicitamente, enviada ao endpoint e exibida como ação auditável.
- **RFE-SEC-024** — Campos sensíveis mascarados pelo backend não deverão ser “reconstruídos” no browser.
- **RFE-SEC-025** — O frontend deverá impedir exposição acidental de dados pessoais em logs de console, telemetry, URLs, títulos de página ou mensagens de erro.
- **RFE-SEC-026** — A aplicação deverá usar proteção contra double-submit no nível de UI para comandos críticos, além da idempotência de backend quando disponível.
- **RFE-SEC-027** — Botões de mutação deverão entrar em estado de processamento até resposta definitiva, evitando disparos repetidos.
- **RFE-SEC-028** — Confirmações críticas deverão descrever entidade, data efetiva e consequência, especialmente anulação, cancelamento, desligamento, transferência e invalidação documental.
- **RFE-SEC-029** — O frontend deverá respeitar `SameSite`/cookie settings do backend sem tentar substituí-los por tokens manuais.
- **RFE-SEC-030** — Em produção, a origem da API deverá vir de configuração de ambiente; não codificar hosts, credenciais ou certificados no bundle.

### 4.2 Autenticação, perfis e guards

- **RFE-AUT-001** — O login usará `{matricula, password, totp}` e não enviará campos legados.
- **RFE-AUT-002** — O fluxo de login deverá suportar resposta 202 `{requiresTwoFactor:true, canSkipTwoFactor:false}`.
- **RFE-AUT-003** — Após autenticação, o frontend deverá consumir `perfil` e `autoridade` canônicos da sessão/resposta.
- **RFE-AUT-004** — Os perfis canônicos são: ADMINISTRADOR, GESTOR_NACIONAL, GESTOR_ESTADUAL, GESTOR_LOCAL, PRESIDENTE e OPERACIONAL.
- **RFE-AUT-005** — As authorities canônicas são: PERFIL_ADMINISTRADOR, PERFIL_GESTOR_NACIONAL, PERFIL_GESTOR_ESTADUAL, PERFIL_GESTOR_LOCAL, PERFIL_PRESIDENTE e PERFIL_OPERACIONAL.
- **RFE-AUT-006** — O contrato legado `role`, `roles`, `ROLE_ADMIN`, `ROLE_SUPERINTENDENCIA`, `ROLE_USER` e equivalentes não poderá dirigir guards ou payloads novos.
- **RFE-AUT-007** — Guards de rota deverão usar autoridade/perfil e, quando necessário, dados de escopo recebidos do backend.
- **RFE-AUT-008** — A visibilidade de botão não substituirá autorização; ações ocultas continuam protegidas no servidor.
- **RFE-AUT-009** — O Gestor Local será tratado como principal perfil de escrita negocial dentro de seu escopo.
- **RFE-AUT-010** — Gestores Estadual e Nacional terão leitura/auditoria conforme escopo, sem receber ações negociais que o backend proíbe.
- **RFE-AUT-011** — O Presidente terá leitura nacional para painéis/relatórios permitidos, sem emissão formal ou mutações proibidas.
- **RFE-AUT-012** — O Operacional terá interfaces estritamente limitadas às operações permitidas e ao escopo temporal/histórico de frequência.
- **RFE-AUT-013** — O Administrador não deverá ser promovido visualmente a “dono do negócio”; intervenções excepcionais deverão depender das permissões oficiais.
- **RFE-AUT-014** — Tela de usuário deverá enviar/editar `perfil`, não `role`.
- **RFE-AUT-015** — O contexto de autenticação deverá eliminar síntese artificial de arrays de roles legados.
- **RFE-AUT-016** — A troca de senha inicial obrigatória deverá bloquear acesso às áreas privadas até conclusão quando `forceChangePassword` indicar exigência.
- **RFE-AUT-017** — Configuração/ativação/desativação de 2FA deverá usar endpoints de perfil e refletir estado real retornado pelo servidor.
- **RFE-AUT-018** — Recuperação de senha deverá manter o fluxo oficial solicitar → validar token → confirmar.
- **RFE-AUT-019** — Avatar e dados de perfil deverão respeitar limites/tipos do endpoint e cache-busting controlado após alteração.
- **RFE-AUT-020** — O frontend deverá mostrar nome, escopo e perfil atuais sem inventar rótulos inconsistentes com os valores canônicos.

### 4.3 Cliente HTTP, envelope, erros e paginação

- **RFE-HTTP-001** — A camada Axios deverá normalizar o envelope `RespostaApi`, preservando `data`, `meta`, `requestId`, `status`, `message`, `error` e `path` quando relevantes.
- **RFE-HTTP-002** — O interceptor atual que retorna somente `data` deverá ser revisto para não descartar metadados úteis de paginação e rastreabilidade.
- **RFE-HTTP-003** — Paginação deverá usar `page`/`size` conforme contrato do endpoint e metadados oficiais; não calcular total a partir apenas da página corrente.
- **RFE-HTTP-004** — Filtros vazios deverão ser omitidos de forma consistente, evitando enviar strings vazias quando semanticamente diferentes de ausência.
- **RFE-HTTP-005** — Datas de negócio deverão usar formato ISO esperado pelo Java, principalmente `YYYY-MM-DD` para datas efetivas.
- **RFE-HTTP-006** — Data/hora local de UX deverá respeitar `America/Sao_Paulo` quando a regra do backend assim define, sem depender da timezone física do equipamento.
- **RFE-HTTP-007** — O header `X-Timezone` deverá refletir timezone acordada pelo sistema e não ser fonte exclusiva da regra negocial.
- **RFE-HTTP-008** — GETs idempotentes poderão manter política de retry limitada; POST/PUT/PATCH/DELETE não terão retry automático genérico.
- **RFE-HTTP-009** — Reenvio de comando idempotente deverá reutilizar a mesma chave apenas quando for exatamente a mesma intenção.
- **RFE-HTTP-010** — Uma nova intenção negocial deverá gerar nova chave de idempotência.
- **RFE-HTTP-011** — Erros de validação 400 deverão ser associados aos campos quando houver informação suficiente, mantendo também mensagem geral.
- **RFE-HTTP-012** — 404 deverá distinguir recurso inexistente de rota incorreta/desatualizada durante desenvolvimento.
- **RFE-HTTP-013** — 409 deverá manter detalhes de conflito e oferecer recarregar/reavaliar prévia quando aplicável.
- **RFE-HTTP-014** — 413 e 415 em documentos deverão ser convertidos em mensagens de tamanho/tipo de arquivo compreensíveis.
- **RFE-HTTP-015** — 5xx deverá exibir mensagem segura com `requestId` quando disponível, permitindo suporte sem revelar stack trace.
- **RFE-HTTP-016** — O cliente deverá cancelar ou ignorar respostas obsoletas em buscas/filtros rápidos para evitar race conditions visuais.
- **RFE-HTTP-017** — Listagens grandes deverão usar paginação/consulta no servidor e nunca carregar universo completo por padrão.
- **RFE-HTTP-018** — Debounce poderá ser utilizado em busca textual, sem alterar semântica de filtros de data/estado.
- **RFE-HTTP-019** — Componentes não deverão depender da forma interna de entidades JPA; somente DTOs/respostas REST fazem parte do contrato.
- **RFE-HTTP-020** — Enums e estados exibidos deverão ter tradutor visual centralizado, mantendo o valor canônico original para comunicação com API.
- **RFE-HTTP-021** — A camada de API deverá suportar respostas binárias de exportação/documentos sem aplicar parser JSON indevido.
- **RFE-HTTP-022** — Multipart deverá ser construído conforme contrato, inclusive parte `metadados` JSON e arquivo opcional/obrigatório conforme origem.
- **RFE-HTTP-023** — O tratamento de loading deverá distinguir carregamento inicial, atualização de filtro, paginação, mutação e background refresh.
- **RFE-HTTP-024** — A aplicação deverá ter estratégia comum de empty state, erro de consulta, permissão negada e conteúdo indisponível.
- **RFE-HTTP-025** — O `requestId` retornado pelo backend deverá poder ser copiado na UI de detalhes de erro para suporte.

## 5. UI, identidade visual e usabilidade

- **RFE-UX-001** — Manter identidade Correios com azul institucional, amarelo institucional, neutros, tipografia e hierarquia visual já presentes no React antigo.
- **RFE-UX-002** — Não introduzir Tailwind CSS, bibliotecas utility-first equivalentes ou dependência que desconfigure o padrão CSS Modules solicitado.
- **RFE-UX-003** — Reduzir progressivamente classes utilitárias globais do `index.css` que imitam Tailwind; manter global apenas o que for realmente transversal.
- **RFE-UX-004** — Cada página deverá ter CSS Module próprio ou módulos compartilhados por componente de design system.
- **RFE-UX-005** — A aplicação deverá funcionar em desktop corporativo e possuir comportamento responsivo para larguras menores sem perder operações essenciais.
- **RFE-UX-006** — Menus deverão ser derivados de capacidade/perfil para não exibir rotas inalcançáveis.
- **RFE-UX-007** — Breadcrumbs/títulos deverão identificar contexto de contrato, pessoa, vínculo e data efetiva em fluxos profundos.
- **RFE-UX-008** — Filtros deverão ser persistidos apenas quando útil e nunca manter contexto de segurança de outro usuário após logout.
- **RFE-UX-009** — Tabelas extensas deverão suportar paginação, estados de carregamento e cabeçalho legível; virtualização poderá ser aplicada quando comprovadamente necessária.
- **RFE-UX-010** — Ações destrutivas deverão usar modal de confirmação; ações simples não deverão gerar modais desnecessários.
- **RFE-UX-011** — Prévia negocial retornada pelo backend deverá ser visualizada antes de confirmação sempre que houver endpoint de prévia.
- **RFE-UX-012** — Impactos, incompatibilidades, excesso de capacidade, pendências e estado “sujeito a revisão” deverão ter destaque sem depender apenas de cor.
- **RFE-UX-013** — Mensagens de sucesso deverão indicar a consequência realizada e, quando disponível, a nova versão/estado.
- **RFE-UX-014** — Toasts não deverão ser o único local para informação importante; erros de formulário e estados persistentes devem permanecer visíveis.
- **RFE-UX-015** — Formulários deverão bloquear campos que o backend não permite editar no estado atual, mas ainda tratar 403/409 caso haja concorrência.
- **RFE-UX-016** — Datas, números e documentos deverão seguir formatação pt-BR na apresentação e formato canônico no transporte.
- **RFE-UX-017** — Labels de perfis e estados devem ser consistentes em toda a aplicação.
- **RFE-UX-018** — Acessibilidade mínima: navegação por teclado, foco visível, label associado, aria quando necessário, contraste adequado e leitura por screen reader.
- **RFE-UX-019** — Ícones deverão ter rótulo/tooltip acessível quando não acompanhados de texto.
- **RFE-UX-020** — Exportações PDF/XLSX deverão manter os ícones/ações solicitados nas páginas pertinentes, usando geração no backend quando o contrato atual oferecer exportação assíncrona.

## 6. Contratos, composições e documentos

- **RFE-CON-001** — A tela de contratos deverá deixar de ser somente CRUD genérico e representar o ciclo de vida contratual completo disponibilizado pela API.
- **RFE-CON-002** — A listagem deverá consumir filtros/opções oficiais e respeitar escopo retornado pelo backend.
- **RFE-CON-003** — O detalhe de contrato deverá expor estado administrativo, estado temporal, vigência, gestão responsável, identificador e eventos relevantes.
- **RFE-CON-004** — Criação deverá nascer como rascunho e respeitar o payload/validações atuais.
- **RFE-CON-005** — Edição direta deverá ficar restrita ao estado em que o backend permite editar o rascunho.
- **RFE-CON-006** — Publicação deverá ser ação explícita, confirmada e protegida por senha quando exigido.
- **RFE-CON-007** — Inativação administrativa e reativação deverão ser apresentadas como conceitos distintos do encerramento temporal.
- **RFE-CON-008** — Encerramento antecipado deverá ter fluxo próprio, não ser representado como simples inativação.
- **RFE-CON-009** — Cancelamento futuro deverá ser fluxo próprio, com data/motivo/evidências conforme DTO.
- **RFE-CON-010** — Anulação deverá ser tratada como evento negocial forte e não como delete.
- **RFE-CON-011** — Correção de anulação deverá exigir relacionamento de correção e deixar claro que não reativa o contrato automaticamente.
- **RFE-CON-012** — Transferência de gestão deverá ter pré-condições, confirmação e exibição de histórico de transferências.
- **RFE-CON-013** — A posição temporal do contrato deverá poder ser consultada na data/conhecimento suportados pela API.
- **RFE-CON-014** — Eventos, precedências e versões deverão ser navegáveis para auditoria/reconstrução histórica.
- **RFE-CON-015** — Delete de contrato só poderá ser oferecido quando se tratar de rascunho eliminável conforme servidor.
- **RFE-CON-016** — Composições contratuais deverão representar explicitamente Lotação + Jornada/Turno + Cargo + efetivo previsto + vigência.
- **RFE-CON-017** — A UI não poderá criar produto cartesiano automático de lotações/turnos/cargos que não exista no contrato.
- **RFE-CON-018** — Inclusão/edição/exclusão de composição deverá respeitar ocupação atual e impedimentos do servidor.
- **RFE-CON-019** — O monitor de composições excedentes deverá existir por contrato/data.
- **RFE-CON-020** — Opções de alocação deverão mostrar efetivo previsto, ocupação atual, ocupação após inclusão e excedente projetado quando retornados.
- **RFE-CON-021** — Capacidade zero deverá ser exibida como indisponível; não oferecer confirmação que o backend sempre rejeitará.
- **RFE-CON-022** — Excesso permitido deverá ser confirmado somente no perfil autorizado, com justificativa, evidência e autorização exigidas.
- **RFE-CON-023** — Aditamentos deverão ter listagem, prévia, confirmação, retificação e cancelamento conforme endpoints atuais.
- **RFE-CON-024** — A prévia de aditamento deverá ser exibida de maneira comparativa antes do comando efetivo.
- **RFE-CON-025** — Redução de efetivo por aditamento que conflite com ocupação deverá mostrar o conflito vindo do servidor e não tentar recalcular de forma autoritativa no React.
- **RFE-CON-026** — Remanejamentos deverão ter listagem, prévia, confirmação, retificação e cancelamento.
- **RFE-CON-027** — Remanejamento deverá evidenciar origem, destino, data efetiva e impactos nas composições/alocações.
- **RFE-CON-028** — Documentos comprobatórios deverão ser acessíveis no contexto do contrato e do fato negocial.
- **RFE-CON-029** — O frontend deverá suportar documento com origem ANEXO, SEI ou ambos, conforme contrato.
- **RFE-CON-030** — Upload deverá aceitar `metadados` + arquivo e validar UX sem substituir regras de arquivo do servidor.
- **RFE-CON-031** — Documento deverá exibir grupo lógico, versão, estado, nível de acesso, fato vinculado, data efetiva e referência SEI quando houver.
- **RFE-CON-032** — Retificação de SEI, substituição e invalidação deverão ser ações versionadas, não edição destrutiva do registro publicado.
- **RFE-CON-033** — Delete de documento deverá aparecer apenas para rascunho eliminável conforme regra da API.
- **RFE-CON-034** — Download de documento pessoal restrito deverá exigir finalidade quando o endpoint exigir e registrar o acesso no backend.
- **RFE-CON-035** — Administração de permissões de documento deverá existir somente para perfis/authorities autorizados.
- **RFE-CON-036** — Histórico de acessos de documento deverá ser exibível para auditoria autorizada.
- **RFE-CON-037** — Correção de número/ano do contrato deverá utilizar o endpoint específico de correção de identificador, jamais PUT genérico no contrato publicado.
- **RFE-CON-038** — O fluxo de correção de identificador deverá validar permissão excepcional ativa e manter chave idempotente estável por intenção.
- **RFE-CON-039** — Pesquisa histórica por número/ano antigo ou novo deverá usar o endpoint de histórico de identificador.
- **RFE-CON-040** — Todos os comandos contratuais deverão atualizar/inutilizar caches locais e recarregar os dados oficiais após sucesso.

## 7. Pessoa, vínculo contratual e alocação temporal

- **RFE-VIN-001** — A área atualmente chamada “Empregados” deverá ser redesenhada conceitualmente para Pessoa / Vínculo Contratual / Alocação, mesmo que o rótulo de menu possa continuar amigável ao usuário.
- **RFE-VIN-002** — `Pessoa` representa identidade; `Vínculo Contratual` representa relação com contrato; `Alocação` representa onde/como a pessoa está posicionada ao longo do tempo.
- **RFE-VIN-003** — O frontend não deverá criar Pessoa isolada por POST inexistente; criação operacional deve ocorrer pelo fluxo integrado de Vínculo.
- **RFE-VIN-004** — Listagem de pessoas deverá usar `/api/pessoas` com busca, contrato, data ativa e paginação do servidor.
- **RFE-VIN-005** — Detalhe de pessoa deverá usar `/api/pessoas/{id}` e separar dados comuns de dados restritos.
- **RFE-VIN-006** — Dados restritos deverão ser carregados sob demanda, com finalidade, somente para usuário autorizado.
- **RFE-VIN-007** — Correção de identidade deverá usar endpoint específico e ser exibida como evento auditável.
- **RFE-VIN-008** — Dados opcionais poderão ser alterados no endpoint específico, mediante confirmação de senha quando exigido.
- **RFE-VIN-009** — Listagem de vínculos deverá ser a fonte canônica para relação pessoa-contrato e suportar os filtros oficiais.
- **RFE-VIN-010** — Criação de vínculo deverá permitir selecionar pessoa existente ou informar nova pessoa conforme DTO integrado aceito pela API.
- **RFE-VIN-011** — Antes de criar vínculo, o frontend deverá consultar opções de alocação para contrato/data.
- **RFE-VIN-012** — Ocupação/excesso projetado retornado pela prévia/opções deve ser exibido ao usuário antes da confirmação.
- **RFE-VIN-013** — Quando inclusão excedente for elegível, o Gestor Local deverá poder fornecer todos os campos obrigatórios de justificativa/evidência/autorização.
- **RFE-VIN-014** — O navegador nunca deverá considerar a prévia de capacidade como garantia; a resposta final do POST é autoritativa.
- **RFE-VIN-015** — Detalhe do vínculo deverá mostrar vigência, matrícula, pessoa, contrato, situação derivada e alocação correspondente.
- **RFE-VIN-016** — Eventos do vínculo deverão estar acessíveis para reconstrução histórica.
- **RFE-VIN-017** — Alocações deverão ser apresentadas como faixas temporais versionadas e nunca como um único “local atual” sobrescrevível.
- **RFE-VIN-018** — A consulta mensal/temporal de alocações deverá apoiar entendimento do histórico e programação futura.
- **RFE-VIN-019** — A tela deverá usar endpoints de posição temporal quando o usuário consultar “como era conhecido até” determinada data/hora.
- **RFE-VIN-020** — Prévia de retificação da data inicial do vínculo deverá ser exibida antes da confirmação.
- **RFE-VIN-021** — Retificação de início deverá usar o token/resultado da prévia e tratar incompatibilidades concorrentes.
- **RFE-VIN-022** — Alteração de alocação deverá usar fluxo de prévia e confirmação quando aplicável.
- **RFE-VIN-023** — Retificação de alocação deverá preservar histórico e não simular edição destrutiva.
- **RFE-VIN-024** — Cancelamento de programação futura de alocação deverá ser ação explícita e não delete genérico.
- **RFE-VIN-025** — Quando uma alteração/retificação tiver data efetiva igual ao último dia do vínculo, a UI deverá solicitar confirmação explícita de precedência e enviar `confirmarPrecedenciaUltimoDia=true` quando o usuário confirmar.
- **RFE-VIN-026** — Alteração de matrícula deverá usar endpoint específico do vínculo e não editar o objeto Pessoa.
- **RFE-VIN-027** — Desligamento deverá ter fluxo próprio com motivo/data/evidências conforme contrato.
- **RFE-VIN-028** — Retificação de desligamento deverá usar prévia antes de confirmação quando prevista pela API.
- **RFE-VIN-029** — Cancelamento de desligamento programado deverá aparecer como ação distinta de reativação.
- **RFE-VIN-030** — Fim natural do contrato deverá ser tratado pelo comando disponibilizado para o contexto autorizado e não por manipulação de datas no browser.
- **RFE-VIN-031** — Historicamente, frequência deve continuar associada ao vínculo/alocação válidos na data de referência, mesmo que a pessoa tenha mudado depois.
- **RFE-VIN-032** — Endpoints `/empregados` remanescentes poderão ser usados somente onde o backend ainda os oferece como projeção/compatibilidade; não devem voltar a ser a fonte canônica de cadastro negocial.
- **RFE-VIN-033** — Formulários antigos que enviam objeto Empregado completo por POST/PUT deverão ser substituídos pelo novo conjunto de fluxos canônicos.
- **RFE-VIN-034** — Filtros de lotação, jornada e cargo deverão usar as opções válidas no contexto e na data efetiva, evitando listas globais incoerentes.

## 8. Frequência, fechamentos, calendário e ocorrências

- **RFE-FRE-001** — Frequência deverá ser registrada de forma canônica com `vinculoContratualId`; o usuário não escolherá um Empregado paralelo para a mesma intenção.
- **RFE-FRE-002** — O backend resolverá pessoa, alocação, contrato, lotação, jornada, cargo e gestão local válidos na data; o frontend não deverá forçar snapshots divergentes.
- **RFE-FRE-003** — A tela diária deverá consumir listagem paginada/filtrada da API e preservar data de referência explícita.
- **RFE-FRE-004** — A tela mensal deverá usar endpoint mensal; intervalo deverá usar endpoint de intervalo quando apropriado.
- **RFE-FRE-005** — Eventos de cada frequência deverão ficar disponíveis para auditoria de versões/retificações.
- **RFE-FRE-006** — Registro individual e em lote deverão exigir confirmação de senha conforme contrato atual.
- **RFE-FRE-007** — Operacional deverá visualizar somente o escopo permitido e respeitar janela temporal oficial do servidor.
- **RFE-FRE-008** — A UI poderá indicar prazo de edição usando `prazoEdicao`/metadados retornados, mas não codificar uma janela diferente como regra autoritativa.
- **RFE-FRE-009** — O dia operacional de jornada noturna deverá ser apresentado de acordo com a data de início definida pelo backend.
- **RFE-FRE-010** — Após retificação por gestor, a frequência deverá aparecer bloqueada para edição operacional.
- **RFE-FRE-011** — Gestor Local deverá informar justificativa de retificação e chave idempotente quando o contrato exigir.
- **RFE-FRE-012** — Uma mesma chave idempotente não poderá ser reaproveitada para conteúdo diferente.
- **RFE-FRE-013** — `SUJEITA_REVISAO`, validade operacional, estado de auditoria e versão negocial deverão aparecer quando relevantes.
- **RFE-FRE-014** — Retroatividade que afete frequências deverá ser refletida como revisão/pendência, não como alteração silenciosa de registro fechado.
- **RFE-FRE-015** — Relatórios oficiais deverão usar o estado calculado no servidor, inclusive exclusão de frequência operacionalmente inválida quando aplicável.
- **RFE-FRE-016** — Fechamentos deverão possuir telas/ações de criação, consulta do atual, detalhe, cancelamento e reprocessamento conforme autorização.
- **RFE-FRE-017** — Reprocessamento de fechamento deverá ser claramente identificado como operação de alto impacto.
- **RFE-FRE-018** — Exceções e adicionais de frequência existentes na API deverão permanecer integrados às telas que deles dependem, respeitando escopo e autorização atuais.
- **RFE-FRE-019** — Calendário/feriados/folgas deverão ser carregados da API, filtrados pelo escopo, sem bloquear indevidamente perfis que têm leitura autorizada.
- **RFE-FRE-020** — Ocorrências deverão manter listagem, criação, exclusão e download de anexo conforme endpoints e permissões.
- **RFE-FRE-021** — Anexo de ocorrência deverá ser baixado com tratamento binário e nome/tipo seguro.
- **RFE-FRE-022** — Não registrar presença para vínculo inexistente, futuro, encerrado ou fora da alocação válida; deixar a validação final ao servidor e explicar a rejeição.
- **RFE-FRE-023** — Pendentes “sem lançamento” deverão ser calculados/consumidos conforme backend, não inferidos por lista incompleta carregada no cliente.
- **RFE-FRE-024** — Operações em lote deverão mostrar resumo de sucesso/falha por item quando a API fornecer granularidade.
- **RFE-FRE-025** — A tela deverá impedir submissão simultânea acidental do mesmo lote.

## 9. Painel e indicadores

- **RFE-PAI-001** — O Painel deverá consumir os endpoints atuais de filtros e efetivo, não reconstruir métricas a partir de listas locais.
- **RFE-PAI-002** — Filtros de contrato, lotação, turno/jornada e cargo deverão ser dinâmicos e coerentes com o recorte disponível.
- **RFE-PAI-003** — A opção “Todos” deverá preservar o comportamento funcional esperado sem enviar IDs inválidos; quando houver painéis desagregados, usar dados retornados/consultas apropriadas.
- **RFE-PAI-004** — O painel deverá permitir navegação entre datas, não apenas data atual.
- **RFE-PAI-005** — Métricas principais deverão contemplar previsto/acionado, presentes, ausentes e pendentes conforme contrato atual.
- **RFE-PAI-006** — Quando selecionado “Todos” em dimensões relevantes, a UI deverá suportar visão geral e detalhamentos separados conforme requisito de negócio.
- **RFE-PAI-007** — Gestor Nacional deverá voltar a ver indicadores autorizados; guards do frontend não poderão ocultá-los por causa do antigo mapa de roles.
- **RFE-PAI-008** — Presidente deverá receber leitura nacional autorizada, sem ações de escrita.
- **RFE-PAI-009** — Gestor Estadual deverá receber o recorte de seu estado; Gestor Local, seu recorte; Operacional somente o que for permitido.
- **RFE-PAI-010** — Gráficos de linhas, barras e dispersão poderão ser disponibilizados quando fizerem sentido, mantendo leitura tabular acessível.
- **RFE-PAI-011** — O “infográfico” deverá ser entendido como apresentação visual das mesmas métricas oficiais, não como cálculo paralelo.
- **RFE-PAI-012** — Cores das séries deverão ser distintas, consistentes e acessíveis, respeitando o padrão Correios.
- **RFE-PAI-013** — Layout do painel deverá ser compacto e evitar cartões/retângulos redundantes.
- **RFE-PAI-014** — Carregamentos de filtros e dados deverão evitar refresh completo da página e preservar estado React corretamente.
- **RFE-PAI-015** — Consultas concorrentes de filtros deverão descartar resposta antiga para não trocar o recorte selecionado.
- **RFE-PAI-016** — Painel de gestão, estatísticas, atividades e ranking de lotações deverão ser mantidos/reavaliados conforme endpoints atuais.
- **RFE-PAI-017** — Exportação de indicadores, quando exigida pelo requisito de negócio, deverá usar dados oficiais e ter PDF/XLSX conforme estratégia de backend existente ou implementação acordada sem recalcular regra negocial no browser.
- **RFE-PAI-018** — Grandes volumes não deverão ser baixados para cálculo de gráfico quando a API já fornece agregação.
- **RFE-PAI-019** — Empty states deverão distinguir “sem dados no período” de “sem permissão/escopo”.
- **RFE-PAI-020** — Cada gráfico deverá ter alternativa textual/tabela ou descrição suficiente para acessibilidade e conferência.

## 10. Relatórios, emissões e exportações

- **RFE-REL-001** — Relatórios deverão usar filtros oficiais de `/api/relatorios/filtros` e evitar listas de seleção obsoletas hardcoded.
- **RFE-REL-002** — Frequência consolidada deverá oferecer consulta e paginação server-side.
- **RFE-REL-003** — Absenteísmo deverá oferecer consulta, versão paginada e resumo oficial do backend.
- **RFE-REL-004** — Relatório de terceirizados deverá usar o consolidado da API.
- **RFE-REL-005** — Horas trabalhadas deverão usar o endpoint específico e não cálculo no React.
- **RFE-REL-006** — Exportações deverão preferir endpoints oficiais e suportar fluxo assíncrono solicitação → status → download quando disponibilizado.
- **RFE-REL-007** — A UI deverá consultar `/api/relatorios/exportacoes/{id}` até estado terminal com cadência controlada, sem polling agressivo.
- **RFE-REL-008** — Download final deverá usar `/arquivo` como binário e respeitar nome/tipo retornados.
- **RFE-REL-009** — Exportação síncrona existente poderá ser usada apenas quando apropriada ao volume; grandes volumes deverão preferir solicitação assíncrona.
- **RFE-REL-010** — Opções de paginação ampliadas deverão ser apresentadas apenas se compatíveis com limites do backend; “Todos” não deverá contornar paginação carregando volume inviável no navegador.
- **RFE-REL-011** — Relatórios durante pendência/revisão deverão mostrar aviso “sujeito a revisão” e quantidade afetada quando os dados da API suportarem essa informação.
- **RFE-REL-012** — A interface deverá manter filtros de estado/contrato/lotação/turno/cargo coerentes com escopo e período.
- **RFE-REL-013** — Gestor Nacional, Estadual, Local, Presidente e Administrador terão leitura somente conforme autorização efetiva do backend.
- **RFE-REL-014** — Presidente não deverá receber ação de emissão formal quando o endpoint administrativo a proíbe.
- **RFE-REL-015** — Relatório administrativo deverá possuir fluxo de prévia antes de emissão.
- **RFE-REL-016** — Emissão formal deverá preservar identificador e instante de conhecimento retornados pelo backend.
- **RFE-REL-017** — Consulta de emissão deverá permitir visualizar o snapshot emitido sem recalculá-lo com dados atuais.
- **RFE-REL-018** — Comparação com vigente deverá destacar diferenças entre emissão histórica e estado atual.
- **RFE-REL-019** — Consulta por “conhecimento em” deverá usar o endpoint administrativo apropriado.
- **RFE-REL-020** — Listagem de emissões deverá ser paginada e filtrável conforme API.
- **RFE-REL-021** — PDF/XLSX deverá ser acionado por ícones/botões consistentes nas páginas solicitadas e com estados de geração/downloading.
- **RFE-REL-022** — Falha de exportação assíncrona deverá exibir erro da tarefa e permitir nova solicitação com nova intenção.
- **RFE-REL-023** — Exportações concluídas não deverão ser interpretadas como autorização permanente de acesso fora da sessão/escopo.
- **RFE-REL-024** — A meta de absenteísmo e demais parâmetros analíticos não deverão ser fixados em `.env` como regra oficial se o backend já os calcula/fornece.
- **RFE-REL-025** — Relatórios deverão ser conferíveis: totais do cabeçalho, paginação, filtros e exportação devem se referir ao mesmo recorte.

## 11. Administração, pendências, auditoria e governança

- **RFE-ADM-001** — Gestão de usuários deverá migrar payloads e filtros para `perfil` canônico.
- **RFE-ADM-002** — Criação, edição, ativação, desativação/exclusão lógica, redefinição de senha e acesso retroativo deverão respeitar escopo e confirmação de senha.
- **RFE-ADM-003** — Conceder e revogar acesso retroativo deverão ser fluxos explícitos e auditáveis.
- **RFE-ADM-004** — Catálogos de banco, agência, tipo de conta e cargo deverão continuar acessíveis somente para escrita nos perfis autorizados pelo backend.
- **RFE-ADM-005** — Lotação e jornada/turno deverão respeitar leitura ampla autorizada e escrita de Gestor Local quando definida pelo backend.
- **RFE-ADM-006** — Superintendência e Gestão Local deverão respeitar endpoints/escopos atuais, sem presumir que o antigo `ROLE_SUPERINTENDENCIA` continua existindo.
- **RFE-ADM-007** — Tipos de contratação, motivos de desligamento, status e demais catálogos deverão ser integrados conforme uso efetivo das telas.
- **RFE-ADM-008** — Permissões excepcionais deverão ter tela de listagem, concessão, revogação e usos para perfis autorizados.
- **RFE-ADM-009** — A concessão de permissão excepcional deverá indicar tipo, alvo, validade, fundamento e demais campos exigidos pelo DTO.
- **RFE-ADM-010** — Expiração/revogação de permissão deverá ser mostrada como estado de domínio; um 403 após abertura da tela pode significar mudança concorrente e deve ser explicado.
- **RFE-ADM-011** — Pendências administrativas deverão ter listagem, resumo, início de tratamento e confirmação de resolução.
- **RFE-ADM-012** — O estado de pendência deverá atualizar após comandos que possam criá-la/resolvê-la.
- **RFE-ADM-013** — Registros de auditoria deverão permanecer acessíveis somente ao Administrador quando essa for a política do servidor.
- **RFE-ADM-014** — A tela de logs/auditoria não deverá expor payloads sensíveis sem necessidade.
- **RFE-ADM-015** — Governança de terceiros deverá preservar o módulo existente, mas integrar CSRF, confirmação de senha e authorities canônicas.
- **RFE-ADM-016** — Fornecedores, tabelas tarifárias, processos, folhas de horas, faturas e riscos deverão permanecer suportados pelos endpoints atuais.
- **RFE-ADM-017** — Mudanças de status em processos/faturas deverão exibir estados permitidos e tratar conflito do servidor.
- **RFE-ADM-018** — Folha de horas deverá suportar gerar, submeter, aprovar e rejeitar conforme perfil/estado atual.
- **RFE-ADM-019** — Faturas deverão ser geradas a partir da folha correspondente e não manualmente desvinculadas.
- **RFE-ADM-020** — Telas administrativas deverão manter trilha clara de quem pode apenas consultar e quem pode executar comandos.

## 12. Testes e critérios de qualidade

- **RFE-TST-001** — Manter e adaptar a suíte Vitest existente; não descartar testes úteis por causa da migração do contrato.
- **RFE-TST-002** — Criar testes unitários para normalização de `perfil/autoridade` sem fallback legado.
- **RFE-TST-003** — Testar máquina de estados do login: sucesso direto, 202/2FA, TOTP inválido, senha inicial obrigatória e falha de sessão.
- **RFE-TST-004** — Testar obtenção e injeção de CSRF em todos os verbos mutáveis.
- **RFE-TST-005** — Testar concorrência de obtenção de CSRF para evitar múltiplas chamadas redundantes simultâneas.
- **RFE-TST-006** — Testar fluxo de confirmação `X-User-Password`, inclusive 428, senha incorreta e repetição controlada.
- **RFE-TST-007** — Testar que senha de confirmação não é persistida nem incluída em logs.
- **RFE-TST-008** — Testar preservação de `meta` e `requestId` na normalização do envelope.
- **RFE-TST-009** — Testar paginação server-side e filtros com respostas vazias/última página.
- **RFE-TST-010** — Testar guards e menu para os seis perfis canônicos.
- **RFE-TST-011** — Testar que Presidente não visualiza emissão formal/mutações proibidas.
- **RFE-TST-012** — Testar que Gestor Nacional visualiza painel/relatórios autorizados.
- **RFE-TST-013** — Testar que Operacional não obtém botões negociais de contrato/pessoa restrita.
- **RFE-TST-014** — Testar criação integrada de vínculo com pessoa existente e nova pessoa.
- **RFE-TST-015** — Testar excesso de capacidade: sem excesso, excesso permitido, capacidade zero, recusa e conflito concorrente.
- **RFE-TST-016** — Testar prévia/confirmar alocação e precedência no último dia do vínculo.
- **RFE-TST-017** — Testar aditamento/remanejamento com prévia e conflito de ocupação.
- **RFE-TST-018** — Testar download/upload/substituição/invalidação de documentos e dados restritos com finalidade.
- **RFE-TST-019** — Testar frequência individual/lote, janela operacional, bloqueio por retificação do gestor e estados de revisão.
- **RFE-TST-020** — Testar fechamento/reprocessamento e prevenção de double-submit.
- **RFE-TST-021** — Testar relatórios paginados e exportação assíncrona até download.
- **RFE-TST-022** — Testar renderização de painel com “Todos”, filtros dinâmicos e navegação de data.
- **RFE-TST-023** — Testar tratamento padronizado de 400,401,403,404,409,413,415,428,5xx.
- **RFE-TST-024** — Testar stale responses/race conditions em filtros e buscas rápidas.
- **RFE-TST-025** — Testar acessibilidade dos fluxos principais com ferramentas automatizadas e navegação manual por teclado.
- **RFE-TST-026** — Testar responsividade mínima das telas essenciais em larguras desktop, tablet e mobile suportadas.
- **RFE-TST-027** — Testar bundle/build com Node 22 conforme baseline do projeto.
- **RFE-TST-028** — Testar ausência de Tailwind e impedir dependência futura não autorizada por checagem estática.
- **RFE-TST-029** — Testar que não há uso negocial novo de `ROLE_*`, `role/roles`, `skipTwoFactor` ou POST/PUT canônico de `/empregados`.
- **RFE-TST-030** — Executar smoke E2E integrado contra Java real para autenticação, contrato, vínculo, frequência, painel e relatório antes do Gate final.
- **RFE-TST-031** — Executar cenários de regressão dos bugs históricos de refresh/estado, 403 do operacional, painel do Gestor Nacional e filtros por escopo.
- **RFE-TST-032** — Executar teste de carga do frontend/API em consultas críticas sem tentar carregar 40 mil+ colaboradores em memória do navegador.
- **RFE-TST-033** — Medir Web Vitals/tempo de interação em páginas de maior volume e otimizar renders, memoização e consultas apenas quando medido.
- **RFE-TST-034** — Validar que nenhuma mudança no React exige alteração no Java quando o endpoint atual já satisfaz o contrato.

## 13. Build, ambientes e empacotamento

- **RFE-BLD-001** — Manter Node 22 como versão-alvo do frontend.
- **RFE-BLD-002** — Manter React 19 e Vite em versões compatíveis já resolvidas pelo projeto, evitando upgrades oportunistas durante a migração funcional.
- **RFE-BLD-003** — Conservar `npm ci`/lockfile como forma reprodutível de instalação quando o lock estiver consistente.
- **RFE-BLD-004** — Manter `.env.example` sem segredos e separar configuração por ambiente.
- **RFE-BLD-005** — A URL base da API deverá ser parametrizada e compatível com proxy de desenvolvimento e implantação junto ao backend quando adotado.
- **RFE-BLD-006** — Nenhuma regra negocial crítica deverá depender de variável `.env` do navegador.
- **RFE-BLD-007** — Build deverá falhar em erro de lint/teste crítico definido no gate, evitando publicar bundle parcialmente válido.
- **RFE-BLD-008** — Assets Correios deverão ser servidos de forma previsível sem caminhos absolutos ligados à máquina de desenvolvimento.
- **RFE-BLD-009** — Bundle deverá ser dividido/lazy-loaded nas páginas pesadas quando isso reduzir carregamento inicial sem prejudicar UX.
- **RFE-BLD-010** — Source maps de produção deverão seguir decisão de segurança/operacional do ambiente e não expor informações desnecessárias publicamente.
- **RFE-BLD-011** — O React poderá continuar sendo empacotado separadamente ou copiado para `static` do backend somente na etapa de empacotamento definida; o código deve permanecer desacoplado do Maven.
- **RFE-BLD-012** — Cada entrega de etapa deverá registrar versões de Node/npm, comandos executados e resultado dos testes.

## 14. Requisitos transversais de desempenho

- Consultas de grande volume devem ser paginadas/agregadas no servidor. O React não deve baixar dezenas de milhares de colaboradores para filtrar ou somar localmente.
- Requests duplicados disparados por renderização devem ser eliminados; efeitos React precisam ter dependências controladas.
- Buscar dados dependentes apenas após os filtros predecessores necessários estarem definidos.
- Prefetch só deve ser usado quando houver benefício mensurável e sem violar escopo.
- Cache local de catálogos poderá existir com invalidação/TTL controlados; não cachear autorização como se fosse permanente.
- Mutações devem invalidar os dados afetados e recarregar estado oficial.
- Tabelas, gráficos e modais devem evitar rerenderização integral por alteração irrelevante.
- Exportação de grande volume deve usar o mecanismo assíncrono do backend.

## 15. Requisitos de acessibilidade

- Alvo mínimo: WCAG 2.1 AA nas interações essenciais, na medida aplicável ao ambiente corporativo.
- Contraste deve permanecer adequado inclusive no azul/amarelo Correios.
- Cor nunca será o único indicador de erro, pendência, sucesso ou série gráfica.
- Modais devem conter foco, devolver foco ao fechar e responder a Escape quando a ação não for destrutiva/irreversível.
- Tabelas devem ter cabeçalhos semânticos e controles de paginação acessíveis.
- Campos inválidos devem anunciar mensagem associada.
- Loading deve possuir indicação textual/aria adequada e não causar salto de foco.

## 16. Requisitos de observabilidade e suporte

- Erros de API devem permitir visualizar/copiar `requestId` quando fornecido.
- Logging cliente deve ser enxuto e não conter senha, TOTP, CPF integral, token CSRF, cookie ou dados pessoais restritos.
- Em desenvolvimento, warnings de contrato obsoleto devem ser detectáveis por testes/checagens estáticas.
- Erros inesperados de renderização devem ter Error Boundary com opção segura de retornar/recarregar sem perder sessão indevidamente.
- Ações críticas podem registrar no cliente somente metadados não sensíveis para diagnóstico, mantendo a auditoria oficial no backend.

## 17. O que será preservado do React antigo

1. Identidade visual Correios e tokens de cores já estabelecidos.
2. React 19 + Vite e organização modular que seja compatível com a evolução.
3. CSS Modules existentes que estejam coesos.
4. Axios central, após adaptação para CSRF/envelope/erros.
5. Componentes genéricos de formulário, modal, tabela, feedback e layout que passarem pela auditoria de contrato/acessibilidade.
6. Telas de painel, frequência, relatórios e governança como base visual, mas com integração atualizada.
7. Suíte Vitest e verificações estáticas úteis.

## 18. O que deverá ser substituído ou profundamente adaptado

1. `role/roles` e qualquer autorização baseada em `ROLE_*` legado.
2. `skipTwoFactor` e qualquer possibilidade visual de ignorar 2FA.
3. Fluxo de mutação sem CSRF.
4. Interceptor que perde `meta/requestId` importantes do envelope.
5. Cadastro operacional baseado em CRUD de `/empregados` como fonte canônica.
6. Regras de negócio mantidas em `.env`/React quando o backend é autoritativo.
7. Contratos tratados como CRUD simples sem ciclo de vida, composições, documentos e temporalidade.
8. Páginas que escondem Gestor Nacional/Presidente por mapa legado de roles.
9. Cálculos de relatório/painel feitos localmente quando já há endpoint oficial.

## 19. Critério para considerar um problema como bug do Java

O backend só deverá ser candidato a alteração quando houver evidência reproduzível de pelo menos uma das situações:

- endpoint documentado e implementado retorna comportamento incompatível com os próprios requisitos/DTOs;
- regra de autorização do Spring impede um perfil que a documentação canônica autoriza;
- DTO/resposta não contém informação indispensável prometida pelo contrato;
- erro 5xx consistente para payload válido;
- inconsistência temporal/concorrente comprovada pelos testes;
- endpoint ou código de erro contradiz a documentação pós-auditoria usada como baseline.

Nesses casos, registrar um **Relatório de Bug Backend** separado. O React não deverá introduzir workaround oculto que masque o defeito.

## 20. Fora de escopo desta Etapa 01

- Nenhuma alteração de `.jsx`, `.js`, `.css`, `.module.css` ou configuração do projeto React.
- Nenhuma alteração no Java.
- Nenhum redesign visual definitivo.
- Nenhuma mudança de banco de dados.
- Nenhuma decisão de produção que pertença ao Gate B do backend (Flyway, rate limit distribuído etc.).

## 21. Gate de aceite desta documentação

A implementação só deve começar após considerar esta baseline junto com os documentos auxiliares do pacote. O primeiro código deve atacar **infraestrutura de integração e segurança antes das telas de negócio**, para não propagar o contrato legado por novas páginas.
