# Índice de Requisitos Frontend

**Total de requisitos identificados nesta baseline:** 323 requisitos numerados, além dos requisitos transversais textuais.

| Família | Quantidade |
|---|---:|
| RFE-ARC | 18 |
| RFE-SEC | 30 |
| RFE-AUT | 20 |
| RFE-HTTP | 25 |
| RFE-UX | 20 |
| RFE-CON | 40 |
| RFE-VIN | 34 |
| RFE-FRE | 25 |
| RFE-PAI | 20 |
| RFE-REL | 25 |
| RFE-ADM | 20 |
| RFE-TST | 34 |
| RFE-BLD | 12 |
