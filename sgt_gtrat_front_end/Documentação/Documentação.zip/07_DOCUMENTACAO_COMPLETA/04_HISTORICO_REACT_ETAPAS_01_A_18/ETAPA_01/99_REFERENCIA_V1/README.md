# SGT/GTRAT — Documentação React — Etapa 01

Data: 11/09/2026

Esta entrega contém **somente documentação e inventário**, sem alteração de código React ou Java.

## Ordem de leitura

1. `01_LEVANTAMENTO_REQUISITOS/SGT_GTRAT_REACT_LEVANTAMENTO_REQUISITOS_IMPLEMENTACAO_V1.md`
2. `02_CONTRATO_INTEGRACAO/SGT_GTRAT_REACT_CONTRATO_INTEGRACAO_JAVA_V1.md`
3. `03_MATRIZ_GAPS/SGT_GTRAT_REACT_MATRIZ_GAPS_V1.md`
4. `04_PLANO_IMPLEMENTACAO/SGT_GTRAT_REACT_PLANO_IMPLEMENTACAO_13_ETAPAS_V1.md`
5. `05_INVENTARIOS/SGT_GTRAT_JAVA_ENDPOINTS_INVENTARIO.csv`
6. `05_INVENTARIOS/SGT_GTRAT_REACT_ATUAL_INVENTARIO.md`

## Decisão principal

O Java atual é tratado como contrato de integração. O React antigo será evoluído preservando o design Correios e componentes úteis, mas migrando segurança, autenticação, perfis e domínio negocial para o contrato pós-auditoria.

## Etapas

Total recomendado: **13 etapas**, sendo a Etapa 01 esta documentação e **12 etapas restantes de implementação/validação**.
