# Governança da Especificação React V2

## Fontes consideradas

- documentação funcional consolidada do Java;
- contrato pós-auditoria específico para React;
- 44 controladores REST e assinaturas dos DTOs;
- `ConfiguracaoSeguranca` e `@PreAuthorize`/`@ExigirSenha`;
- React antigo: rotas, serviços, core HTTP/security, CSS Modules, configuração e testes.

## Regra de atualização

Ao alterar o Java no futuro, gerar novo inventário e comparar com `SGT_GTRAT_API_ENDPOINTS_DETALHADO_V2.csv`. Endpoint novo/removido/alterado deve provocar atualização da rastreabilidade e do serviço React afetado.

## Status sugeridos

`NÃO_INICIADO`, `EM_IMPLEMENTACAO`, `IMPLEMENTADO`, `VALIDADO_MOCK`, `VALIDADO_JAVA`, `BLOQUEADO_BUG_JAVA`, `NÃO_CONSUMIR_JUSTIFICADO`.

## Definição de pronto de um requisito

Um requisito só é `VALIDADO_JAVA` quando a UI/serviço correspondente foi exercitada contra a API Java atual com perfil/escopo adequados e o teste/evidência foi registrado. Teste mockado sozinho não conclui aderência de integração.
