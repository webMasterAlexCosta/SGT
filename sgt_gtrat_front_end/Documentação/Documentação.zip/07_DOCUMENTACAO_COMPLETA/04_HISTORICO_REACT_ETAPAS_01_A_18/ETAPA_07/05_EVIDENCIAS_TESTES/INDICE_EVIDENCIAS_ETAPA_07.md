# Índice de evidências — Etapa 07

- `*.log` e `*.exit`: execução final dos gates;
- `vitest-junit.xml`: unitários;
- `componentes-junit.xml`: componentes;
- `camada2-comportamento-junit.xml`: Camada 2;
- `camada3-robustez-junit.xml`: Camada 3;
- `resultados-react.json`: resultado integrado React × Java;
- `qualidade-react.*`: análise estática;
- `bundle-performance.*`: budget de bundle;
- `relatorio-testes-react.pdf`: relatório produzido pela suíte existente.

Todos os gates exceto integridade retornaram código 0. Integridade retorna 1 por uma única divergência XLSX preexistente, detalhada em `TESTES_ETAPA_07.md`.
