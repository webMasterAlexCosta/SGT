# Próxima etapa — Etapa 08

## Contratos — núcleo e ciclo de vida

A Etapa 08 **não foi iniciada** nesta entrega.

Objetivo documental: transformar a tela de contratos de CRUD simples em representação do ciclo de vida temporal do domínio.

Escopo previsto: **16 endpoints de `ContratoControlador`**.

Principais frentes:

- lista/resumo e detalhe contratual;
- rascunho, criação, edição e publicação;
- timeline de eventos, precedências, versões e posição temporal;
- inativação/reativação;
- encerramento antecipado, cancelamento futuro e anulação;
- descarte físico apenas de rascunho elegível;
- separação entre data efetiva, data do ato e data de registro;
- leitura nacional de Presidente/Gestor Nacional e escrita apenas pelos perfis autorizados;
- testes de rascunho, publicação, bloqueios pós-publicação, eventos temporais e matriz de perfis.

Gate previsto: **ciclo de vida contratual completo e rastreável**.
