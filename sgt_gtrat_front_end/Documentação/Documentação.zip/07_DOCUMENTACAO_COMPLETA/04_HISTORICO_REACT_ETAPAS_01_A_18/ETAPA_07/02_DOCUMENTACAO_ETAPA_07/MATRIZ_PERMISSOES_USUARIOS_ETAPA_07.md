# Matriz de permissões — Etapa 07

| Área | Administrador | Gestor Nacional | Gestor Estadual | Gestor Local | Presidente | Operacional |
|---|---|---|---|---|---|---|
| Configurações do sistema | editar | não | não | não | não | não |
| Meu Perfil / 2FA / avatar | próprio | próprio | próprio | próprio | próprio | próprio |
| Listar/administrar usuários | conforme serviço | conforme serviço | próprio escopo estadual | própria Gestão Local | não | não |
| Criar usuário | perfis permitidos pelo Java | Gestor Estadual | Gestor Local do escopo | Operacional local | não | não |
| Alterar própria conta via admin | sem troca de perfil | sem troca de perfil | sem troca de perfil | sem troca de perfil | n/a | n/a |
| Redefinir própria senha pela administração | não | não | não | não | n/a | n/a |

A tabela resume a experiência React. O backend continua decidindo cada operação e pode responder 403 quando o alvo não pertence ao escopo.
