# Alterações — Etapa 07

## Escopo

Etapa 07 — **Usuários, perfil e configurações administrativas**. A baseline é a Etapa 06 entregue. O backend Java não foi alterado.

## Implementado

1. **Configurações administrativas do sistema**
   - nova rota/tela administrativa exclusiva do `PERFIL_ADMINISTRADOR`;
   - leitura por `GET /api/sistema/configuracoes`;
   - gravação por `POST /api/sistema/configuracoes`;
   - somente `HORAS_DIA_TRABALHO`, `HORA_INICIO_NOTURNO` e `MINUTOS_HORA_NOTURNA` são editáveis, pois são as três chaves aceitas pelo serviço Java atual;
   - releitura canônica após salvar;
   - nenhuma configuração administrativa é armazenada em `localStorage` ou `sessionStorage`.

2. **Gestão de usuários**
   - autoridade/capacidades canônicas para Administrador, Gestor Nacional, Gestor Estadual e Gestor Local;
   - busca, filtro de perfil, filtro de status e paginação local sobre a `List` retornada pelo endpoint atual;
   - matrícula obrigatória no formulário administrativo;
   - criação, edição, ativação, inativação, redefinição de senha e acesso retroativo preservam a confirmação central por 428/`@ExigirSenha`;
   - edição da própria conta não oferece alteração de perfil, conforme regra do Java;
   - após editar a própria conta, perfil e sessão são reconsultados para recalcular o shell/menu;
   - tabela exibe matrícula, bloqueio e validade de acesso retroativo quando fornecidos pelo backend.

3. **Perfil, senha, 2FA e avatar**
   - `ServicoPerfil.validarSenha` alinhado a `/api/perfil/validar-senha`;
   - os 8 endpoints do `PerfilControlador` foram inventariados/testados;
   - referência de UX para senha centralizada em `SENHA_MINIMA_UI=8` e `SENHA_MAXIMA_UI=72`, sem substituir a validação autoritativa do Java;
   - avatar permanece multipart (`file`) e com cache invalidável;
   - fluxo 2FA permanece sem persistência de segredo em Web Storage.

4. **Shell/rotas**
   - rota `configuracoes-sistema` lazy;
   - menu mostra a configuração administrativa apenas quando a capacidade canônica permite;
   - nenhum `ROLE_*`/`skipTwoFactor` foi reintroduzido.

## Arquivos

A comparação `diff -qr` Etapa 06 × Etapa 07 registra 17 diferenças de caminho (18 arquivos efetivamente adicionados/alterados, pois uma pasta nova contém dois arquivos). Consulte `INVENTARIO_ARQUIVOS_ALTERADOS_ETAPA_07.txt` e o patch completo.
