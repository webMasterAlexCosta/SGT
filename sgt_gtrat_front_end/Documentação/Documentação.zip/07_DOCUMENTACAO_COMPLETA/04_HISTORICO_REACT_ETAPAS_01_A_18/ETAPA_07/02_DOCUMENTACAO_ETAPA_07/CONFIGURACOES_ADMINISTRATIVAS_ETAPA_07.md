# Configurações administrativas — Etapa 07

## Chaves editáveis confirmadas no Java

| Chave | Regra de formato usada na UI | Autoridade final |
|---|---|---|
| `HORAS_DIA_TRABALHO` | inteiro 1..24 | serviço Java |
| `HORA_INICIO_NOTURNO` | hora válida `HH:mm` | serviço Java |
| `MINUTOS_HORA_NOTURNA` | >0 e <=60 | serviço Java |

Outras chaves eventualmente retornadas pela API não são automaticamente transformadas em campos editáveis. Isso evita oferecer uma mutação que o serviço Java rejeita.

Após cada POST bem-sucedido, o React executa nova leitura da API. Web Storage não é usado como fonte de verdade.
