# Dependências — Etapa 07

- `package.json`: inalterado em relação à Etapa 06.
- `package-lock.json`: inalterado em relação à Etapa 06.
- `.node-version`: inalterado em relação à Etapa 06.
- `.nvmrc`: inalterado em relação à Etapa 06.
