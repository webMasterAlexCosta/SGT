# Pendências e riscos — Etapa 07

1. **XLSX de frequência no Java — preexistente**
   - o gate integrado permanece 284/285;
   - a única falha não pertence à Etapa 07;
   - o backend não foi modificado para mascarar o teste.

2. **Política de senha por ambiente**
   - `8` é apenas referência de UX observada no Java de desenvolvimento atual;
   - qualquer mudança da política no backend continua sendo validada pelo servidor;
   - uma evolução futura pode expor política pública/canônica se o Java fornecer contrato para isso.

3. **GET /api/usuarios retorna List**
   - filtros/paginação da Etapa 07 são locais sobre a lista recebida;
   - se a volumetria crescer, o ideal é endpoint paginado/filtrado no Java em vez de mover autoridade de escopo para o cliente.

4. **Chunk vendor-face**
   - há aviso de tamanho, mas não quebra o budget atual;
   - pode ser otimizado em etapa de performance sem bloquear a Etapa 07.

5. **Regra especial de ativação de Operacional**
   - o Java impõe condição mais restritiva do que a capacidade genérica do matcher;
   - o frontend não tenta reproduzir toda a regra como autorização; 403 permanece final.
