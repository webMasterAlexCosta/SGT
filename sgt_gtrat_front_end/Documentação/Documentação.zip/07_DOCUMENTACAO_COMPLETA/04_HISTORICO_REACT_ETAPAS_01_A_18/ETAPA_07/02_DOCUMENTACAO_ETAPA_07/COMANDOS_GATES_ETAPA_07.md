# Comandos dos gates — Etapa 07

Executados com Node 22.16.0 e npm 10.9.2:

```bash
npm run validate:runtime
npm run validar:nomenclatura
npm run test:configuracao
npx vitest run --config vitest.config.js test/vitest/usuariosPerfilConfiguracoesEtapa07.test.js --coverage.enabled=false
npm test
npm run test:componentes
npm run test:camada2
npm run test:camada3:vitest
npm run test:qualidade:estatica
npm run test:bundle
npm run test:segredos:bundle
SGT_BACKEND_DIR=/mnt/data/java_etapa06/sgt_gtrat_back_end npm run test:integridade
```

Os códigos de saída e logs correspondentes estão em `05_EVIDENCIAS_TESTES/`. O gate integrado retorna 1 pela única divergência XLSX documentada; todos os demais gates retornam 0.
