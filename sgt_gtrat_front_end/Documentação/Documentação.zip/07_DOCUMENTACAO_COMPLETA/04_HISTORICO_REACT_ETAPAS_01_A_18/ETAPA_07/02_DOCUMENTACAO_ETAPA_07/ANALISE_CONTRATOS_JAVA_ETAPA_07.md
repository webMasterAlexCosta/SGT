# Análise dos contratos Java — Etapa 07

## Configuração do sistema

`ConfiguracaoSistemaControlador` expõe 2 endpoints e exige Administrador. Embora a leitura possa retornar outras chaves, o serviço Java atual só permite gravar:

- `HORAS_DIA_TRABALHO`: inteiro entre 1 e 24;
- `HORA_INICIO_NOTURNO`: `HH:mm` válido;
- `MINUTOS_HORA_NOTURNA`: valor finito maior que 0 e menor ou igual a 60.

`HORA_FIM_NOTURNO` pode existir nos dados/seeds, mas não é uma chave gravável no serviço atual; portanto o React não inventa edição dela.

## Perfil

Foram conferidos os 8 endpoints de 2FA, senha e avatar. O React mantém os DTOs/nomes multipart do Java e releitura do estado canônico após comandos sensíveis.

## Usuários

A segurança HTTP de `/api/usuarios/**` permite os quatro perfis gerenciais: Administrador, Gestor Nacional, Gestor Estadual e Gestor Local. O serviço restringe o alvo pelo escopo/hierarquia:

- Administrador pode criar perfis permitidos pelo serviço;
- Gestor Nacional cria/administra Gestor Estadual dentro do contrato atual;
- Gestor Estadual cria/administra Gestor Local dentro da própria Superintendência/escopo;
- Gestor Local cria/administra Operacional da própria Gestão Local;
- Presidente não administra `/usuarios/**`;
- ativação de Operacional inativo possui regra específica no serviço: somente o Gestor Local correspondente pode efetivá-la;
- redefinição administrativa de senha não é usada para a própria conta;
- alterações sensíveis do usuário-alvo revogam/inutilizam sessões conforme o backend.

A UI usa capacidade para experiência, mas 403 do Java continua sendo a autoridade final.

## Política de senha

O ambiente Java de referência desta validação usa `AUTH_PASSWORD_MIN_LENGTH=8`. O React usa 8 apenas como orientação de UX para reduzir submissões obviamente inválidas e declara explicitamente que o servidor é a autoridade final. Não foi criada regra de negócio local para substituir configuração futura do backend.
