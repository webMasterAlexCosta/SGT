# Testes — Etapa 07

## Resultado final

| Gate | Resultado |
|---|---:|
| Runtime | Node 22.16.0 / npm 10.9.2 — aprovado |
| Nomenclatura | 225 arquivos — aprovado |
| Configuração | 16/16 |
| Focal Etapa 07 | 9/9 |
| Unitários | 73/73 |
| Componentes | 344/344 |
| Camada 2 | 583/583 |
| Camada 3 | 474/474 |
| Qualidade estática | 225 arquivos, 0 erros de gate, 1 aviso |
| Bundle/budget | aprovado |
| Segredos no bundle | aprovado |
| Integridade React × Java | 284/285 |

## Única falha integrada

`exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão`

Esta divergência já existia antes da Etapa 07 e aponta para o Java de relatórios/frequência (`XlsxStreamingWriter`/serviço de exportação), fora do escopo de usuários/perfil/configurações. Os 7 novos testes integrados da Etapa 07 passaram.

## Observações

- O `stderr` do teste de absenteísmo simula propositalmente indisponibilidade de resumo e o teste passa preservando a tabela.
- Avisos `HTMLFormElement.requestSubmit()` das suítes de componente/comportamento são limitação conhecida do JSDOM e não produziram falhas.
- `vendor-face` permanece como chunk grande (~1,31 MB), porém abaixo dos limites de gate definidos pelo projeto; o budget foi aprovado.
