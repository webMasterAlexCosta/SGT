# SGT/GTRAT React — Etapa 07

Entrega fechada da **Etapa 07 — Usuários, perfil e configurações administrativas**.

## Pastas

- `01_REACT_ETAPA_07`: fonte final desta etapa;
- `02_DOCUMENTACAO_ETAPA_07`: alterações, contratos, matrizes, rastreabilidade, diff e hashes;
- `03_DOCUMENTACAO_ORIGINAL`: documentação original das 18 etapas, preservada sem alteração;
- `04_REACT_ETAPA_06_REFERENCIA`: baseline imediatamente anterior;
- `05_EVIDENCIAS_TESTES`: logs e relatórios dos gates finais;
- `06_ENTRADAS_ORIGINAIS`: React antigo e planejamento original enviados no início.

## Estado

- 19/19 endpoints da Etapa 07 inventariados e integrados/validados;
- Java inalterado;
- 284/285 no gate integrado, com a única falha XLSX de frequência preexistente;
- Etapa 08 não iniciada.

O fonte não inclui `node_modules`, `dist`, `reports` nem `.git`.
