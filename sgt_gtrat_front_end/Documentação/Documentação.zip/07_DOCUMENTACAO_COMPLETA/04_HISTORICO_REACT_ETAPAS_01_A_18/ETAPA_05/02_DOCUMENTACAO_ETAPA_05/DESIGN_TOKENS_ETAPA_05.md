# Design tokens — Etapa 05

`src/styles/tokens.css` passa a ser a fonte comum para:

- azul/amarelo Correios e escala de neutros;
- sucesso, atenção, perigo, informação, pendência, bloqueio e rascunho;
- superfícies, bordas e texto;
- tipografia e pesos;
- escala de espaçamento;
- raios;
- sombras;
- z-index do shell, tooltip, modal e toast;
- largura da barra lateral, limite de conteúdo, altura do cabeçalho e breakpoints;
- transições.

Aliases do React legado foram mantidos temporariamente **como variáveis**, não como classes utilitárias, para evitar regressão visual durante a migração das etapas de domínio.
