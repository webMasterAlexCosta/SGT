# Próxima etapa — Etapa 06

## Estrutura organizacional e catálogos

Objetivo: realinhar filtros e cadastros mestres ao escopo/permissões e à validade temporal do Java.

Escopo previsto pela documentação original:

- **53 endpoints**;
- Superintendências e Gestões Locais por escopo;
- visão da estrutura por região;
- Lotação, Jornada/Turno, Cargo, Tipo de Contratação, Regra Adicional, Banco, Agência, Tipo de Conta, Status e motivos;
- leitura histórica versus opção válida para nova operação;
- ativação/inativação/reativação;
- escrita por capacidade;
- selects dependentes;
- paginação/filtros e erros de vínculo/programação futura.

A Etapa 06 **não foi iniciada** dentro do ZIP da Etapa 05.
