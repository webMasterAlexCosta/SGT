# Testes — Etapa 05

| Gate | Resultado final |
|---|---|
| Runtime | Node 22.16.0 / npm 10.9.2 — aprovado |
| Nomenclatura | 221 arquivos — aprovado |
| Configuração | 16/16 |
| Focais Etapa 05 | 9/9 |
| Unitários completos | 56/56 |
| Componentes | 342/342 |
| Camada 2 / comportamento | 580/580 |
| Camada 3 / robustez | 467/467 |
| Qualidade estática | 221 arquivos, 0 erros de gate, 1 aviso |
| Bundle budget | aprovado |
| Segredos no bundle | aprovado |
| Integridade React × Java | 277/278; 1 divergência XLSX do Java |
| Preview HTTP | respondeu normalmente ao `curl` durante tentativa de smoke |
| Chromium headless | **não concluído por limitação DBus/zygote do executor** |

## Observações

O aviso de qualidade é não impeditivo. O Vite também avisa que `vendor-face` permanece acima de 1 MB minificado; o gate de orçamento configurado pelo projeto aprova o bundle e o pacote pesado já está separado do chunk principal. A etapa registra o aviso para otimização posterior em vez de alterar dependência sem necessidade.

Os logs e exit codes estão em `05_EVIDENCIAS_TESTES/`.
