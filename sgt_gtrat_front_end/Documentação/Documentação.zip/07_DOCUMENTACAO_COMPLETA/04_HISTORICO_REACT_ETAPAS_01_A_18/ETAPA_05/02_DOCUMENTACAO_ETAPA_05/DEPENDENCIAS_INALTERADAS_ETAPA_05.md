# Dependências — Etapa 05

Nenhuma dependência foi adicionada, removida ou atualizada.

Os hashes de `package.json` e `package-lock.json` são idênticos aos da baseline Etapa 04. A implementação usa somente React/CSS Modules e recursos já presentes no projeto.

Não foi introduzido Tailwind.
