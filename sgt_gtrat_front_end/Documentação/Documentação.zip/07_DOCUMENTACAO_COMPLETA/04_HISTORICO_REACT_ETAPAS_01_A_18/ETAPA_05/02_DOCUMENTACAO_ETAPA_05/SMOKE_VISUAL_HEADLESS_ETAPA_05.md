# Smoke visual headless — Etapa 05

## Tentativa 1

Chromium 144, `--headless=new --no-sandbox --disable-gpu --disable-dev-shm-usage`.

Resultado: timeout. Log registra repetidas falhas DBus e, no encerramento, erro de comunicação com zygote. Nenhum screenshot foi produzido.

## Tentativa 2

Foi testado modo alternativo com `--no-zygote --single-process`, além de desabilitar operações de rede em background.

Resultado: timeout (exit 124), com avisos de proxy resolver em single-process e as mesmas limitações DBus.

## Decisão

Não marcar smoke como aprovado. O preview HTTP respondeu ao `curl`, o build foi aprovado e os testes de acessibilidade/teclado são determinísticos. A inspeção visual real deve ser repetida em um CI/desktop com Chromium funcional.
