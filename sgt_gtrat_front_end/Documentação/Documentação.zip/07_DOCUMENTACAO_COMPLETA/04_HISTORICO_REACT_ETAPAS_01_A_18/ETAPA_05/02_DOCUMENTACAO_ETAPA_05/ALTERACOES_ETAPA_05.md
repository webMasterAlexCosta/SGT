# Alterações — Etapa 05

## Objetivo executado

Consolidar o shell comum do React para que as próximas etapas não reinventem estrutura visual, acessibilidade, navegação, estados de página e tratamento de falhas, mantendo o padrão Correios e **React + CSS Modules sem Tailwind**.

## Alterações implementadas

### 1. Tokens e CSS global

- criado `src/styles/tokens.css` com cores Correios, neutros, estados semânticos, tipografia, espaçamento, raios, sombras, z-index, limites do shell e transições;
- `src/index.css` foi reduzido ao que é realmente global: reset, foco, seleção, scrollbar, classe somente-leitor-de-tela e preferência de movimento reduzido;
- removidas as últimas utilidades globais com aparência Tailwind (`flex`, `mr-1`, `animate-spin`, etc.); os usos residuais foram migrados para seus CSS Modules;
- removido `src/modules/auth/themeConfig.jsx`, arquivo morto que continha apenas strings de classes estilo Tailwind e não era usado pela aplicação;
- nenhuma dependência Tailwind foi adicionada.

### 2. Shell de página reutilizável

Foram criados `EstruturaPagina` e `EstadoPagina`, com padrão para:

- título/subtítulo;
- ações;
- filtros;
- quantidade de filtros ativos e limpeza;
- loading;
- vazio;
- erro recuperável;
- conteúdo.

A adoção em todas as telas de domínio será feita quando cada módulo for evoluído nas etapas 06–18, evitando uma refatoração horizontal arriscada antes do contrato de cada domínio.

### 3. Acessibilidade de diálogos

Criado `useDialogoAcessivel`, com:

- aprisionamento de foco com `Tab`/`Shift+Tab`;
- foco inicial determinístico;
- restauração do foco anterior;
- fechamento por `Esc` quando seguro;
- bloqueio de fechamento durante ação crítica;
- bloqueio de scroll do `body` sem classe global legada.

O padrão foi aplicado aos modais centrais e também ao modal de contratos.

### 4. Confirmação crítica e stepper

- `ModalConfirmacao` passou a usar `alertdialog`, título/descrição associados, `aria-busy` e bloqueio de saída enquanto a confirmação assíncrona está em andamento;
- criado `FluxoEtapas` para prévia → confirmação → resultado, com `aria-current="step"`;
- ações críticas exibem texto explícito e não dependem de um genérico “OK”.

### 5. Navegação desktop/mobile

- sidebar e header continuam usando a mesma matriz de capacidades canônicas da Etapa 04;
- botão mobile expõe `aria-expanded` e `aria-controls`;
- menu mobile possui fechamento explícito, suporte a `Esc`, foco inicial e `inert` quando oculto;
- overlay mobile passou a ser controle semântico clicável;
- retorno ao desktop fecha automaticamente o estado de menu mobile;
- tooltips do shell deixaram de depender de utilitários globais.

### 6. Error Boundary e suporte

`FronteiraErro` agora:

- usa `requestId` do backend quando disponível;
- gera ID local `ui_*` quando a falha é exclusivamente de interface;
- oferece cópia do identificador;
- mantém mensagem principal não técnica;
- expõe stack apenas em desenvolvimento;
- permite tentar renderizar novamente ou recarregar a aplicação.

### 7. Lazy loading

`AtualizacaoModulo` deixou de fazer parte do shell inicial e passou a ser carregado por `React.lazy`. O build comprova chunk separado `AtualizacaoModulo-*`.

### 8. Persistência e avatar

Foi removido um side effect residual de `ServicoPerfil.enviarAvatar` que gravava `sgt_foto_url` diretamente no `localStorage`. O serviço HTTP agora apenas executa a operação; cache/persistência da foto fica na camada de perfil/contexto com chave derivada de `APP_NAME`.

### 9. Limpeza localizada de CSS legado

As poucas ocorrências restantes de classes utilitárias foram migradas para CSS Modules nos módulos de frequência, turnos, empregados e ocorrências. Não houve redesenho funcional desses módulos; a alteração é de higiene visual/arquitetural.

## O que não foi feito nesta etapa

- nenhum endpoint Java foi modificado;
- nenhuma regra de negócio foi transferida para o React;
- os domínios das Etapas 06–18 não foram reescritos prematuramente;
- a divergência XLSX do backend não foi mascarada;
- o smoke Chromium não foi marcado como aprovado, pois o navegador não conclui neste executor.
