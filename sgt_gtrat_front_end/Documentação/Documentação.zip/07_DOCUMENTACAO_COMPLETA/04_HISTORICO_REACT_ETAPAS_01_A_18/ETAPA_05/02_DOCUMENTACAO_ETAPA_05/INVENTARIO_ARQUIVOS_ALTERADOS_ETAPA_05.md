# Inventário de arquivos alterados — Etapa 05

O comparativo `Etapa 04 entregue × Etapa 05 final` contém **42 diferenças de caminho** (`diff -qr`, excluindo `node_modules`, `dist` e `reports`).

## Diferenças

- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Aplicacao.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Aplicacao.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Aplicacao.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Aplicacao.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Leiaute/BarraLateral/components/ItemNavegacao.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Leiaute/BarraLateral/components/ItemNavegacao.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Leiaute/BarraLateral/index.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Leiaute/BarraLateral/index.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Leiaute/BarraLateral/index.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Leiaute/BarraLateral/index.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Leiaute/Cabecalho/index.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Leiaute/Cabecalho/index.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Leiaute/Cabecalho/index.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Leiaute/Cabecalho/index.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Leiaute/Rodape/components/LinksRodape.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Leiaute/Rodape/components/LinksRodape.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Leiaute/Rodape/components/StatusServidor.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Leiaute/Rodape/components/StatusServidor.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/Leiaute/Rodape/index.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/Leiaute/Rodape/index.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/core/ui/Aviso.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui/Aviso.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/core/ui/EnvolucroDica.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui/EnvolucroDica.jsx differ`
- `Only in /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui: EstruturaPagina.jsx`
- `Only in /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui: EstruturaPagina.module.css`
- `Only in /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui: FluxoEtapas.jsx`
- `Only in /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui: FluxoEtapas.module.css`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/core/ui/FronteiraErro.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui/FronteiraErro.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/core/ui/FronteiraErro.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui/FronteiraErro.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/core/ui/ModalConfirmacao.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui/ModalConfirmacao.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/core/ui/ModalConfirmacao.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui/ModalConfirmacao.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/core/ui/UI.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui/UI.module.css differ`
- `Only in /mnt/data/etapa05_work/sgt_gtrat_front_end/src/core/ui: acessibilidadeDialogo.js`
- `Only in /mnt/data/etapa05_work/sgt_gtrat_front_end/src/hooks: useConsultaMidia.js`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/index.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/index.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/main.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/main.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/admin/pages/PaginaContratos/components/ModalContrato/index.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/admin/pages/PaginaContratos/components/ModalContrato/index.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/admin/pages/PaginaTurnos/components/CartaoDeTurno/index.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/admin/pages/PaginaTurnos/components/CartaoDeTurno/index.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/admin/pages/PaginaTurnos/components/CartaoDeTurno/index.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/admin/pages/PaginaTurnos/components/CartaoDeTurno/index.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/admin/pages/PaginaTurnos/components/ModalDeTurno/index.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/admin/pages/PaginaTurnos/components/ModalDeTurno/index.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/admin/pages/PaginaTurnos/components/ModalDeTurno/index.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/admin/pages/PaginaTurnos/components/ModalDeTurno/index.module.css differ`
- `Only in /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/auth: themeConfig.jsx`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/rh/pages/EmpregadosLista/components/FormularioEmpregado/index.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/rh/pages/EmpregadosLista/components/FormularioEmpregado/index.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/rh/pages/EmpregadosLista/components/FormularioEmpregado/index.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/rh/pages/EmpregadosLista/components/FormularioEmpregado/index.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/rh/pages/PaginaFrequencia/components/CabecalhoFrequencia.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/rh/pages/PaginaFrequencia/components/CabecalhoFrequencia.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/rh/pages/PaginaFrequencia/components/TabelaFrequencia.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/rh/pages/PaginaFrequencia/components/TabelaFrequencia.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/rh/pages/PaginaFrequencia/index.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/rh/pages/PaginaFrequencia/index.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/rh/pages/PaginaOcorrencias/index.jsx and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/rh/pages/PaginaOcorrencias/index.jsx differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/modules/rh/pages/PaginaOcorrencias/index.module.css and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/modules/rh/pages/PaginaOcorrencias/index.module.css differ`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/src/services/perfil/ServicoPerfil.js and /mnt/data/etapa05_work/sgt_gtrat_front_end/src/services/perfil/ServicoPerfil.js differ`
- `Only in /mnt/data/etapa05_work/sgt_gtrat_front_end/src: styles`
- `Only in /mnt/data/etapa05_work/sgt_gtrat_front_end/test/vitest: shellEtapa05.test.jsx`
- `Files /mnt/data/etapa05_work/SGT_GTRAT_REACT_ETAPA_04/01_REACT_ETAPA_04/sgt_gtrat_front_end/test/vitest-componentes/fixtures/componentesManifest.js and /mnt/data/etapa05_work/sgt_gtrat_front_end/test/vitest-componentes/fixtures/componentesManifest.js differ`
