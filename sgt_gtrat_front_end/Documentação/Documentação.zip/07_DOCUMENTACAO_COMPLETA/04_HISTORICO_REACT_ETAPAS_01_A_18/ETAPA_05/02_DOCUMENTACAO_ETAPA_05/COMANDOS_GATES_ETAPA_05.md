# Comandos de gates — Etapa 05

```bash
npm ci --offline --cache <cache-offline> --no-audit --fund=false
npm run validate:runtime
npm run validar:nomenclatura
npm run test:configuracao
npm run test
npm run test:componentes
npm run test:camada2
npm run test:camada3:vitest
npm run test:qualidade:estatica
npm run test:bundle
npm run test:segredos:bundle
SGT_BACKEND_DIR=<JAVA atual> npm run test:integridade
```

Os gates de Camada 2 e Camada 3 foram executados separadamente para não confundir timeout do executor com falha do React.
