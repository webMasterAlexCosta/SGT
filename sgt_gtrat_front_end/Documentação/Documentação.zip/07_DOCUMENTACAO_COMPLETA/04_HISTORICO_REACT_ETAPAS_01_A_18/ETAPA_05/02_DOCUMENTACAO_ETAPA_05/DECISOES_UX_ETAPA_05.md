# Decisões de UX/arquitetura — Etapa 05

1. **CSS Modules é o padrão.** CSS global fica restrito a tokens, reset e regras realmente globais.
2. **Sem Tailwind.** Não foi adicionada dependência Tailwind e as últimas strings/utilidades herdadas foram removidas/migradas.
3. **Não refatorar todos os domínios de uma vez.** Os novos componentes são a fundação; cada página será migrada quando seu contrato Java for tratado.
4. **Capacidades continuam sendo a fonte de navegação.** Desktop e mobile usam a mesma decisão de autorização da Etapa 04.
5. **Falha técnica não deve dominar a mensagem ao usuário.** requestId fica copiável em área de suporte; stack é DEV-only.
6. **Modal crítico não fecha durante envio.** O estado assíncrono governa Escape, overlay e botões.
7. **Stepper em vez de pilha de modais** para fluxos de prévia/confirmação/resultado.
8. **Serviço HTTP não controla preferência visual/localStorage.** O cache de avatar fica fora do serviço de transporte.
9. **Smoke não é “aprovado por timeout”.** Limitação do Chromium é documentada como tal.
