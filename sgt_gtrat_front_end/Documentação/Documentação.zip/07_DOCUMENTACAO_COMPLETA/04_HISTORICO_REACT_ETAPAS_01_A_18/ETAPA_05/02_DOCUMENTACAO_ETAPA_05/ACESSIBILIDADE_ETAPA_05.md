# Acessibilidade — Etapa 05

## Implementado e automatizado

- foco visível global;
- `prefers-reduced-motion` respeitado;
- foco preso em diálogos;
- restauração do foco anterior;
- Escape somente quando seguro;
- `aria-labelledby`, `aria-describedby`, `aria-busy` em diálogos centrais;
- `alertdialog` para confirmação crítica;
- `aria-current="step"` no stepper;
- `aria-expanded`/`aria-controls` no menu mobile;
- menu oculto com `inert` no modo mobile;
- overlay de navegação como controle semântico;
- requestId/ID de suporte copiável;
- HTML não possui `user-scalable=no` nem `maximum-scale=1`, portanto o navegador não bloqueia zoom 200%;
- testes de teclado em JSDOM.

## Limitação

A validação visual real a 200% e screenshots desktop/mobile não pôde ser concluída porque o Chromium headless do executor trava por DBus/zygote. Ver `SMOKE_VISUAL_HEADLESS_ETAPA_05.md` e logs brutos.
