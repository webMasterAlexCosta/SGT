# Pendências e riscos — Etapa 05

## 1. Smoke visual headless

**Situação:** limitação de ambiente.

Chromium 144 não concluiu a captura headless. Os logs apresentam falha de conexão DBus e erro de comunicação com zygote. Uma segunda tentativa com `--no-zygote --single-process` também expirou.

**Tratamento:** não classificado como sucesso. Manter smoke visual real para homologação/CI com navegador funcional. Há cobertura determinística de teclado, foco, semântica e zoom não bloqueado nos testes da etapa.

## 2. `vendor-face` grande

O build possui chunk `vendor-face` de aproximadamente 1,31 MB minificado. O orçamento interno do projeto passa, e o chunk está separado do shell principal, mas continua candidato a otimização na etapa de performance/bundle.

## 3. Adoção dos novos padrões por domínio

`EstruturaPagina`, `EstadoPagina`, `FluxoEtapas` e o padrão de diálogo estão prontos. Não foi feita migração horizontal de todas as páginas para evitar regressão em módulos cujo contrato será alterado nas Etapas 06–18. A rastreabilidade marca esses requisitos como base atendida ou adoção pendente por domínio.

## 4. Divergência XLSX no Java

A integridade permanece 277/278 pela exportação XLSX de frequência no backend. É dívida já existente e não pertence à Etapa 05.
