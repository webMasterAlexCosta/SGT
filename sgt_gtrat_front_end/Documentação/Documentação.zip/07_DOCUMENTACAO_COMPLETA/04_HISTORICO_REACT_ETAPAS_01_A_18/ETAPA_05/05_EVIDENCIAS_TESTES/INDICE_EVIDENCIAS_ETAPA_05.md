# Índice de evidências — Etapa 05

Use preferencialmente os arquivos com sufixo `_final` quando houver uma execução intermediária e outra final.

- `validate_runtime.log` — runtime Node/npm e configuração;
- `validar_nomenclatura.log` — gate de nomenclatura;
- `test_configuracao.log` — 16 testes de configuração;
- `test_unitarios_final.log` — 56/56 unitários;
- `test_componentes.log` — 342/342 componentes;
- `test_camada2.log` — 580/580 comportamento;
- `test_camada3.log` — 467/467 robustez;
- `qualidade_estatica_final.log` — 0 erros de gate;
- `bundle_final.log` — build + orçamento;
- `segredos_bundle_final.log` — fail-closed de segredos;
- `integridade_java_final.log` — 277/278, única falha XLSX backend;
- `smoke/` — tentativas Chromium headless e limitação do executor;
- `09_resultados_integridade.json` e `09_relatorio_integridade.pdf` — relatório integrado gerado pelo próprio projeto.
