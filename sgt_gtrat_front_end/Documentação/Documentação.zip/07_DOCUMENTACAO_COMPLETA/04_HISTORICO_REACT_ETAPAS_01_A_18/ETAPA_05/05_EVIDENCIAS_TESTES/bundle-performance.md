# Orçamento de bundle React

- JS total: 3679.7 KB (1033.6 KB gzip)
- CSS total: 495.0 KB
- Maior JS: assets/vendor-face-BvM7HRcj.js — 1283.8 KB (318.3 KB gzip)
- Violações: 0
- Avisos de otimização: 1

## Avisos de otimização

- Chunk pesado para revisão: assets/vendor-face-BvM7HRcj.js (1314597 bytes / 325931 gzip).

## Maiores arquivos

- `assets/vendor-face-BvM7HRcj.js`: 1283.8 KB / 318.3 KB gzip
- `assets/vendor-core-C0u3_FJt.js`: 493.5 KB / 143.9 KB gzip
- `assets/vendor-charts-lvNgAyK2.js`: 422.1 KB / 117.6 KB gzip
- `assets/vendor-pdf-BZmyc6F0.js`: 349.4 KB / 112.4 KB gzip
- `assets/vendor-react-6TxKP9aR.js`: 211.5 KB / 67.3 KB gzip
- `assets/pages-B0yio9mO.js`: 176.8 KB / 45.1 KB gzip
- `assets/index-DJ22CCOa.js`: 121.8 KB / 40.0 KB gzip
- `assets/index-BT1j9PDR.css`: 76.6 KB / 15.7 KB gzip
- `assets/pages-0TLfp-Ex.css`: 62.5 KB / 11.4 KB gzip
- `assets/EmpregadosLista-mEWKYChN.js`: 52.6 KB / 14.4 KB gzip
- `assets/PaginaFrequencia-C3B_Aryx.js`: 52.5 KB / 16.1 KB gzip
- `assets/EmpregadosLista-CwrJ_Np2.css`: 42.0 KB / 7.8 KB gzip
- `assets/FormularioEmpregado-C0Z8OAp-.js`: 41.3 KB / 10.3 KB gzip
- `assets/vendor-icons-5Lhzy8n-.js`: 40.6 KB / 11.8 KB gzip
- `assets/PaginaFrequencia-BedYu8PB.css`: 38.2 KB / 7.0 KB gzip
- `assets/Login-BbvLaclX.js`: 33.5 KB / 10.1 KB gzip
- `assets/PaginaRelatorioAbsenteismo-Dk7sQ5CF.js`: 33.3 KB / 8.8 KB gzip
- `assets/PaginaPerfil-D52mPdn7.js`: 31.8 KB / 9.4 KB gzip
- `assets/PaginaRelatoriosTerceirizados-Dp4Izamd.js`: 31.2 KB / 9.8 KB gzip
- `assets/PaginaTurnos-DoyilTi0.js`: 28.6 KB / 8.9 KB gzip
