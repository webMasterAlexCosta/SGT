# Origem documental — Etapa 04

- Fonte recuperada: `SGT_GTRAT_REACT_ETAPA_04.zip`.
- Conteúdo preservado sem reescrita: `00_LEIA_PRIMEIRO`, `02_DOCUMENTACAO_ETAPA_04` e `05_EVIDENCIAS_TESTES` quando existentes.
- Arquivos recuperados desta fonte: **48**.
- A documentação histórica é preservada para rastreabilidade; em conflito, prevalecem o Java atual e a documentação final da Etapa 18.
