# DECISÕES TÉCNICAS — ETAPA 04

1. **Fail-closed**: perfil/autoridade desconhecido não recebe fallback.
2. **Web Storage não autentica**: somente preferências/cache não autoritativos permanecem.
3. **2FA não pode ser pulado**: `requiresTwoFactor` mantém estado intermediário.
4. **Sessão/identidade são duas confirmações**: bootstrap consulta sessão e depois perfil.
5. **Heartbeat não é polling de escrita contínua**: `touch=true` é ligado à atividade humana.
6. **Renovação é single-flight**: uma promessa compartilhada evita renovação concorrente.
7. **Administrador técnico não vira gestor negocial** por conveniência do frontend.
8. **403 é esperado e compreensível**: deep links negados mostram estado de acesso negado.
9. **429 não inventa protocolo**: sem `lockout` do backend, não há contador local fictício.
10. **Avatar em storage é só cache de URL** e é removido quando deixa de existir/logout.
