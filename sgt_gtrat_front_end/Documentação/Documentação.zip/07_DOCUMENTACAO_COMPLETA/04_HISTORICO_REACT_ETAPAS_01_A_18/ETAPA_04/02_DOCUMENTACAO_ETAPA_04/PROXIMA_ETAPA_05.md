# PRÓXIMA ETAPA — 05

## Shell visual, design tokens, navegação e acessibilidade base

Objetivo previsto na documentação original: preservar o design Correios, reduzir inconsistência visual e preparar o shell para os novos módulos.

Escopo inicial:

- inventariar CSS global, CSS Modules, sidebar, header, modais e tokens;
- consolidar tokens Correios (cores, tipografia, espaçamento, bordas, sombras e estados);
- padronizar estrutura de página, loading, vazio e erro;
- adaptar sidebar/header/mobile às capacidades canônicas concluídas na Etapa 04;
- revisar navegação responsiva e acessibilidade base;
- manter React sem Tailwind e preservar CSS Modules.

A Etapa 05 **não foi iniciada** neste pacote.
