# COMANDOS E GATES — ETAPA 04

Executados sobre o estado final:

```text
npm run validate:runtime
npm run validar:nomenclatura
npm run test:configuracao
npm run test
npm run test:componentes
npm run test:camada2
npm run test:camada3:vitest
npm run test:qualidade:estatica
npm run test:bundle
npm run test:segredos:bundle
SGT_BACKEND_DIR=<JAVA atual> npm run test:integridade
```

Os logs e exit codes estão em `05_EVIDENCIAS_TESTES/`. A integridade retorna código 1 exclusivamente pela única divergência XLSX documentada.
