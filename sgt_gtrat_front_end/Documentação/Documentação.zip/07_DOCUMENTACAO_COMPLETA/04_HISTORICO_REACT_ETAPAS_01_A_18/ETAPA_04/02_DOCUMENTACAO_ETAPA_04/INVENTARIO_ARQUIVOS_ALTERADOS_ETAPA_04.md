# INVENTÁRIO DE ARQUIVOS ALTERADOS — ETAPA 04

Total de diferenças contra a baseline entregue da Etapa 03: **42**.

## Modificados (38)

- `src/Aplicacao.jsx`
- `src/core/http.js`
- `src/core/security/roles.js`
- `src/hooks/usePulsoAtividade.js`
- `src/modules/AtualizacaoModulo/index.jsx`
- `src/modules/admin/pages/PaginaUsuarios/components/CabecalhoUsuarios/index.jsx`
- `src/modules/admin/pages/PaginaUsuarios/components/ModalUsuario/index.jsx`
- `src/modules/admin/pages/PaginaUsuarios/components/TabelaUsuarios/index.jsx`
- `src/modules/admin/pages/PaginaUsuarios/index.jsx`
- `src/modules/auth/components/ModalReautenticacao.jsx`
- `src/modules/auth/context.jsx`
- `src/modules/auth/pages/Login/components/FormularioAcesso.jsx`
- `src/modules/auth/pages/Login/components/FormularioRecuperacaoSenha.jsx`
- `src/modules/auth/pages/Login/index.jsx`
- `src/modules/perfil/components/GerenciadorSegundoFator/index.jsx`
- `src/modules/perfil/pages/PaginaPerfil/index.jsx`
- `src/modules/rh/pages/PaginaFrequencia/useLogicaFrequencia.js`
- `src/services/auth/ServicoAutenticacao.js`
- `test/contratoHttpJava.test.js`
- `test/contratosPresidente.test.js`
- `test/filtrosEstado2fa.test.js`
- `test/hierarquiaGestaoLocal.test.js`
- `test/loginMatricula.test.js`
- `test/nomenclaturaGestao.test.js`
- `test/profilePasswordChange.test.js`
- `test/recuperacaoSenhaGmail.test.js`
- `test/relatoriosMensalAbsenteismo.test.js`
- `test/roles.test.js`
- `test/sessionInactivity.test.js`
- `test/vitest/Permissoes.test.js`
- `test/vitest-agressivo/camada2/ComportamentoTodosComponentes.test.jsx`
- `test/vitest-agressivo/camada3/RobustezPaginasCicloVida.test.jsx`
- `test/vitest-agressivo/fixtures/ambienteAgressivo.jsx`
- `test/vitest-componentes/ContextosReact.test.jsx`
- `test/vitest-componentes/HooksReact.test.jsx`
- `test/vitest-componentes/TodosComponentesRenderizacao.test.jsx`
- `test/vitest-componentes/fixtures/ambienteComponentes.jsx`
- `test/vitest-componentes/fixtures/componentesManifest.js`

## Novos (4)

- `src/core/security/AcessoNegado.jsx`
- `src/core/security/AcessoNegado.module.css`
- `src/core/security/estadoAutenticacao.js`
- `test/vitest/AutenticacaoEtapa04.test.js`

`node_modules`, `dist` e `reports` foram excluídos da comparação/entrega de fonte.
