# CONTRATO JAVA DE REFERÊNCIA — ETAPA 04

A referência usada nos testes foi o `JAVA(3).zip` enviado na conversa. SHA-256: `bb9eeb2d779015d00145aaee2aef55a45537082814ea79ba8eee135ac0055f18`.

## Escopo

A documentação original associa **20 endpoints** à Etapa 04: 12 de `AutenticacaoControlador` e 8 de `PerfilControlador`. A lista filtrada está em `ENDPOINTS_ETAPA_04.csv`.

## Pontos confirmados

- login recebe `matricula`, `password` e `totp` opcional;
- sessão é consultada em `/api/autenticacao/sessao`;
- identidade/autorização é confirmada por `/api/usuarios/meu-perfil`;
- renovação usa `/api/autenticacao/renovar-sessao`;
- logout usa `/api/autenticacao/encerrar-sessao`;
- recuperação possui solicitar/validar/confirmar;
- cadastro público fornece superintendências e gestões locais;
- 2FA do perfil possui status/configurar/ativar/desativar;
- perfil possui alterar senha, validar senha e avatar;
- autoridades canônicas usam prefixo `PERFIL_`.

Nenhum arquivo Java foi modificado.
