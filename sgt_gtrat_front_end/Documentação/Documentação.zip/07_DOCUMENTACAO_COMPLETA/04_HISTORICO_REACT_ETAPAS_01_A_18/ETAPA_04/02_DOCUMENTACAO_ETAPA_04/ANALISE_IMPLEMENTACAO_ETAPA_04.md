# ANÁLISE DE IMPLEMENTAÇÃO — ETAPA 04

## Baseline

A Etapa 03 deixou o núcleo HTTP pronto, mas a aplicação ainda possuía contratos legados de autenticação/perfis e nove divergências no gate integrado com o Java.

## Estratégia

A Etapa 04 concentrou autenticação e autorização em fontes canônicas do servidor e evitou migrar antecipadamente regras de domínio. A UI usa capacidades para experiência do usuário, mas o backend/403 permanece autoridade final.

## Resultado

O gate oficial da documentação original é: **“Zero skipTwoFactor/ROLE_* canônico; matriz dos seis perfis passa.”**

O scan final de `src` e `test` não encontra `ROLE_*` nem `skipTwoFactor` como contrato legado. Os seis perfis canônicos estão centralizados e os testes de autenticação/permissão passam.

A integração estática evoluiu de **267/276 (9 falhas)** na Etapa 03 para **277/278 (1 falha)** no estado final da Etapa 04. O total de testes aumentou porque foram adicionadas novas provas da própria Etapa 04. A falha remanescente é de exportação XLSX de frequência no Java, fora deste escopo.

## Requisitos transversais ainda rastreados

Seis requisitos `RFE-PERM` permanecem parciais porque dependem da revisão de telas/endpoints de domínio nas etapas posteriores: escopo específico, minimização de PII, permissões excepcionais, propagação explícita de capacidades em todo componente legado e precedência endpoint a endpoint de `@PreAuthorize`. Eles estão identificados no `STATUS_REQUISITOS_ETAPA_04.csv` e não impedem o gate textual desta etapa.
