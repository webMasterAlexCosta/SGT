# DIVERGÊNCIAS REACT × JAVA — ETAPA 04

| Estado | Testes | Aprovados | Falhas |
|---|---:|---:|---:|
| Etapa 03 | 276 | 267 | 9 |
| Etapa 04 final | 278 | 277 | 1 |

A Etapa 04 adicionou duas provas de integridade, por isso o total subiu de 276 para 278.

As divergências de autenticação/perfis presentes na Etapa 03 foram eliminadas/realinhadas. A única falha remanescente é a exportação XLSX de frequência no backend Java.

Evidências:

- `05_EVIDENCIAS_TESTES/09_integridade_java.log`;
- `05_EVIDENCIAS_TESTES/11_ETAPA03_integridade_java_referencia.log`.
