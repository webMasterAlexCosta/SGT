# ALTERAÇÕES — ETAPA 04

## Objetivo

Substituir o contrato legado de autenticação/roles pelo contrato canônico do Java e tornar sessão, 2FA e capacidades fail-closed.

## Implementações principais

1. **Seis perfis/autoridades canônicos** — `PERFIL_ADMINISTRADOR`, `PERFIL_GESTOR_NACIONAL`, `PERFIL_GESTOR_ESTADUAL`, `PERFIL_GESTOR_LOCAL`, `PERFIL_PRESIDENTE` e `PERFIL_OPERACIONAL`. O frontend não aceita `ROLE_*` como autoridade.
2. **State machine de autenticação** — restauração, não autenticado, credenciais aceitas, 2FA requerido, autenticado, primeira senha obrigatória e encerramento.
3. **Login 2FA** — payload `matricula/password/totp`, sem `skipTwoFactor`; `requiresTwoFactor=true` mantém a sessão fora do contexto autenticado até o TOTP ser concluído.
4. **Sessão como fonte de verdade** — bootstrap por `/autenticacao/sessao` e identidade/autorização por `/usuarios/meu-perfil`; nenhum usuário autoritativo é restaurado de Web Storage.
5. **Logout servidor** — `/autenticacao/encerrar-sessao` + limpeza local segura.
6. **Heartbeat/inatividade** — leituras de sessão deduplicadas por intenção (`touch=false`/`touch=true`) e atualização por atividade humana.
7. **Renovação de sessão deduplicada** — apenas uma chamada a `/autenticacao/renovar-sessao` fica em voo.
8. **Códigos de encerramento** — `SESSION_REPLACED`, `SESSION_EXPIRED`, `SESSION_INVALID`, dispositivos e estados de conta recebem mensagens sem detalhes técnicos.
9. **Recuperação de senha em três fases** — solicitar, validar deep link e confirmar explicitamente. Abrir o link não consome o token.
10. **Cadastro público hierárquico** — Gestão Estadual/UF → Gestão Local usando endpoints públicos oficiais.
11. **2FA do perfil** — status, configurar, ativar e desativar; status é reconsultado após mutações e segredo/QR fica apenas em memória visual.
12. **Troca de senha** — revalida perfil/sessão após sucesso e não força logout artificial.
13. **Gestão de usuários** — envio de `perfil` canônico e hierarquia Administrador → qualquer perfil, Gestor Nacional → Gestor Estadual, Gestor Estadual → Gestor Local, Gestor Local → Operacional.
14. **Capacidades semânticas** — `podeX` centralizados e rota inicial por perfil; Administrador técnico não herda automaticamente escrita negocial.
15. **Acesso negado compreensível** — deep link sem autorização apresenta estado explícito em vez de redirect silencioso.
16. **Rate limit fiel ao Java** — contador local só é criado quando o backend fornece `lockout`; não existe fallback inventado.
17. **Avatar/cache** — cache de URL usa uma única chave derivada de `APP_NAME`, é invalidável e não representa identidade/autorização.

## Não alterado

- Backend Java: **inalterado**.
- Dependências npm: **inalteradas** em relação à Etapa 03.
- Identidade visual Correios: sem redesenho nesta etapa.
