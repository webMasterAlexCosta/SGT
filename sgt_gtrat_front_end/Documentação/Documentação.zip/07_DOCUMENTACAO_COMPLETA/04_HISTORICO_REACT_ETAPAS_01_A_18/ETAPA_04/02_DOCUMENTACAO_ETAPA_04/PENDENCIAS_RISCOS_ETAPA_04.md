# PENDÊNCIAS E RISCOS — ETAPA 04

## 1. Única falha do gate integrado: XLSX de frequência

O estado final registra 277/278. A falha é:

`exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão`

Ela aponta para o Java atual e não foi causada pela autenticação. O backend foi mantido inalterado.

## 2. Requisitos de permissão que dependem de módulos posteriores

`RFE-PERM-011`, `012`, `013`, `014`, `018` e `020` permanecem `PARCIAL_RASTREADO`. A infraestrutura canônica está pronta, mas a comprovação integral exige migrar cada tela/endpoint de contratos, pessoas, relatórios, permissões excepcionais etc.

## 3. 403 continua sendo segurança final

Ocultar menu/botão não concede nem remove autorização. A UI trata acesso negado, mas o Java continua sendo a autoridade.

## 4. 429

O login só mostra contagem regressiva quando o Java fornece `lockout`. O filtro global 429 sem `Retry-After` continua sendo uma limitação contratual já registrada na Etapa 03.

## 5. Bundle e complexidade

- `vendor-face` é o maior chunk, mas permanece abaixo do limite do gate.
- `useLogicaFrequencia.js` é o único aviso de qualidade estática e deverá ser abordado na etapa de frequência/refatoração correspondente.
