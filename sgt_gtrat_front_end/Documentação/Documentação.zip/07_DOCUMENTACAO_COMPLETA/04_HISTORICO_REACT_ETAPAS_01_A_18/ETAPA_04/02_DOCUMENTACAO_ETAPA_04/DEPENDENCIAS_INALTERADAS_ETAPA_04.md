# DEPENDÊNCIAS — ETAPA 03 × ETAPA 04

`package.json`
- Etapa 03: `554a4c4dabb1030a70d9c1391cd9a890d79a3459927a94762be5d73a08058bec`
- Etapa 04: `554a4c4dabb1030a70d9c1391cd9a890d79a3459927a94762be5d73a08058bec`

`package-lock.json`
- Etapa 03: `356cbe7921f287648acbcff5a5802b5e640f662a13dd3d33d90b811e10a11123`
- Etapa 04: `356cbe7921f287648acbcff5a5802b5e640f662a13dd3d33d90b811e10a11123`

Conclusão: dependências npm **não foram alteradas** na Etapa 04.
