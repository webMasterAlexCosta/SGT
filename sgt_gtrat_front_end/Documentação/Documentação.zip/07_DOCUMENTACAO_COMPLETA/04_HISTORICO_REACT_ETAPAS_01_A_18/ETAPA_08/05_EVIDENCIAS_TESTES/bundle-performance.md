# Orçamento de bundle React

- JS total: 3726.6 KB (1046.9 KB gzip)
- CSS total: 514.7 KB
- Maior JS: assets/vendor-face-BvM7HRcj.js — 1283.8 KB (318.3 KB gzip)
- Violações: 0
- Avisos de otimização: 1

## Avisos de otimização

- Chunk pesado para revisão: assets/vendor-face-BvM7HRcj.js (1314597 bytes / 325931 gzip).

## Maiores arquivos

- `assets/vendor-face-BvM7HRcj.js`: 1283.8 KB / 318.3 KB gzip
- `assets/vendor-core-C0u3_FJt.js`: 493.5 KB / 143.9 KB gzip
- `assets/vendor-charts-lvNgAyK2.js`: 422.1 KB / 117.6 KB gzip
- `assets/vendor-pdf-BZmyc6F0.js`: 349.4 KB / 112.4 KB gzip
- `assets/vendor-react-6TxKP9aR.js`: 211.5 KB / 67.3 KB gzip
- `assets/pages-CUIFN1ai.js`: 176.8 KB / 45.1 KB gzip
- `assets/index-2wB-lpJL.js`: 126.2 KB / 41.0 KB gzip
- `assets/index-BT1j9PDR.css`: 76.6 KB / 15.7 KB gzip
- `assets/pages-0TLfp-Ex.css`: 62.5 KB / 11.4 KB gzip
- `assets/EmpregadosLista-DVp7QM-L.js`: 52.6 KB / 14.4 KB gzip
- `assets/PaginaFrequencia-BBGp4v34.js`: 52.5 KB / 16.1 KB gzip
- `assets/PaginaContratos-B2EcWhgb.js`: 47.8 KB / 12.7 KB gzip
- `assets/EmpregadosLista-CwrJ_Np2.css`: 42.0 KB / 7.8 KB gzip
- `assets/FormularioEmpregado-DAuC9c-i.js`: 41.3 KB / 10.3 KB gzip
- `assets/vendor-icons-abRiysRx.js`: 41.0 KB / 12.0 KB gzip
- `assets/PaginaFrequencia-BedYu8PB.css`: 38.2 KB / 7.0 KB gzip
- `assets/PaginaTurnos-2C8UqEZP.js`: 34.2 KB / 10.3 KB gzip
- `assets/Login-CTNauxdW.js`: 33.5 KB / 10.1 KB gzip
- `assets/PaginaRelatorioAbsenteismo-Drs38SVQ.js`: 33.3 KB / 8.8 KB gzip
- `assets/PaginaPerfil-DPxY17FN.js`: 31.9 KB / 9.4 KB gzip
