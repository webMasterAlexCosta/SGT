# Índice de evidências — Etapa 08

Cada gate final possui `.log` e `.exit` quando aplicável. Relatórios JUnit/qualidade/bundle foram copiados do estado final do projeto.

Atenção: `integridade_java.exit` é `1` por uma única falha preexistente de XLSX de frequência; `integridade_java.log` registra 293 testes, 292 aprovados e 1 falha.
