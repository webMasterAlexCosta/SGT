# SGT/GTRAT React — Etapa 08

Entrega fechada da **Etapa 08 — Contratos: núcleo e ciclo de vida**.

## Pastas

- `01_REACT_ETAPA_08`: fonte final desta etapa;
- `02_DOCUMENTACAO_ETAPA_08`: alterações, contratos Java, matrizes, rastreabilidade, diff e hashes;
- `03_DOCUMENTACAO_ORIGINAL`: documentação original das 18 etapas, preservada sem alteração;
- `04_REACT_ETAPA_07_REFERENCIA`: baseline imediatamente anterior, exatamente a fonte entregue na Etapa 07;
- `05_EVIDENCIAS_TESTES`: logs, exit codes e relatórios dos gates finais;
- `06_ENTRADAS_ORIGINAIS`: React antigo e planejamento original enviados no início.

## Estado

- 16/16 endpoints da Etapa 08 integrados/validados;
- ciclo de vida separado em estado negocial, situação temporal e habilitação administrativa;
- timeline, precedências, versões e consulta bitemporal disponíveis no detalhe;
- escrita contratual restrita ao Gestor Local, leitura para os seis perfis conforme Java;
- Java inalterado;
- gate integrado final: **292/293**, com a única falha XLSX de frequência preexistente no backend;
- Etapa 09 não iniciada.

O fonte não inclui `node_modules`, `dist`, `reports` nem `.git`.
