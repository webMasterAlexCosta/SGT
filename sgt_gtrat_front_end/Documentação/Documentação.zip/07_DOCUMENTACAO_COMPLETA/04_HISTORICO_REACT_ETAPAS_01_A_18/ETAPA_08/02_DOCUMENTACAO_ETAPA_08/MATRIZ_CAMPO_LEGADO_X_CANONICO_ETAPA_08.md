# Matriz campo legado × contrato canônico — Etapa 08

| Legado React | Estado na Etapa 08 | Campo/fluxo canônico |
|---|---|---|
| Número livre | mantido, como rascunho | `numeroContrato` |
| Ano implícito/ausente | adicionado | `anoContrato` |
| Tipo em texto livre | removido | `tipoContratacaoId` + `tipoContratacaoDescricao` |
| Descrição | mantido | `descricao` |
| Início/fim | mantidos | `dataInicio` / `dataFim` |
| Checkbox “Contrato ativo” | removido como comando | `habilitacaoAdministrativa`, alterada por `inativar`/`reativar` |
| Gestão Local | mantida | `gestaoLocalId` / `gestaoLocalNome` |
| Efetivo previsto | mantido | `efetivoPrevisto` |
| Empresa ausente/incompleta | adicionado | `cnpjEmpresa`, `razaoSocialEmpresa`, `nomeFantasiaEmpresa` |
| Situação única calculada no React | substituída | `estadoNegocial` + `situacaoTemporal` + `habilitacaoAdministrativa` do Java |
| Histórico simples/inexistente | substituído | eventos + precedências + versões |
| Sem visão bitemporal | adicionado | `posicao-temporal?data&conhecidoAte` |
| Exclusão genérica | restringida na UI | descarte apenas de rascunho; Java decide elegibilidade final |
