# Comandos de gates — Etapa 08

```bash
npm run validate:runtime
npm run validar:nomenclatura
npm run test:configuracao
npx vitest run --config vitest.config.js --coverage.enabled=false test/vitest/contratosEtapa08.test.js
SGT_BACKEND_DIR=<JAVA> node --test test/contratosEtapa08.test.js
npm run test
npm run test:componentes
npm run test:camada2
npm run test:camada3:vitest
npm run test:qualidade:estatica
npm run test:bundle
npm run test:segredos:bundle
SGT_BACKEND_DIR=<JAVA> npm run test:integridade
```

O último comando retorna código 1 exclusivamente pela divergência XLSX preexistente. O log final contém `293 tests / 292 pass / 1 fail`.
