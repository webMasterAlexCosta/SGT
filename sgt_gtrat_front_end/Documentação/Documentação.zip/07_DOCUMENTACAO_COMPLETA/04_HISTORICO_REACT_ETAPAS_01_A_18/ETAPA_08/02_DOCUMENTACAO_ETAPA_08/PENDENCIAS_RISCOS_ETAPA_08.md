# Pendências e riscos — Etapa 08

## 1. XLSX de frequência — preexistente no Java

O gate integrado termina em 292/293 porque o teste `exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão` continua divergindo da implementação Java atual (`XlsxStreamingWriter`). Esse achado já existia nas etapas anteriores e não é causado por Contratos.

## 2. Composição necessária para publicação

O Java exige composição original consistente para publicar. A UI de composição é escopo formal da Etapa 09. Nesta etapa o comando de publicação existe e a resposta/erro do Java é preservada; não foi criada composição fictícia no cliente.

## 3. Documentos completos

Upload/versionamento documental e fonte comprobatória por anexo pertencem à Etapa 10. Enquanto isso, ações que exigem fonte solicitam referência SEI quando aplicável.

## 4. Pendências administrativas

O requisito trata pendências como eixo independente, mas os 16 endpoints/`ContratoDTO` desta etapa não trazem esse resumo. Não foi criado indicador local autoritativo. A integração deve ocorrer quando o endpoint/domínio de pendências for incorporado na etapa apropriada.

## 5. Smoke real navegador + backend

Os gates desta entrega cobrem contrato HTTP mockado, regressão React e comparação estática integrada com o Java. Não foi declarado smoke E2E real com banco/backend em execução neste executor.

## 6. Chunk `vendor-face`

O Vite continua emitindo o aviso herdado de chunk acima de 1 MB. O gate de orçamento do próprio projeto permanece aprovado.
