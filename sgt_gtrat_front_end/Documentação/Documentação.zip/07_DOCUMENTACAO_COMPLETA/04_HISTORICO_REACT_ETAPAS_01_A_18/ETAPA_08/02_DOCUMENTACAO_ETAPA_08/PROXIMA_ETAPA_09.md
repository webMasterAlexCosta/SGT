# Próxima etapa — Etapa 09

**Contratos — composição, excedentes, aditamentos e remanejamentos.**

O inventário original associa **15 endpoints** à Etapa 09:

- 5 de aditamentos;
- 5 de composições/excedentes;
- 5 de remanejamentos.

Prioridades:

1. fluxos de prévia → revisão de impacto → confirmação quando a API oferece prévia;
2. composição por lotação/turno/cargo, com total autoritativo vindo do Java;
3. aditamento positivo/negativo com data efetiva, histórico, retificação e cancelamento;
4. excedentes sem reconciliação autoritativa no React;
5. remanejamento com contexto/token da prévia e tratamento de concorrência/409;
6. validar publicação do contrato após existir composição consistente.

A Etapa 09 **não foi iniciada neste ZIP**.
