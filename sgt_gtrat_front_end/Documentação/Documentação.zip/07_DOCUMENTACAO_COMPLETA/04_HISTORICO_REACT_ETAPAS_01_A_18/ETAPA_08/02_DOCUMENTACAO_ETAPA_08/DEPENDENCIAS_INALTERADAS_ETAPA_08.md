# Dependências — Etapa 08

- `package.json`: inalterado em relação à Etapa 07.
- `package-lock.json`: inalterado em relação à Etapa 07.
- `.node-version`: inalterado em relação à Etapa 07.
- `.nvmrc`: inalterado em relação à Etapa 07.

Nenhuma dependência NPM foi adicionada para a Etapa 08.
