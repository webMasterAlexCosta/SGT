# Análise do contrato Java — Etapa 08

## Modelo canônico

`ContratoDTO` separa três conceitos que o React legado misturava:

- `estadoNegocial`: `RASCUNHO`, `PUBLICADO`, `CANCELADO`, `ANULADO`;
- `situacaoTemporal`: `RASCUNHO`, `FUTURO`, `VIGENTE`, `ENCERRADO`, `CANCELADO`, `ANULADO`;
- `habilitacaoAdministrativa`: `ATIVO`, `INATIVO`.

O campo legado `ativo` permanece no DTO por compatibilidade, mas não é usado pelo novo formulário como comando autoritativo.

## Rascunho

O serviço Java permite rascunho incompleto. As obrigatoriedades de publicação não foram antecipadas no formulário de criação. O React só executa validações estruturais seguras (ordem das datas quando ambas existem, formato do CNPJ se informado, etc.); unicidade e regra negocial permanecem no Java.

## Publicação

A publicação exige validações canônicas no backend, incluindo dados completos, Tipo de Contratação ativo, empresa, vigência, efetivo e composição original consistente. Como a UI de composição pertence à Etapa 09, a Etapa 08 expõe o comando de publicação e informa que o servidor fará essa validação. A referência SEI é exigida na UI porque o fluxo documental completo pertence à Etapa 10.

## Eventos de ciclo de vida

- inativação/reativação são eventos administrativos, não encerramento de vigência;
- encerramento antecipado altera o fim efetivo e exige fonte comprobatória;
- cancelamento futuro é distinto de anulação e encerramento;
- anulação preserva o registro e exige data do ato, data efetiva e fonte comprobatória;
- descarte físico permanece restrito a rascunho elegível, decisão final do Java.

## Temporalidade

`GET /api/contratos/{id}/posicao-temporal` usa:

- `LocalDate data`: data efetiva de referência;
- `Instant conhecidoAte`: corte opcional da verdade conhecida.

A tela não reconstrói fatos por conta própria; apresenta a resposta do servidor.

## Segurança

- leitura de `/api/contratos/**`: seis perfis canônicos;
- escrita de `/api/contratos/**`: `PERFIL_GESTOR_LOCAL`;
- mutações do controlador da Etapa 08 estão protegidas por `@ExigirSenha`.

## Pendências

Pendências administrativas são um eixo conceitualmente independente, porém não fazem parte do `ContratoDTO` nem dos 16 endpoints desta etapa. Por isso esse eixo foi rastreado como parcial, sem informação sintética inventada no frontend.
