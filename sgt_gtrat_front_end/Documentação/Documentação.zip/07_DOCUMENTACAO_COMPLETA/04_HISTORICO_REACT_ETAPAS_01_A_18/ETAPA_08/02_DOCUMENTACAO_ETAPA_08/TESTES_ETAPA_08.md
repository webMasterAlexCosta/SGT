# Testes — Etapa 08

Resultados finais do estado exato empacotado:

- runtime: aprovado;
- nomenclatura: 227 arquivos, aprovado;
- configuração: **16/16**;
- focal Etapa 08 (Vitest): **9/9**;
- integrado focal Etapa 08 (Node + Java): **8/8**;
- unitários: **82/82**;
- componentes: **348/348**;
- Camada 2: **591/591**;
- Camada 3: **478/478**;
- qualidade estática: **227 arquivos, 0 erros de gate, 1 aviso**;
- bundle/budget: aprovado;
- segredos no bundle: aprovado;
- integridade React × Java: **292/293**, uma única falha XLSX preexistente.

O `stderr` conhecido do teste de absenteísmo simula falha de resumo e faz parte de um cenário que passa. Avisos `requestSubmit()` do JSDOM não representam falha funcional.

Os logs e códigos de saída estão em `05_EVIDENCIAS_TESTES`.
