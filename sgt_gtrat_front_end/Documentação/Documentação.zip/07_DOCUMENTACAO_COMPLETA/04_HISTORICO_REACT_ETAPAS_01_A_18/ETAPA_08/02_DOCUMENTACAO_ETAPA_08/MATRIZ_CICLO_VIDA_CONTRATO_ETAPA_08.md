# Matriz do ciclo de vida — Etapa 08

| Situação observada | Ações apresentadas ao Gestor Local | Autoridade final |
|---|---|---|
| RASCUNHO | editar, publicar, descartar | Java valida rascunho/publicação/elegibilidade do descarte |
| PUBLICADO + VIGENTE + ATIVO | inativar, encerrar antecipadamente, anular | Java |
| PUBLICADO + VIGENTE + INATIVO | reativar, encerrar antecipadamente, anular | Java |
| PUBLICADO + FUTURO | inativar/reativar conforme habilitação, cancelar futuro, encerrar conforme regra, anular | Java |
| ENCERRADO/CANCELADO/ANULADO | consulta histórica; sem edição livre | Java |

## Datas de evento

A UI mantém separadas:

- **data efetiva**: quando o fato produz alcance temporal;
- **data do ato**: data do documento/ato, obrigatória quando o contrato Java exige;
- **registrado em**: instante persistido pelo backend.

## Concorrência e conflitos

A infraestrutura HTTP central preserva 409 como conflito negocial e não repete mutações incertas automaticamente. A confirmação por senha segue o fluxo 428 implementado nas etapas anteriores.
