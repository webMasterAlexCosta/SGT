# Inventário de endpoints — Etapa 08

Total planejado: **16**. Total integrado/validado: **16**.

| Método | Endpoint | Java | Senha | Status |
|---|---|---|---:|---|
| GET | `/api/contratos` | `listarTodos` | NAO | INTEGRADO_VALIDADO |
| GET | `/api/contratos/opcoes` | `obterOpcoes` | NAO | INTEGRADO_VALIDADO |
| GET | `/api/contratos/{id}` | `buscarPorId` | NAO | INTEGRADO_VALIDADO |
| GET | `/api/contratos/{id}/eventos` | `listarEventos` | NAO | INTEGRADO_VALIDADO |
| GET | `/api/contratos/{id}/eventos/precedencias` | `listarPrecedencias` | NAO | INTEGRADO_VALIDADO |
| GET | `/api/contratos/{id}/versoes` | `listarVersoes` | NAO | INTEGRADO_VALIDADO |
| GET | `/api/contratos/{id}/posicao-temporal` | `consultarPosicaoTemporal` | NAO | INTEGRADO_VALIDADO |
| POST | `/api/contratos` | `criar` | SIM | INTEGRADO_VALIDADO |
| POST | `/api/contratos/{id}/publicar` | `publicar` | SIM | INTEGRADO_VALIDADO |
| PUT | `/api/contratos/{id}` | `atualizar` | SIM | INTEGRADO_VALIDADO |
| POST | `/api/contratos/{id}/inativar` | `inativar` | SIM | INTEGRADO_VALIDADO |
| POST | `/api/contratos/{id}/reativar` | `reativar` | SIM | INTEGRADO_VALIDADO |
| POST | `/api/contratos/{id}/encerrar-antecipadamente` | `encerrarAntecipadamente` | SIM | INTEGRADO_VALIDADO |
| POST | `/api/contratos/{id}/cancelar-futuro` | `cancelarFuturo` | SIM | INTEGRADO_VALIDADO |
| POST | `/api/contratos/{id}/anular` | `anular` | SIM | INTEGRADO_VALIDADO |
| DELETE | `/api/contratos/{id}` | `excluir` | SIM | INTEGRADO_VALIDADO |

Endpoints de transferência/correção excepcional estão classificados como Etapa 10 no inventário original e não foram adicionados ao serviço desta etapa.
