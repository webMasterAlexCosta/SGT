# Alterações — Etapa 08

## Objetivo

Substituir o CRUD simplificado de contratos pelo núcleo temporal e auditável definido no Java atual, sem antecipar composição/aditamentos/remanejamentos da Etapa 09 nem documentos/transferências/correções excepcionais da Etapa 10.

## Principais mudanças

1. `ServicoContrato` passou a representar os 16 endpoints do `ContratoControlador` pertencentes à Etapa 08.
2. O formulário foi convertido em **rascunho canônico**: número/ano, Tipo de Contratação por ID, empresa, vigência, efetivo, Gestão Local e obrigatoriedade de matrícula.
3. O antigo checkbox `ativo` deixou de comandar o contrato. A habilitação administrativa agora é alterada somente por eventos de inativação/reativação do Java.
4. Lista e detalhe exibem separadamente:
   - estado negocial;
   - situação temporal;
   - habilitação administrativa.
5. O detalhe contratual passou a expor:
   - timeline de eventos;
   - relações de precedência;
   - versões negociais;
   - consulta temporal/bitemporal (`data` + `conhecidoAte`).
6. Foram adicionados comandos explícitos para:
   - publicação;
   - inativação administrativa;
   - reativação;
   - encerramento antecipado;
   - cancelamento de contrato futuro;
   - anulação;
   - descarte físico de rascunho elegível.
7. As mutações reutilizam o fluxo central de confirmação de senha da Etapa 03/04 e não implementam retry cego.
8. Presidente mantém visão nacional somente leitura; Gestor Local é o único perfil com escrita de contrato, conforme `ConfiguracaoSeguranca`.
9. O detalhe diferencia **data efetiva**, **data do ato** e **data/hora de registro**.
10. O React não implementa rotas de `transferir-gestao`, `corrigir-anulacao` ou histórico de transferências nesta etapa.

## Java

O backend de referência foi apenas lido para validação de contrato. **Nenhum arquivo Java foi alterado.**
