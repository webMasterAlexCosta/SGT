# Matriz de permissões — Contratos / Etapa 08

| Perfil | Consultar contratos | Consulta nacional | Criar/editar/comandar ciclo de vida |
|---|---:|---:|---:|
| Administrador | sim | conforme escopo global | não |
| Gestor Nacional | sim | sim | não |
| Presidente | sim | sim | não |
| Gestor Estadual | sim | conforme escopo estadual | não |
| Gestor Local | sim | não; escopo da Gestão Local | **sim** |
| Operacional | sim | não | não |

A matriz reproduz o matcher do Java. O React não amplia a autorização.
