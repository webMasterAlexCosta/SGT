# Origem documental — Etapa 03

- Fonte recuperada: `SGT_GTRAT_REACT_ETAPA_03.zip`.
- Conteúdo preservado sem reescrita: `00_LEIA_PRIMEIRO`, `02_DOCUMENTACAO_ETAPA_03` e `05_EVIDENCIAS_TESTES` quando existentes.
- Arquivos recuperados desta fonte: **30**.
- A documentação histórica é preservada para rastreabilidade; em conflito, prevalecem o Java atual e a documentação final da Etapa 18.
