# SGT/GTRAT — Entrega React — Etapa 03

## Escopo fechado

Esta entrega corresponde à **Etapa 03 — Core HTTP, CSRF, envelope e segurança de comandos** do planejamento original de 18 etapas.

A baseline de código é a entrega aprovada da **Etapa 02**. O Java atual foi utilizado exclusivamente como referência de contrato e para a suíte de integridade; **nenhum arquivo Java foi alterado**.

## Estrutura do pacote

- `01_REACT_ETAPA_03/sgt_gtrat_front_end`: React após a Etapa 03, sem `node_modules`, `dist`, `reports` e `.git`.
- `02_DOCUMENTACAO_ETAPA_03`: documentação produzida nesta etapa, decisões, rastreabilidade, riscos, inventário e diff Etapa 02 × Etapa 03.
- `03_DOCUMENTACAO_ORIGINAL`: cópia inalterada do planejamento/requisitos originais enviados pelo usuário.
- `04_REACT_ETAPA_02_REFERENCIA`: baseline exata usada para a evolução da Etapa 03.
- `05_EVIDENCIAS_TESTES`: logs dos gates e comparação de integridade com a Etapa 02.
- `06_ENTRADAS_ORIGINAIS`: ZIP original do React antigo e ZIP original do planejamento, acompanhados por hashes.

## Decisão de gate

**Etapa 03: APROVADA COM DIVERGÊNCIAS HERDADAS E ITENS DE APLICAÇÃO DIFERIDA DOCUMENTADOS.**

Os gates próprios da camada HTTP passaram. A suíte integrada React × Java permaneceu com as **mesmas 9 divergências herdadas da Etapa 02**, sem aumento de divergências.

O gate principal da Etapa 03 foi atingido: mutações futuras podem consumir **CSRF, confirmação de senha, envelope, erro, retry, idempotência, datas, multipart, download e cancelamento** pela infraestrutura central, sem recriar essas preocupações em cada serviço.

Alguns requisitos do catálogo CSRF/HTTP dependem de telas e comandos concretos (duplo clique, prévia/impacto, retorno seguro em 404, reconciliação de estado após timeout). Eles estão marcados como **aplicação diferida** para as etapas de domínio; a infraestrutura necessária foi preparada nesta etapa quando possível.

## Próximo passo

A próxima entrega deve iniciar a **Etapa 04 — Autenticação, sessão, 2FA e autoridades**, usando `01_REACT_ETAPA_03/sgt_gtrat_front_end` como nova baseline.
