# ANÁLISE DE IMPLEMENTAÇÃO — ETAPA 03

## Situação encontrada na baseline da Etapa 02

Antes da alteração, o React já possuía um cliente Axios central, mas ainda faltavam garantias exigidas pelo Java escalonado:

- não havia coordenador CSRF com bootstrap deduplicado;
- o envelope era reduzido cedo demais, perdendo `meta`, `status` e `requestId`;
- não existia fluxo central para o 428 de `@ExigirSenha`;
- o retry não distinguia suficientemente uma mutação de resultado incerto;
- idempotência ainda não estava modelada como intenção;
- multipart, download e tipos temporais não tinham contrato único;
- os erros HTTP não tinham classificação semântica uniforme;
- sanitização de dados sensíveis não era responsabilidade explícita do núcleo.

## Estratégia adotada

A Etapa 03 foi implementada como infraestrutura transversal, sem migrar antecipadamente as telas das etapas seguintes.

A compatibilidade com o React legado foi preservada por duas interfaces:

- `requisitar`: continua devolvendo o payload de dados;
- `requisitarEnvelope`: devolve o contexto completo para código novo.

Essa estratégia reduz a superfície de regressão e permite migrar domínio por domínio nas etapas 04–18.

## Resultado

A camada central agora contém pontos únicos para:

- requisição;
- envelope;
- erro;
- CSRF;
- confirmação de senha;
- retry;
- idempotência;
- datas;
- multipart;
- download;
- sanitização.

A regressão completa das camadas 1–3 permaneceu verde. A integridade com o Java manteve o mesmo conjunto de nove divergências da Etapa 02.

## Critério de saída

O gate textual da documentação original é:

> Nenhuma mutação futura precisa implementar CSRF/senha/idempotência por conta própria.

A infraestrutura implementada satisfaz esse critério. A aplicação concreta das capacidades em cada endpoint continuará sendo validada nas etapas de domínio.
