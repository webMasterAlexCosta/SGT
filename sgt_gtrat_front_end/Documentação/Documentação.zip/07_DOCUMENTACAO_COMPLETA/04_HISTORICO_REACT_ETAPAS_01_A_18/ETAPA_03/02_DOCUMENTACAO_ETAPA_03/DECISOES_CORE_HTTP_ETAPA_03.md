# DECISÕES TÉCNICAS — CORE HTTP — ETAPA 03

## 1. Compatibilidade progressiva

A camada central preserva o comportamento legado de retornar `data` para serviços existentes, mas disponibiliza `requisitarEnvelope` para módulos novos que precisam de status, meta, headers e requestId.

Isso evita migrar todos os serviços de domínio dentro da Etapa 03.

## 2. CSRF em memória

O token CSRF não é persistido em Web Storage. Uma promessa compartilhada evita múltiplos bootstraps simultâneos.

## 3. 403 não é sinônimo de CSRF

Não existe heurística por texto. Renovação automática só acontece com código explícito de CSRF e somente quando o replay é seguro.

## 4. 428 como fluxo, não como toast terminal

`PASSWORD_CONFIRMATION_REQUIRED` abre o provedor central. A intenção original é repetida uma vez com `X-User-Password`.

## 5. Senha efêmera

A senha não é persistida, é removida de headers/config após a tentativa e o campo do modal é limpo depois de erro.

## 6. Idempotência segue o Java

O frontend não cria um protocolo inexistente. A chave é inserida no corpo/DTO quando a requisição declara idempotência.

## 7. Falha de rede em mutação é resultado incerto

POST/PUT/PATCH/DELETE não ganham retry automático por conveniência. O chamador recebe indicação de resultado incerto e deve reconciliar o estado quando houver endpoint adequado.

## 8. GET pode usar retry

GET pode usar retry limitado com backoff, jitter, `Retry-After` e `AbortSignal`.

## 9. Multipart deixa o browser definir boundary

Definir manualmente `Content-Type: multipart/form-data` pode quebrar o boundary. A infraestrutura remove esse header quando o corpo é `FormData`.

## 10. Erro de suporte usa requestId

Stack/Exception/PII não devem aparecer ao usuário. O identificador rastreável é `requestId`.
