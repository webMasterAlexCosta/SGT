# RASTREABILIDADE — ETAPA 03

## Checklist oficial da Etapa 03

| Item do plano | Situação | Evidência principal |
|---|---|---|
| Coordenador CSRF com bootstrap deduplicado | CONCLUÍDO | `coordenadorCsrf.js`, teste concorrente |
| Header CSRF dinâmico em mutações | CONCLUÍDO | interceptor + teste `headerName` |
| Envelope/meta/status/requestId | CONCLUÍDO | `respostaHttp.js`, `requisitarEnvelope` |
| Catálogo 400/401/403/404/409/413/415/422/428/429/5xx | CONCLUÍDO | `erroHttp.js` |
| Fluxo central `X-User-Password` | CONCLUÍDO | coordenador + provedor + modal |
| Intenção/replay controlado após 428 | CONCLUÍDO | replay único testado |
| Chave de idempotência | CONCLUÍDO NO NÚCLEO | segue `chaveIdempotencia` do Java |
| Retry GET / mutações seguras | CONCLUÍDO | `retryPolicy.js` |
| Multipart/download | CONCLUÍDO | helpers + testes |
| LocalDate/YearMonth/Instant/arrays | CONCLUÍDO | helpers + testes |
| AbortSignal/resposta fora de ordem | BASE CONCLUÍDA | cancelamento central; consumo por filtros continua por módulo |
| Sanitização de logs/erros | CONCLUÍDO | `sanitizacao.js` + teste |

## Requisitos RFE-HTTP

| Requisito | Situação | Observação |
|---|---|---|
| RFE-HTTP-001 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-002 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-003 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-004 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-005 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-006 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-007 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-008 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-009 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-010 | APLICACAO_DIFERIDA | Classificação 404 existe; navegação segura depende das telas de detalhe. |
| RFE-HTTP-011 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-012 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-013 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-014 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-015 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-016 | IMPLEMENTADO_BASE | 5xx/mutação é marcada como resultado incerto e sem retry automático. |
| RFE-HTTP-017 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-018 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-019 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-020 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-021 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-022 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-023 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-024 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-025 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-026 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-027 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-028 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-HTTP-029 | PARCIAL/CONTINUO | Helper exige método; migração de todos os serviços será validada conforme cada módulo. |
| RFE-HTTP-030 | PARCIAL/CONTINUO | Serializador central existe; serviços legados serão migrados por módulo. |

## Requisitos RFE-CSRF

| Requisito | Situação | Observação |
|---|---|---|
| RFE-CSRF-001 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-002 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-003 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-004 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-005 | PARCIAL/BACKEND | Suporte existe, mas Java atual não diferencia falha CSRF com código estável. |
| RFE-CSRF-006 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-007 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-008 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-009 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-010 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-011 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-012 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-013 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |
| RFE-CSRF-014 | APLICACAO_DIFERIDA | Bloqueio de double click deve ser aplicado aos comandos concretos. |
| RFE-CSRF-015 | APLICACAO_DIFERIDA | Modal central mostra consequência; confirmação destrutiva adicional depende do comando. |
| RFE-CSRF-016 | APLICACAO_DIFERIDA | Fluxos de prévia pertencem aos módulos contratuais/negociais. |
| RFE-CSRF-017 | APLICACAO_DIFERIDA | Invalidação da prévia depende do estado de formulário do módulo. |
| RFE-CSRF-018 | APLICACAO_DIFERIDA | Conflito de token de prévia depende do endpoint de domínio. |
| RFE-CSRF-019 | APLICACAO_DIFERIDA | Infra marca resultado incerto; reconciliação requer endpoint de leitura do domínio. |
| RFE-CSRF-020 | IMPLEMENTADO_BASE | Infraestrutura central implementada/testada. |

## Leitura da matriz

`IMPLEMENTADO_BASE` significa que a responsabilidade transversal foi implementada no core e já possui evidência de teste.

`PARCIAL/CONTINUO` significa que a infraestrutura existe, mas a eliminação de padrões legados só pode ser completada com segurança ao migrar os serviços correspondentes.

`APLICACAO_DIFERIDA` não é falha da Etapa 03: indica requisito que exige tela/comando concreto e deve ser comprovado nas etapas de domínio.

`PARCIAL/BACKEND` indica que o frontend está preparado, porém o contrato atual do Java ainda não fornece informação suficiente para executar a automação de forma segura.
