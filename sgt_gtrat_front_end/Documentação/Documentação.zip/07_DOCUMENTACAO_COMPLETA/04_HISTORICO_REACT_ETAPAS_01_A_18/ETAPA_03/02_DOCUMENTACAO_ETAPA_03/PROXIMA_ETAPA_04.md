# PRÓXIMA ETAPA — 04

## Etapa 04 — Autenticação, sessão, 2FA e autoridades

A Etapa 04 deve partir exclusivamente da baseline `01_REACT_ETAPA_03/sgt_gtrat_front_end`.

### Escopo principal já definido pelo planejamento

1. remover `skipTwoFactor`;
2. implementar state machine de login com HTTP 202/2FA;
3. substituir `ROLE_*` canônico pelos seis `PERFIL_*` do Java;
4. eliminar fallback `ROLE_USER`;
5. deixar Web Storage sem autoridade sobre usuário/sessão;
6. restaurar sessão por API;
7. implementar logout servidor + limpeza local;
8. tratar códigos de sessão;
9. adaptar solicitação/cadastro de acesso;
10. validar recuperação e primeira senha;
11. adaptar 2FA do perfil;
12. centralizar capacidades e rota inicial por perfil.

### Regra de continuidade

A Etapa 04 deve reutilizar o core da Etapa 03:

- nenhuma tela deve implementar CSRF manual;
- nenhuma tela deve criar fluxo próprio para 428;
- nenhum serviço deve inventar retry de mutação;
- requestId/erro/envelope devem usar o core;
- senha de confirmação deve continuar efêmera.

### Divergências herdadas relevantes

Uma das divergências integradas já aponta diretamente para a Etapa 04: o React legado ainda possui contrato de login incompatível com o Java atual, incluindo `skipTwoFactor`.

A correção deve acontecer na Etapa 04, não retroativamente na Etapa 03.
