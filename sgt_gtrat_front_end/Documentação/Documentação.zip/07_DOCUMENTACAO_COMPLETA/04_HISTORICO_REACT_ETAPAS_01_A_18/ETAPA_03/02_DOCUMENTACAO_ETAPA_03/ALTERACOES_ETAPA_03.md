# ALTERAÇÕES — ETAPA 03

## Objetivo

Adequar a camada HTTP do React ao contrato pós-auditoria do Java antes de expandir módulos de negócio.

## Alterações implementadas

### 1. Cliente HTTP central

`src/core/http.js` passou a concentrar o comportamento transversal da API:

- `withCredentials=true`;
- `X-Request-Id`;
- `X-Client`;
- `X-Client-Version`;
- `X-Timezone`;
- serialização central de parâmetros;
- normalização de resposta/envelope;
- normalização semântica de erros;
- CSRF em mutações;
- confirmação de senha por 428;
- retry seguro/cancelável;
- invalidação do CSRF quando o contexto de sessão muda.

Os serviços legados continuam podendo receber somente `data`, enquanto chamadas que precisam de status/meta/headers/requestId podem usar `requisitarEnvelope`.

### 2. Coordenador CSRF

Foi criado `src/core/http/coordenadorCsrf.js`.

Comportamento:

- token mantido apenas em memória;
- bootstrap por `GET /autenticacao/csrf`;
- deduplicação de bootstrap concorrente por promessa compartilhada;
- uso do `headerName` retornado pelo Java;
- aplicação automática somente a POST/PUT/PATCH/DELETE;
- invalidação após mudanças relevantes de sessão;
- renovação apenas quando a falha puder ser identificada como CSRF e o replay estiver explicitamente seguro.

### 3. Envelope e paginação

Foi criado `src/core/http/respostaHttp.js`.

A normalização preserva:

- status HTTP;
- `data`;
- `meta`;
- `requestId`;
- headers;
- `path`;
- indicadores semânticos como 202 pendente e 204 sem conteúdo.

`extrairPagina` mantém os metadados de paginação em vez de reduzir `Page<T>` a uma lista simples.

### 4. Catálogo semântico de erros

Foi criado `src/core/http/erroHttp.js`.

Tratamento explícito para:

- 400;
- 401;
- 403;
- 404;
- 409;
- 413;
- 415;
- 422;
- 428;
- 429;
- 5xx;
- erro de rede;
- cancelamento voluntário.

O erro normalizado preserva `requestId`, campos de validação, `Retry-After` quando presente e a noção de resultado incerto em mutações.

### 5. Fluxo central `@ExigirSenha`

Foram criados:

- `src/core/http/coordenadorConfirmacaoSenha.js`;
- `src/core/security/ProvedorConfirmacaoSenhaHttp.jsx`.

O modal de confirmação foi integrado à aplicação em `src/Aplicacao.jsx`.

Fluxo:

1. a mutação é enviada sem senha;
2. o Java responde 428 `PASSWORD_CONFIRMATION_REQUIRED`;
3. a intenção original é mantida em memória;
4. o usuário vê ação, entidade e consequência;
5. a senha é enviada em `X-User-Password`;
6. o replay ocorre uma única vez;
7. a senha é removida da configuração imediatamente depois;
8. 403 `INVALID_CONFIRMATION_PASSWORD` mantém a sessão e limpa o campo de senha.

### 6. Idempotência por intenção

Foi criado `src/core/http/idempotencia.js`.

Decisão adotada: **não inventar o header `Idempotency-Key`**.

O Java atual usa `chaveIdempotencia` em DTOs/corpos específicos. A infraestrutura permite gerar uma chave por intenção e injetá-la no campo definido pelo contrato da requisição. O replay da mesma intenção preserva a chave; uma nova intenção recebe outra chave.

### 7. Retry seguro

`src/core/http/retryPolicy.js` foi revisado:

- GET pode repetir com backoff limitado;
- retry é cancelável por `AbortSignal`;
- `Retry-After` é respeitado quando enviado;
- mutações não são repetidas automaticamente por padrão;
- mutações somente podem repetir quando marcadas como idempotentes/seguras;
- requisição que carregou `X-User-Password` não entra em retry automático.

### 8. Datas e query params

Foram adicionados helpers para:

- `LocalDate` como `YYYY-MM-DD`, sem conversão UTC acidental;
- `YearMonth` como `YYYY-MM`;
- `Instant` ISO-8601 com offset ou `Z`;
- arrays em query params no formato repetido compatível com Spring.

### 9. Multipart e download

Foram criados helpers para:

- `FormData`;
- remoção de `Content-Type: multipart/form-data` manual para o browser gerar o boundary;
- preservação dos nomes das partes;
- downloads usando blob e headers reais;
- nome de arquivo seguro a partir de `Content-Disposition`.

### 10. Sanitização

Foi criado `src/core/http/sanitizacao.js`.

A normalização não envia para UI/telemetria:

- `X-User-Password`;
- tokens;
- stack traces;
- senha;
- CPF completo;
- estruturas técnicas sensíveis.

Quando a mensagem do backend parece técnica, a UI usa mensagem segura e mantém `requestId` para suporte.

### 11. Testes

Foram adicionados:

- `test/vitest/httpEtapa03.test.js`;
- `test/vitest-componentes/ConfirmacaoSenhaHttpEtapa03.test.jsx`;
- fixture do novo provedor no manifesto público de componentes.

## O que não foi alterado

- nenhum arquivo Java;
- nenhuma dependência npm;
- `package.json` e `package-lock.json` são idênticos aos da Etapa 02;
- identidade visual Correios;
- Tailwind não foi introduzido;
- módulos de autenticação/2FA/perfis não foram migrados antecipadamente; isso pertence à Etapa 04.
