# COMANDOS E GATES EXECUTADOS — ETAPA 03

## Gates registrados

Os seguintes grupos foram executados sobre o estado final da Etapa 03, depois da última alteração de código:

```text
npm run test:configuracao
npm test
npm run test:componentes
npm run test:camada2
npm run test:camada3:vitest
npm run test:qualidade:estatica
npm run test:bundle
npm run test:segredos:bundle
npm run test:integridade
```

A execução de integridade usa o Java atual como referência e retorna código diferente de zero devido às nove divergências herdadas já presentes na Etapa 02.

## Evidências

A correspondência é:

- `01_runtime_config_nomenclatura.log` — runtime/configuração/nomenclatura;
- `02_unitarios.log` — unitários;
- `03_componentes.log` — componentes;
- `04_camada2.log` — comportamento/Camada 2;
- `05_camada3_robustez.log` — robustez/Camada 3;
- `06_qualidade_estatica.log` — auditoria estática;
- `07_bundle.log` — build/budget;
- `08_segredos_bundle.log` — fail-closed/segredos;
- `09_integridade_java.log` — integração estática/contratual React × Java;
- `09_integridade_java.exit` — código de saída da integridade;
- `10_ETAPA02_INTEGRIDADE_COM_JAVA_REFERENCIA.txt` — baseline usada para provar que as nove falhas são herdadas.

## Nota

Nenhuma dependência npm foi adicionada para implementar a Etapa 03. Todo o trabalho foi realizado sobre as dependências já aprovadas na Etapa 02.
