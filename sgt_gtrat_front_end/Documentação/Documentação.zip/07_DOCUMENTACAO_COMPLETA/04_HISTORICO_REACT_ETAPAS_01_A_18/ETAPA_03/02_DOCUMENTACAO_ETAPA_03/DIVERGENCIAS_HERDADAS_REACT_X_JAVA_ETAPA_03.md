# DIVERGÊNCIAS HERDADAS — REACT × JAVA — ETAPA 03

## Comparação direta

| Estado | Aprovados | Falhas |
|---|---:|---:|
| Etapa 02 contra Java atual | 267 | 9 |
| Etapa 03 contra Java atual | 267 | 9 |

As nove falhas possuem os mesmos títulos nas duas execuções.

## Conclusão

A Etapa 03 aumentou a infraestrutura e a cobertura de testes do React, mas **não ampliou a dívida de integração** com o Java.

Essas divergências não foram corrigidas dentro da Etapa 03 porque pertencem a contratos de autenticação, perfis, seeds, relatórios e outras áreas fora do núcleo HTTP. Corrigi-las antecipadamente aumentaria o risco de misturar etapas e criar efeitos colaterais.

Os logs completos estão em:

- `05_EVIDENCIAS_TESTES/09_integridade_java.log`;
- `05_EVIDENCIAS_TESTES/10_ETAPA02_INTEGRIDADE_COM_JAVA_REFERENCIA.txt`.
