# CONTRATO JAVA LIDO NA ETAPA 03

## CSRF

O Java atual define `TokenCsrfDTO` com:

- `headerName`;
- `parameterName`;
- `token`.

O endpoint utilizado pelo SPA é `GET /api/autenticacao/csrf`.

Consequência para o React: o nome do header CSRF é **dinâmico** e não deve ser assumido por serviço.

## Envelope de sucesso

`RespostaApi<T>` contém:

- `timestamp`;
- `status`;
- `error`;
- `message`;
- `requestId`;
- `meta`;
- `data`;
- `path`.

A Etapa 03 deixou de descartar `meta`, `requestId` e status quando o chamador necessita do envelope.

## Confirmação de senha

O inventário do Java atual encontrou:

- **123 ocorrências de `@ExigirSenha`**;
- distribuídas por **33 arquivos/controladores**.

O Java usa o header `X-User-Password`.

Quando a senha não acompanha a requisição protegida:

- HTTP **428**;
- código `PASSWORD_CONFIRMATION_REQUIRED`.

Quando a senha está incorreta:

- HTTP **403**;
- código `INVALID_CONFIRMATION_PASSWORD`;
- a sessão permanece válida.

## Idempotência

O Java atual possui `chaveIdempotencia` em DTOs/fluxos específicos, por exemplo relatórios, documentos comprobatórios, correções/retificações e frequência.

Não foi encontrado contrato global que determine `Idempotency-Key` como header universal. Por isso a Etapa 03 não inventa esse header.

## Limitações do contrato Java observadas

### 1. 403 de CSRF não é distinguível com segurança

O `AccessDeniedHandler` atual devolve 403 genérico com mensagem de autorização, e não há código padronizado como `CSRF_INVALID` ou `CSRF_MISSING`.

Decisão do React: **não assumir que qualquer 403 é CSRF**, porque isso poderia repetir uma mutação negocial após uma negação de autorização.

A infraestrutura já suporta renovação se o backend passar a emitir código inequívoco de CSRF.

### 2. 429 sem Retry-After

O `FiltroLimitacaoRequisicoes` atual devolve 429 e mensagem JSON, porém não foi encontrado header `Retry-After`.

A infraestrutura React interpreta e respeita `Retry-After` quando ele existir. No contrato Java atual, a UI ainda precisa trabalhar com a mensagem/estado recebido.

## Java inalterado

Todos os pontos acima são observações de contrato. Nenhum arquivo do backend foi modificado na Etapa 03.
