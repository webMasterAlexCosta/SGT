# PENDÊNCIAS E RISCOS — ETAPA 03

## 1. Nove divergências herdadas React × Java

A suíte integrada permanece com as mesmas nove falhas da Etapa 02:

1. corpos principais têm os mesmos campos públicos nos dois projetos;
2. carga inicial cria GTRAT, GEDIS e GETRA em todas as UFs;
3. seeds de desenvolvimento registram conclusão e não repetem a carga;
4. Gestão Estadual tem leitura sem herdar escrita operacional;
5. integração de e-mail usa Gmail SMTP somente no backend;
6. exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão;
7. backend mantém escopo por perfil e processa grandes bases em lotes;
8. gestor estadual recebe leitura da tela e da API de feriados e folgas;
9. contrato integrado Java aplica 30 minutos e logout revogável.

Nenhuma foi introduzida pela Etapa 03.

## 2. 403 CSRF não tem código inequívoco no Java

O Java atual entrega acesso negado 403 de forma genérica. Reexecutar automaticamente uma mutação após todo 403 seria perigoso.

Mitigação aplicada:

- o React só renova/reenvia quando o erro é identificado explicitamente como CSRF;
- mutação precisa estar marcada como segura/idempotente para replay;
- não há loop de renovação.

Recomendação de backend futura: diferenciar falha CSRF com código estável.

## 3. 429 não fornece Retry-After

O React já suporta `Retry-After`, mas o filtro Java atual não envia esse header.

Risco: a UI não consegue derivar com precisão o tempo de espera apenas do protocolo HTTP.

## 4. Requisitos dependentes de módulos de domínio

Alguns requisitos do catálogo não podem ser encerrados somente pela infraestrutura:

- bloqueio visual de double click em cada comando;
- confirmação semântica adicional de exclusão/inativação/anulação;
- prévia e confirmação em duas fases;
- invalidação de prévia após edição;
- tratamento de conflito de token de prévia;
- consulta do estado atual após resultado incerto;
- retorno seguro à lista em 404 de telas de detalhe.

Eles permanecem rastreados para as etapas 04–18 conforme os módulos concretos forem migrados.

## 5. Autenticação/roles ainda são legado

A Etapa 03 deliberadamente não removeu:

- `skipTwoFactor`;
- `ROLE_*` canônico legado;
- contratos antigos de sessão/2FA.

Esses itens pertencem à **Etapa 04**. A existência deles não deve ser interpretada como regressão da Etapa 03.

## 6. Bundle grande

O build informa chunk `vendor-face` acima de 1 MB minificado. O gate atual passa, mas é dívida de performance para revisão posterior, especialmente na Etapa 05 (shell/lazy loading/bundle).
