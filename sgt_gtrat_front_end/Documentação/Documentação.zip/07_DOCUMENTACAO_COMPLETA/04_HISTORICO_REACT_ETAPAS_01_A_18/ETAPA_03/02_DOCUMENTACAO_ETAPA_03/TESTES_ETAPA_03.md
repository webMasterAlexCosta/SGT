# TESTES — ETAPA 03

## Estado validado

Os logs em `05_EVIDENCIAS_TESTES` foram gerados depois da última alteração de código da etapa.

| Gate | Resultado |
|---|---:|
| Runtime/configuração | 16/16 aprovados |
| Unitários | 40/40 aprovados |
| Componentes | 335/335 aprovados |
| Camada 2 | 571/571 aprovados |
| Camada 3/robustez | 461/461 aprovados |
| Qualidade estática | 216 arquivos; 0 erros de gate; 1 aviso |
| Bundle | aprovado |
| Segredos no bundle | aprovado |
| Integridade React × Java | 267/276; 9 divergências herdadas |

## Cobertura focal da Etapa 03

`httpEtapa03.test.js` comprova, entre outros:

- primeira mutação com bootstrap CSRF;
- três mutações concorrentes usando um único bootstrap;
- uso do `headerName` retornado pelo Java;
- GET sem bootstrap CSRF;
- envelope/meta/status/headers/requestId;
- 202 pendente;
- 204 sem conteúdo;
- 428 + senha correta;
- senha incorreta 403 sem logout da sessão;
- cancelamento do modal 428;
- replay único;
- preservação da mesma chave de idempotência no replay;
- não repetição de mutação arbitrária após falha de rede;
- resultado incerto para mutação sem resposta;
- retry GET;
- cancelamento durante backoff;
- renovação CSRF apenas quando identificada e declarada segura;
- 403 genérico não interpretado como CSRF;
- 409;
- 413;
- 415;
- 422;
- `Retry-After`;
- sanitização de erro técnico/PII/segredos;
- `withCredentials`;
- `AbortSignal`;
- arrays/query params;
- LocalDate;
- YearMonth;
- Instant;
- multipart;
- download e `Content-Disposition`.

`ConfirmacaoSenhaHttpEtapa03.test.jsx` comprova que o modal:

- mostra ação;
- mostra entidade;
- mostra consequência;
- envia a senha somente ao callback;
- limpa a senha após tentativa inválida.

## Regressão

A inclusão do provedor global inicialmente revelou uma única falha no manifesto de componentes: o novo componente público não possuía fixture. A fixture foi adicionada e a suíte foi repetida, fechando em **335/335**.

## Integridade com o Java

Etapa 02: **267 aprovados / 9 falhas**.

Etapa 03: **267 aprovados / 9 falhas**.

Os títulos das nove falhas são os mesmos. Portanto, a Etapa 03 **não criou nova divergência de contrato**.

## Observações de log

O teste de absenteísmo registra em `stderr` a mensagem `resumo indisponível` porque existe um cenário de teste que simula deliberadamente falha do resumo. O teste passa e a tabela é preservada; não é regressão.

O build ainda apresenta aviso do Vite de chunk acima de 1000 kB (`vendor-face`). O gate de bundle passa e essa otimização não pertence ao objetivo funcional da Etapa 03.
