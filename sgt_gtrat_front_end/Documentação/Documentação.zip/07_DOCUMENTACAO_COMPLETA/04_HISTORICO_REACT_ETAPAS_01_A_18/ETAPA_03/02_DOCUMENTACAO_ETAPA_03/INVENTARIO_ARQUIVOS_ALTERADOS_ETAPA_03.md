# INVENTÁRIO DE ARQUIVOS ALTERADOS — ETAPA 03

Total: **7 arquivos modificados + 13 arquivos novos = 20 arquivos**.

## Modificados

- `src/Aplicacao.jsx`
- `src/core/http/configuracaoRequisicaoAxios.js`
- `src/core/http/retryPolicy.js`
- `src/core/http.js`
- `src/core/security/ModalConfirmacaoSenha.jsx`
- `src/core/security/ModalConfirmacaoSenha.module.css`
- `test/vitest-componentes/fixtures/componentesManifest.js`

## Novos

- `src/core/http/coordenadorConfirmacaoSenha.js`
- `src/core/http/coordenadorCsrf.js`
- `src/core/http/datasHttp.js`
- `src/core/http/download.js`
- `src/core/http/erroHttp.js`
- `src/core/http/idempotencia.js`
- `src/core/http/metodosHttp.js`
- `src/core/http/multipart.js`
- `src/core/http/respostaHttp.js`
- `src/core/http/sanitizacao.js`
- `src/core/security/ProvedorConfirmacaoSenhaHttp.jsx`
- `test/vitest/httpEtapa03.test.js`
- `test/vitest-componentes/ConfirmacaoSenhaHttpEtapa03.test.jsx`

## Dependências

`package.json` e `package-lock.json` não foram alterados em relação à Etapa 02.
