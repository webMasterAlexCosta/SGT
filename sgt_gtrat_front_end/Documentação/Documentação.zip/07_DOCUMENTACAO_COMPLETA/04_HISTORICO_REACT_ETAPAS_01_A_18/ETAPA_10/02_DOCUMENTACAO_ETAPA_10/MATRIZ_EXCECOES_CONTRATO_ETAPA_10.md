# Exceções contratuais — Etapa 10

## Transferência de Gestão

- contrato publicado;
- executada pelo Gestor Local da origem;
- Gestão destino diferente e ativa;
- autorização administrativa excepcional vigente;
- data efetiva dentro da vigência;
- mapeamento explícito de composição origem para Lotação/Turno/Cargo destino;
- backend exige cobertura integral de composições operacionais e alocações posteriores;
- sem movimentação automática criada pelo React;
- histórico disponível em `/transferencias-gestao`.

## Correção de identificador

- fluxo excepcional após publicação;
- número/ano antigo preservado;
- data efetiva + data do ato + motivo + SEI + autorização;
- chave de idempotência por intenção;
- histórico pesquisável pelo identificador antigo.

## Correção de anulação

- somente contrato ANULADO;
- seleciona evento de ANULACAO do próprio contrato;
- relação `CANCELA`;
- mesma data efetiva do evento cancelado;
- exige SEI;
- não reativa administrativamente o contrato.
