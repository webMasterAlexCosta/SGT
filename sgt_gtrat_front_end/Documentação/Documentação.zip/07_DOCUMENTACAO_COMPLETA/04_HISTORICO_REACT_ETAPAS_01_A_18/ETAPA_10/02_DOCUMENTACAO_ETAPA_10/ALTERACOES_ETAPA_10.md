# Alterações — Etapa 10

## Escopo

Contratos — documentos, transferências e correções excepcionais.

## Implementado

- Serviço dedicado com os 19 endpoints da etapa.
- Módulo documental integrado ao detalhe do contrato.
- Upload multipart com parte JSON `metadados` e parte opcional `arquivo`.
- Registro por anexo, SEI ou ambos.
- Vínculo documental a fato existente (`fatoId`) ou fato futuro (`fatoChave`).
- Download blob preservando nome retornado por `Content-Disposition`.
- Tratamento explícito de HTTP 413, 415 e 409.
- Progresso de upload por `onUploadProgress` sem inventar limite em bytes no cliente.
- Cadeia de eventos/versionamento documental.
- Retificação de SEI, nova versão/acréscimo de anexo, invalidação e descarte apenas do rascunho elegível.
- Classificação `NEGOCIAL` e `PESSOAL_RESTRITO`.
- Finalidade obrigatória na UI antes de tentativa de acesso restrito.
- Usuário Operacional não recebe o módulo documental, coerente com a regra interna do serviço Java.
- Administrador técnico pode conceder/revogar permissões; Gestor Local responsável pode consultar permissões/acessos e gerir documentos.
- Transferência excepcional de Gestão Local com mapeamentos explícitos de composição origem → Lotação/Turno/Cargo de destino.
- Correção excepcional de número/ano com chave de idempotência e histórico pesquisável.
- Correção de anulação ligada ao evento ANULACAO por `relacaoPrecedencia=CANCELA`, sem reativação silenciosa.
- Confirmação de senha reutiliza exclusivamente o mecanismo HTTP central construído na Etapa 03.

## Arquivos principais

- `src/services/admin/ServicoExcecoesContrato.js`
- `src/services/admin/ServicoDominioExcecoesContrato.js`
- `src/modules/admin/pages/PaginaContratos/components/PainelExcecoesContrato/index.jsx`
- `src/modules/admin/pages/PaginaContratos/components/PainelExcecoesContrato/index.module.css`
- `src/modules/admin/pages/PaginaContratos/components/ModalDetalhesContrato/index.jsx`
- `test/vitest/excecoesContratoEtapa10.test.js`
- `test/excecoesContratoEtapa10.test.js`
