# Pendências e riscos — Etapa 10

1. **XLSX de frequência no Java:** única falha do gate integrado; não pertence ao escopo desta etapa.
2. **Limite máximo de upload:** o Java possui limite configurado internamente, mas não há endpoint público desta etapa expondo o número. O React não duplica/inventa bytes; reage ao 413 do servidor.
3. **Transferência excepcional:** não existe endpoint de prévia autoritativa entre os 19 endpoints. A UI exige revisão explícita e confirmação de senha, mas a validação atômica final permanece no Java.
4. **Permissão excepcional de transferência/correção:** o Java exige concessão administrativa vigente. A Etapa 10 consome a autorização informada, mas a administração dessas concessões pertence a outro módulo/etapa.
5. **Smoke arquivo contra backend vivo:** não executado neste ambiente; ver `TESTES_ETAPA_10.md`.
