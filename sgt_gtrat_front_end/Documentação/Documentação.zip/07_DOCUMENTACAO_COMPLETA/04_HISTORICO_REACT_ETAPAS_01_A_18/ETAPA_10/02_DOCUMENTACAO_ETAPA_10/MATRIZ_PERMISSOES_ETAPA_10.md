# Permissões — Etapa 10

- **Gestor Local responsável:** escrita documental e ações excepcionais contratuais dentro do escopo; consulta de permissões/acessos restritos.
- **Administrador técnico:** consulta contratual; concessão/revogação de acesso a documento PESSOAL_RESTRITO. Leitura do conteúdo restrito continua dependente das regras do Java.
- **Gestor Nacional / Presidente / Gestor Estadual:** consulta de documentos negociais no escopo. Documento restrito depende de finalidade e permissão específica.
- **Operacional:** não recebe o módulo documental; o serviço Java também bloqueia explicitamente o acesso.

Ocultar ação na UI é apenas affordance; a autorização definitiva permanece no Java.
