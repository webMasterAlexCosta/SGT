# Dependências

Comparação com Etapa 09:

- package.json: idêntico
- package-lock.json: idêntico
- .node-version: idêntico
- .nvmrc: idêntico
