# Matriz documental — Etapa 10

| Tema | Comportamento React |
|---|---|
| Fonte | arquivo, SEI ou ambos |
| Multipart | `metadados` JSON + `arquivo` opcional |
| Fato | `tipoFato` + `fatoId` existente ou `fatoChave` futuro |
| Classificação | NEGOCIAL / PESSOAL_RESTRITO |
| Restrito | finalidade declarada antes da consulta/download |
| Upload | progresso visual; limite definitivo no Java |
| 413 | mensagem de limite do servidor |
| 415 | mensagem de extensão/MIME/assinatura |
| Retificação SEI | nova versão/evento; referência anterior preservada |
| Nova versão/anexo | arquivo e/ou SEI; versão anterior preservada |
| Invalidação | não apaga histórico |
| Descarte | somente RASCUNHO sem SEI externo, ainda validado pelo Java |
| Download | blob + nome de `Content-Disposition` |
| Permissão | Administrador concede/revoga; Java valida necessidade e vigência |
| Auditoria | eventos, permissões e acessos exibidos quando autorizados |
