# Testes — Etapa 10

| Gate | Resultado |
|---|---:|
| Node/npm runtime | Node 22.16.0 / npm 10.9.2 |
| `npm ci --offline` | 229 pacotes |
| Configuração | 16/16 |
| Focais Etapa 10 | 5/5 |
| Integração focal React × Java | 7/7 |
| Unitários | 96/96 |
| Componentes | 352/352 |
| Camada 2 | 597/597 |
| Camada 3 | 482/482 |
| Nomenclatura | 233 arquivos aprovados |
| Qualidade estática | 0 erros de gate, 1 aviso |
| Bundle/budget | aprovado |
| Segredos no bundle | aprovado |
| Integridade React × Java | 307/308 |

A única falha do gate integrado é a exportação XLSX de frequência no Java (`XlsxStreamingWriter`), preexistente e fora da Etapa 10.

### Limitação de smoke real

O Java não foi inicializado com banco/ambiente operacional nesta etapa; portanto não foi possível comprovar um upload/download ponta a ponta contra servidor vivo. O contrato multipart/download foi validado por testes React, inspeção do controlador/serviço Java e build. O ZIP não classifica esse smoke como executado.
