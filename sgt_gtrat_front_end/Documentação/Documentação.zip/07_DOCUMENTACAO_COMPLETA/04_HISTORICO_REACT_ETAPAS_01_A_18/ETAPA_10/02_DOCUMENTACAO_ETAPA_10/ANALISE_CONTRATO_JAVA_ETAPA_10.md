# Análise do contrato Java — Etapa 10

## Documentos

`DocumentoComprobatorioControlador` possui 13 endpoints. Escrita documental é do Gestor Local responsável. Concessão/revogação de permissão restrita é administrativa.

O `DocumentoComprobatorioServico` reforça regras que não podem ser deduzidas apenas do matcher HTTP:

- Operacional não acessa documentos;
- rascunho documental só é visível ao Gestor Local responsável;
- `PESSOAL_RESTRITO` exige finalidade;
- usuário que não é o Gestor Local responsável necessita permissão específica vigente;
- acessos restritos são auditados;
- arquivo é validado por tamanho, extensão, MIME e assinatura binária;
- versão publicada errada não é apagada: é substituída/inválida preservando trilha.

## Transferência de Gestão

`POST /api/contratos/{id}/transferir-gestao` exige Gestor Local da Gestão de origem, contrato publicado, autorização excepcional vigente, Gestão destino ativa e mapeamento completo das composições/alocações posteriores. O serviço executa atomicamente ou retorna erro.

## Correção de identificador

Número/ano publicado é corrigido por fato excepcional idempotente. O identificador anterior permanece pesquisável em `/api/contratos/historico-identificador`.

## Correção de anulação

A correção exige o evento ANULACAO precedente e `relacaoPrecedencia=CANCELA`, mesma data efetiva e referência documental. O Java volta o estado negocial a PUBLICADO, porém mantém `ativo=false`; reativação administrativa continua comando separado.
