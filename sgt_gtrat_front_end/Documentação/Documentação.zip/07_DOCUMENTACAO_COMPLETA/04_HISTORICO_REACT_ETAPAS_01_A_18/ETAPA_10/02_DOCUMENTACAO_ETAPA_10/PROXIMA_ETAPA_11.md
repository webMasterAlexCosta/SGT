# Próxima etapa — Etapa 11

**Pessoas e vínculos contratuais.**

A próxima etapa deve migrar a identidade canônica para Pessoa → Vínculo Contratual, implementar busca/edição de Pessoa com proteção de PII, ciclo de vida do vínculo, histórico/datas efetivas e substituir dependências de `empregadoId` por `vinculoContratualId` onde o Java atual exigir.

A Etapa 11 não foi iniciada neste pacote.
