# Origem documental — Etapa 02

- Fonte recuperada: `SGT_GTRAT_REACT_ETAPA_02.zip`.
- Conteúdo preservado sem reescrita: `00_LEIA_PRIMEIRO`, `02_DOCUMENTACAO_ETAPA_02` e `05_EVIDENCIAS_TESTES` quando existentes.
- Arquivos recuperados desta fonte: **45**.
- A documentação histórica é preservada para rastreabilidade; em conflito, prevalecem o Java atual e a documentação final da Etapa 18.
