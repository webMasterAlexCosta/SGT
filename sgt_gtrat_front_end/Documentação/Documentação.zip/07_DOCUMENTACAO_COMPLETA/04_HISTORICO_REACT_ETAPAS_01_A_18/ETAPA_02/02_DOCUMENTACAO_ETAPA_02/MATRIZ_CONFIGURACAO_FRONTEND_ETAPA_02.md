# MATRIZ DE CONFIGURAÇÃO FRONTEND — ESTADO DA ETAPA 02

## Precedência
1. **Vite/.env (build):** infraestrutura, identidade, preferências e hints de UX.
2. **`/config.json` (runtime Java):** parâmetros públicos dinâmicos e estado operacional público; sobrepõe os campos dinâmicos equivalentes do build.
3. **Endpoints de domínio:** fonte autoritativa para permissões, prazos, limites negociais, temporalidade e validações complexas.

## Variáveis Vite

| Grupo | Variáveis | Autoritativa para negócio? |
|---|---|---|
| Infraestrutura HTTP | `VITE_API_URL`, `VITE_HTTP_TIMEOUT`, `VITE_HTTP_RETRY_BASE_MS`, `VITE_HTTP_RETRY_MAX_MS` | Não |
| Sessão/heartbeat UX | `VITE_PING_INTERVAL_MS`, `VITE_SESSION_MAX_TIME_MS`, `VITE_SESSION_WARN_5MIN_MS`, `VITE_SESSION_WARN_1MIN_MS`, `VITE_SESSION_REFRESH_INTERVAL_MS`, `VITE_INACTIVITY_TIMEOUT_MS` | Não; contrato de sessão será revisado na Etapa 04 |
| Identidade institucional | `VITE_APP_NAME`, `VITE_APP_COMPANY`, `VITE_APP_CNPJ`, `VITE_APP_AUTHOR_*`, `VITE_COMPANY_DEPARTMENT`, `VITE_APP_CLIENT_ID`, `VITE_APP_ALLOWED_DOMAIN` | Não |
| Estado visual fallback | `VITE_EM_MANUTENCAO`, `VITE_PREVISAO_RETORNO` | Não; `/config.json` prevalece |
| Preferência/otimização de UI | `VITE_FREQUENCIA_MAX_GRID_ITEMS`, `VITE_FREQUENCIA_EDIT_WARNING_MINUTES`, `VITE_ABSENTEISMO_DEFAULT_META`, paginações, debounce, toasts, upload UX, latência, tooltips, dashboard | Não |
| Credenciais de teste | `VITE_SHOW_TEST_CREDENTIALS`, `VITE_TEST_GLOBAL_PASSWORD`, `VITE_TEST_GESTOR_PASSWORD` | Nunca; fail-closed em produção |
| Referências visuais de jornada | `VITE_JORNADA_REFERENCIA_HORAS`, `VITE_JORNADA_LIMIAR_INFERIOR`, `VITE_JORNADA_LIMIAR_MEDIO` | Não; Java valida a jornada |

## Variáveis somente de desenvolvimento/shell
`DEV_PROXY_TARGET`, `DEV_SERVER_HOST`, `DEV_SERVER_PORT`, `DEV_HTTPS_ENABLED`, `DEV_HTTPS_PFX_PATH`, `DEV_HTTPS_PFX_PASSPHRASE`, `JAVA_BACKEND_DIR` e `JAVA_STATIC_DIR` não são expostas como contrato de negócio do browser.

## Removidas como autoridade local
`VITE_FREQUENCIA_LIMIT_ADMIN_DAYS`, `VITE_FREQUENCIA_LIMIT_UNLOCKED_DAYS`, `VITE_FREQUENCIA_LIMIT_DEFAULT_DAYS`, `VITE_FREQUENCIA_EDIT_WINDOW_HOURS`, `VITE_OCORRENCIA_MAX_DIAS` e `VITE_AUTH_PASSWORD_MIN_LENGTH`.

## Rebuild × runtime
- Alterar `VITE_*` exige novo build Vite.
- Alterar `/config.json` pode surtir efeito no novo carregamento sem recompilar o frontend, desde que o contrato do JSON permaneça válido.
- Regras de domínio não devem ser transportadas para `VITE_*`; devem vir da API/resposta do Java.
