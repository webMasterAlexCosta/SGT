# TESTES — ETAPA 02

## Ambiente final
- Node: **v22.16.0**
- npm: **10.9.2**
- React: **19.2.8**
- Vite: **8.2.0**
- Vitest: **4.1.11**
- Instalação limpa: `npm ci --offline`

## Gates concluídos

| Gate | Resultado |
|---|---|
| `npm ci --offline` | APROVADO — 229 pacotes, 0 vulnerabilidades |
| `npm ls --all` | APROVADO |
| `npm run validate:runtime` | APROVADO |
| `npm run validar:nomenclatura` | APROVADO |
| `npm run test:configuracao` | **16/16 aprovados** |
| `npm run test` | **20/20 aprovados** |
| `npm run test:componentes` | **332/332 aprovados** |
| `npm run test:camada2` | **568/568 aprovados** |
| `npm run test:camada3:vitest` | **459/459 aprovados** |
| `npm run test:qualidade:estatica` | APROVADO — 205 arquivos, 0 erros de gate, 1 aviso |
| `npm run test:bundle` | APROVADO |
| `npm run test:segredos:bundle` | APROVADO |
| Preview HTTP do `index.html` | APROVADO — HTTP 200 |
| Chromium headless | NÃO CONCLUÍDO — timeout/DBus do ambiente; não contabilizado como aprovado |

## Bundle
- JS total: **3662,1 KB**
- JS gzip: **1028,7 KB**
- CSS total: **492,2 KB**
- Maior chunk: **1283,8 KB** (`vendor-face` é o principal candidato a otimização/lazy load futura)
- O budget executável passou; o Vite emite aviso de chunk > 1000 kB, registrado como risco de performance, não regressão funcional.

## Integridade React × Java

### Estado Etapa 02
- testes: **276**
- aprovados: **267**
- falhos: **9**

### Baseline React original contra o MESMO Java
- testes: **264**
- aprovados: **255**
- falhos: **9**

### Comparação
O conjunto nominal das 9 falhas é idêntico antes e depois. Portanto, a Etapa 02 **não adicionou nova divergência integrada**.

1. corpos principais têm os mesmos campos públicos nos dois projetos
2. carga inicial cria GTRAT, GEDIS e GETRA em todas as UFs
3. seeds de desenvolvimento registram conclusão e não repetem a carga
4. Gestão Estadual tem leitura sem herdar escrita operacional
5. integração de e-mail usa Gmail SMTP somente no backend
6. exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão
7. backend mantém escopo por perfil e processa grandes bases em lotes
8. gestor estadual recebe leitura da tela e da API de feriados e folgas
9. contrato integrado Java aplica 30 minutos e logout revogável

Essas divergências permanecem abertas para as etapas de domínio correspondentes. Elas não são classificadas automaticamente como bug Java; precisam ser triadas pelo contrato da etapa responsável.

## Smoke de navegador
O `vite preview` respondeu `HTTP 200` para a raiz. O Chromium headless do ambiente não finalizou `--dump-dom` e registrou erros de DBus/zygote; por isso o smoke visual foi marcado como **não concluído**, conforme a regra da documentação original de nunca inferir aprovação por limitação de ambiente.
