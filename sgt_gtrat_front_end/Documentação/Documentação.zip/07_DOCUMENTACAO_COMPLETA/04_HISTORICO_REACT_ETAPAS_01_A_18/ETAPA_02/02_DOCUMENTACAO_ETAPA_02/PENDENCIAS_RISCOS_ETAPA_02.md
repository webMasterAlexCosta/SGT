# PENDÊNCIAS E RISCOS — ETAPA 02

## 1. Divergências herdadas React × Java
Existem **9 divergências integradas** e elas já estavam presentes no React original contra o Java atual. Não bloqueiam o gate específico da Etapa 02, mas devem ser tratadas nas etapas responsáveis por contrato, seeds, perfis, exportação e sessão.

1. corpos principais têm os mesmos campos públicos nos dois projetos
2. carga inicial cria GTRAT, GEDIS e GETRA em todas as UFs
3. seeds de desenvolvimento registram conclusão e não repetem a carga
4. Gestão Estadual tem leitura sem herdar escrita operacional
5. integração de e-mail usa Gmail SMTP somente no backend
6. exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão
7. backend mantém escopo por perfil e processa grandes bases em lotes
8. gestor estadual recebe leitura da tela e da API de feriados e folgas
9. contrato integrado Java aplica 30 minutos e logout revogável

## 2. Bundle pesado
O maior chunk está em aproximadamente **1,28 MB** minificado e decorre principalmente da biblioteca de reconhecimento facial. O aviso do Vite permanece. A estratégia de lazy load/code splitting deve ser aprofundada na Etapa 05 e nas telas que realmente usam essa capacidade.

## 3. HTTP avançado ainda é legado
A Etapa 02 não deve antecipar a Etapa 03. Ainda faltam a centralização definitiva de envelope, CSRF, `requestId`, 428/senha, idempotência, retry seguro e política completa de timeout/cancelamento.

## 4. Autenticação/roles ainda não canônicos
O React antigo ainda contém contratos que serão substituídos na Etapa 04. Não foram alterados nesta etapa para evitar mistura de escopo.

## 5. Smoke Chromium
O navegador headless disponível no ambiente não concluiu o dump DOM por timeout e mensagens DBus/zygote. O HTTP do preview respondeu 200. O smoke visual permanece **não concluído**, não “aprovado por inferência”.

## 6. Segredos de desenvolvimento
O pacote de fonte mantém os arquivos de desenvolvimento recebidos pelo usuário (`.env` e `keystore.p12`) porque fazem parte do estado do projeto solicitado. O gate de produção prova que credenciais de teste não entram no bundle quando o modo de produção é usado. Antes de produção, credenciais/chaves/certificados de desenvolvimento devem ser substituídos conforme o processo do projeto.
