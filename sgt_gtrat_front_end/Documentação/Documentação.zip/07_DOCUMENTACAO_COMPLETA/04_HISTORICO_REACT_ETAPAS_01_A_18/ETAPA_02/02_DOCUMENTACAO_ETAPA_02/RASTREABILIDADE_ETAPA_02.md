# RASTREABILIDADE — ETAPA 02

| Requisito | Status Etapa 02 | Evidência principal |
|---|---|---|
| RFE-CFG-001 | ATENDIDO | `VITE_API_URL`; parser aceita `/api` ou HTTP(S) |
| RFE-CFG-002 | ATENDIDO | `runtimeConfig.js`, bootstrap e 16 testes de configuração |
| RFE-CFG-003 | ATENDIDO | matriz de configuração desta entrega; regras locais removidas |
| RFE-CFG-004 | ATENDIDO | `VITE_FREQUENCIA_EDIT_WINDOW_HOURS` removido como autoridade |
| RFE-CFG-005 | ATENDIDO NO ESCOPO | paginação permanece preferência/teto de UI; servidor continua autoridade |
| RFE-CFG-006 | ATENDIDO | `test:segredos:bundle` fail-closed em produção |
| RFE-CFG-007 | ATENDIDO | autoria/rodapé separados de autenticação/autorização |
| RFE-CFG-008 | ATENDIDO | `X-Timezone` usa IANA do browser apenas como informação; regra é backend |
| RFE-CFG-009 | ATENDIDO NO ESCOPO | timeout default e overrides já existem; política HTTP será centralizada na Etapa 03 |
| RFE-CFG-010 | ATENDIDO | validador impede `VITE_*` de permissão/role/acesso |
| RFE-CFG-011 | ATENDIDO | parser rejeita NaN, zero proibido, faixa impossível e relações inválidas |
| RFE-CFG-012 | ATENDIDO | matriz desta entrega separa build Vite, runtime `/config.json` e shell/dev |
| RFE-CFG-013 | ATENDIDO | `validate:runtime` detecta VITE usada e não documentada ou órfã |
| RFE-CFG-014 | ATENDIDO | configuração administrativa continua consultada via API; não foi criada persistência substituta |
| RFE-CFG-015 | ATENDIDO NO GATE | falha de runtime não concede permissão/regra; backend segue autoridade; fallback é somente visual |

## Endpoint diretamente associado à Etapa 02
- `GET /config.json` — consumido no bootstrap por `ServicoSistema.carregarRuntimeConfig` e validado antes da combinação com a configuração de build.

## Gate da etapa
O gate documental original exige: **build limpo e configuração classificada; regra negocial crítica não depende de VITE_***. Esse gate foi satisfeito.
