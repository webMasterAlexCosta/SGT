# DIVERGÊNCIAS HERDADAS — REACT ORIGINAL × JAVA ATUAL

Este arquivo existe para impedir que falhas anteriores à Etapa 02 sejam atribuídas às mudanças de configuração.

## Resultado
- React original: 264 testes, 255 passam, 9 falham.
- React Etapa 02: 276 testes, 267 passam, 9 falham.
- Conjunto nominal das falhas: idêntico.

## Falhas herdadas
1. corpos principais têm os mesmos campos públicos nos dois projetos
2. carga inicial cria GTRAT, GEDIS e GETRA em todas as UFs
3. seeds de desenvolvimento registram conclusão e não repetem a carga
4. Gestão Estadual tem leitura sem herdar escrita operacional
5. integração de e-mail usa Gmail SMTP somente no backend
6. exportação XLSX de frequência é streaming, congela linhas/colunas e configura impressão
7. backend mantém escopo por perfil e processa grandes bases em lotes
8. gestor estadual recebe leitura da tela e da API de feriados e folgas
9. contrato integrado Java aplica 30 minutos e logout revogável

Nenhuma delas foi corrigida nesta etapa por aproximação. Cada uma será triada na etapa funcional correspondente.
