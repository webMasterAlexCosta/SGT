# PRÓXIMA ETAPA — 03

## Etapa 03 — Core HTTP, CSRF, envelope e segurança de comandos

Não iniciar mudanças de domínio antes de congelar a camada HTTP. A próxima etapa deve:
1. ler no Java o contrato real de CSRF, envelope, handlers, `@ExigirSenha`, idempotência e DTOs de erro;
2. inventariar o cliente Axios atual;
3. preservar status/headers/meta/requestId;
4. implementar bootstrap CSRF deduplicado;
5. injetar CSRF apenas em mutações;
6. centralizar o fluxo 428 + `X-User-Password` sem persistir senha;
7. modelar idempotência e retry seguro;
8. padronizar 400/401/403/404/409/413/415/422/428/429/5xx;
9. padronizar multipart, download, datas, arrays e cancelamento;
10. criar testes focais e de contrato antes de adaptar módulos.

**Baseline obrigatória:** usar `01_REACT_ETAPA_02/sgt_gtrat_front_end` desta entrega.
