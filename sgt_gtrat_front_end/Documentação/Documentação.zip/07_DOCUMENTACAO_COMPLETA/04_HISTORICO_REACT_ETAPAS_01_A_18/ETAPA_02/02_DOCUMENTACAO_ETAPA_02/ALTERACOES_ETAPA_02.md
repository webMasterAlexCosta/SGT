# ALTERAÇÕES — ETAPA 02

## 1. Objetivo executado

Preparar o React para evolução contra o Java atual, tornando runtime/configuração previsíveis e impedindo que variáveis `VITE_*` decidam regras negociais que pertencem ao backend.

## 2. Alterações realizadas

### Runtime Node/npm
- `engines.node` passou a exigir `>=22.16.0 <23`.
- `packageManager` permanece `npm@10.9.2`.
- `.nvmrc` e `.node-version` permanecem alinhados ao Node 22.16.0.
- O pacote offline enviado pelo usuário foi validado por `npm ci --offline` em reconstrução limpa.

### Configuração frontend
- Centralizada a leitura de `import.meta.env` em `src/core/config.js`.
- Criado `src/core/configuracaoFrontend.js` para parsing, normalização, validação de tipos/faixas e congelamento da configuração.
- `VITE_API_URL` aceita caminho relativo (`/api`) ou HTTP(S), sem host obrigatório hardcoded.
- Variáveis numéricas inválidas, `NaN`, zero proibido e combinações impossíveis agora falham explicitamente.
- Booleanos deixam de aceitar valores ambíguos como `sim/não`.
- `.env.example` passou a ser validado contra as `VITE_*` realmente consumidas, detectando variável faltante e variável órfã.

### `/config.json`
- Mantido como configuração pública dinâmica fornecida pelo Java.
- Criada validação tipada em `runtimeConfig.js`.
- O bootstrap da aplicação carrega `/config.json` antes de decidir manutenção.
- A precedência ficou explícita: infraestrutura/UX de build em Vite; parâmetros públicos dinâmicos em `/config.json`; regras/autorizações de domínio nas APIs.
- `EM_MANUTENCAO` e `PREVISAO_RETORNO` do Java prevalecem sobre o fallback local quando `/config.json` responde.

### Regras negociais removidas do `.env`
Foram removidas como autoridade local as variáveis que permitiam ao React inventar regras do backend, incluindo:
- `VITE_FREQUENCIA_LIMIT_ADMIN_DAYS`;
- `VITE_FREQUENCIA_LIMIT_UNLOCKED_DAYS`;
- `VITE_FREQUENCIA_LIMIT_DEFAULT_DAYS`;
- `VITE_FREQUENCIA_EDIT_WINDOW_HOURS`;
- `VITE_OCORRENCIA_MAX_DIAS`;
- `VITE_AUTH_PASSWORD_MIN_LENGTH`.

Também foram ajustados pontos de frequência, ocorrências e turnos para preservar validações estruturais/UX sem tornar o navegador a fonte de verdade da regra.

### Credenciais e fail-closed
- Em build de produção, credenciais de teste não entram no objeto de configuração.
- Mesmo com `VITE_SHOW_TEST_CREDENTIALS=true`, produção força `SHOW_TEST_CREDENTIALS=false`.
- Criado `scripts/verificar-segredos-bundle.mjs` com credenciais-canário para provar que o bundle de produção não incorpora senhas de teste.

### Vite e bundle
- `build.target` passou de `esnext` para `es2022`.
- `chunkSizeWarningLimit` foi reduzido de 2000 kB para 1000 kB.
- Proxy e HTTPS de desenvolvimento agora validam URL, porta e booleanos.
- `/api` e `/config.json` continuam apontando ao backend no desenvolvimento.
- O código continua React + CSS Modules, sem Tailwind e sem redesenho visual nesta etapa.

### Testes adicionados/ajustados
- `test/configuracaoFrontend.test.js`;
- `test/runtimeConfig.test.js` ampliado;
- `test/configuracaoNegocioNaoAutoritativa.test.js`;
- `test/bootstrapConfiguracaoRuntime.test.js`;
- validações adicionais de arquitetura/ambiente;
- scripts de runtime, bundle e segredos atualizados.

## 3. O que deliberadamente NÃO foi feito

- Não foi alterado o Java.
- Não foi iniciada a Etapa 03 (CSRF/envelope/428/idempotência/retry de mutações).
- Não foram substituídos ainda contratos legados de autenticação/roles, pois pertencem à Etapa 04.
- Não houve redesign: o padrão visual Correios atual foi preservado.
- As 9 divergências integradas herdadas não foram “corrigidas por aproximação”, para evitar efeito colateral fora do escopo.
