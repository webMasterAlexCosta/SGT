# Correção da verificação XLSX — sem alterar o Java

## Diagnóstico

A bateria `npm run test:integridade` tinha 343 verificações, com uma única falha no teste `relatorioFrequenciaExportacaoVisual.test.js`.

A asserção antiga procurava:

- `new XlsxStreamingWriter(..., 4, 4, larguras)`.

O Java atual, que é o contrato definitivo, contém no método `gerarFrequenciaXlsxNoArquivo`:

- `new XlsxStreamingWriter(..., 5, 5, larguras)`.

O `XlsxStreamingWriter` usa esses valores para `freezeRows` e `freezeColumns`. Portanto, a falha era **uma expectativa de teste React desatualizada**, não um defeito no backend e não um defeito do código produtivo React.

## Correção aplicada

Somente o teste React foi ajustado. A nova verificação:

1. isola especificamente o bloco `gerarFrequenciaXlsxNoArquivo` do Java;
2. confirma o construtor com `5, 5, larguras`;
3. continua verificando streaming, `pane`, orientação `landscape`, `fitToWidth=1`, ausência de gridlines, total geral, legenda e estilos.

Nenhum arquivo do Java foi alterado.

## Resultado

- teste focal de exportação de frequência: **7/7**;
- integridade React × Java: **343/343**;
- falhas: **0**.
