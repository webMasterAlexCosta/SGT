# Auditoria das Etapas 01 a 12 — conformidade com o Java definitivo

## Conclusão

A revisão foi executada sobre a baseline acumulada da Etapa 13 corrigida, confrontada com o `JAVA.zip` atual. **Não foi encontrada, nas Etapas 01 a 12, implementação produtiva que dependa de alteração do Java para funcionar.** O princípio observado é: o Java decide contrato HTTP, identidade, autorização, temporalidade, capacidade, estados e validações negociais; o React apresenta, prepara comandos e falha fechado quando não possui decisão autoritativa.

A antiga divergência 342/343 não era uma quebra desse princípio. Tratava-se de uma asserção de teste XLSX ainda fixada em `4,4`, enquanto o Java atual já usa `5,5`. O teste foi corrigido; a integridade passou a **343/343**.

## Matriz por etapa

| Etapa | Escopo | Resultado da auditoria contra o Java |
|---|---|---|
| 01 | baseline documental | Conforme. Não altera código. |
| 02 | runtime/configuração | Conforme. Node 22.16.0; configuração tipada; regra negocial não é decidida por `VITE_*`; fail-closed para credenciais. `test:configuracao`: 16/16. |
| 03 | HTTP/CSRF/envelope/428/idempotência | Conforme. 20 testes focais validam CSRF pelo `headerName` do backend, replay único de 428, idempotência, multipart, LocalDate, retry somente seguro, AbortSignal e requestId. |
| 04 | autenticação/sessão/2FA/perfis | Conforme. Login usa matrícula/senha/TOTP opcional; desafio 202 e 429 seguem resposta do Java; seis perfis canônicos e capacidades acompanham os matchers. |
| 05 | shell/navegação/acessibilidade | Conforme. Não cria contrato de domínio próprio; menu deriva das capacidades da Etapa 04 e permanece fail-closed. |
| 06 | estrutura/catálogos | Conforme e conservador. Temporalidade/inativos não são reativados localmente; selects encadeados cancelam respostas antigas; 403 permanece autoridade final. Para Cargo, diante de regras Java potencialmente contraditórias entre segurança/serviço, o React **não concede escrita** por suposição. |
| 07 | usuários/perfil/configuração administrativa | Conforme. Inventário acumulado cobre endpoints e campos aceitos; matchers e `@ExigirSenha` são verificados diretamente no Java; política de senha local é apenas dica de UX. |
| 08 | contrato núcleo/ciclo de vida | Conforme. 16 endpoints previstos cobertos; leitura/escrita segue matriz Java; estados, publicação, anulação, descarte e consulta bitemporal não são recalculados no browser. |
| 09 | composição/aditamento/remanejamento | Conforme. 15 endpoints cobertos; prévia/token, capacidade, redução, ocupação, soma zero, precedência e cancelamento são tratados segundo o Java, sem movimentação automática de pessoas. |
| 10 | documentos/transferências/correções | Conforme. 19 endpoints cobertos; multipart, SEI, permissões, transferência atômica, correção de identificador e correção de anulação seguem controladores/serviços/DTOs Java. |
| 11 | Pessoa/Vínculo | Conforme. `Pessoa` e `VinculoContratual` são a escrita canônica; `Empregado` não é usado como substituto de identidade; prévias, capacidade, desligamento e permissões seguem Java. |
| 12 | alocações temporais | Conforme. 8 endpoints temporais cobertos; `YearMonth`, `conhecidoAte`, prévia/token, retificação, cancelamento futuro, precedência, capacidade e opções vazias seguem o backend. |

## Evidências executadas nesta revisão

- Vitest principal: **117/117**;
- componentes: **367/367**;
- comportamento/camada 2: **628/628**;
- robustez/performance/camada 3: **503/503**;
- integridade estática React × Java: **343/343**;
- qualidade estática: **245 arquivos, 0 erros, 0 avisos**;
- nomenclatura: aprovada;
- runtime: **Node 22.16.0 / npm 10.9.2**;
- build/bundle: aprovado;
- segredos no bundle: fail-closed aprovado.

## Observação histórica importante

A primeira entrega da Etapa 13 chegou a interpretar a ausência de `vinculoContratualId` na projeção de frequência como necessidade de alteração no Java. Essa interpretação foi descartada e **não faz parte da baseline válida**. A baseline atual resolve o vínculo somente com endpoints já existentes no Java e preserva o backend sem alterações.

## Regra para as próximas etapas

A partir desta auditoria, qualquer nova etapa deve seguir a mesma ordem:

1. localizar o controlador/DTO/matcher Java existente;
2. implementar o React em cima desse contrato;
3. se houver ambiguidade, falhar fechado e buscar outra API Java existente;
4. nunca propor alteração do Java como forma de acomodar o React;
5. manter testes integrados que leiam diretamente o Java anexado para detectar deriva de contrato.
